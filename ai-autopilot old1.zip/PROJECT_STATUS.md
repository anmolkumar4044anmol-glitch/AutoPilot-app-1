# AI AutoPilot — Engineering Project Status & Audit Report

**Date of Audit:** October 31, 2026  
**System Target:** Android 8.0 (API 26) through Android 14+ (API 34)  
**Hardware Profiles:** 4 GB RAM (Lite Mode) & 8 GB RAM (Advanced Mode)  
**Architectural Stack:** Kotlin, Jetpack Compose, Android AccessibilityService, Foreground Service WindowManager Overlay, SQLite Local Database, Server-Side Gemini 3.8 Flash, GitHub Actions Cloud Build.

---

## 1. Feature Completion Matrix

| Feature Module | Status | Native Android Implementation | Cloud / Web Companion |
| :--- | :--- | :--- | :--- |
| **Floating Overlay Assistant** | ✅ Completed | `FloatingAssistantOverlayService.kt` (WindowManager overlay, default top-left `(16, 36)`, small green indicator, user-movable, compact 42dp diameter, does not obstruct game) | Interactive phone simulator with draggable bubble, 3-state glowing indicator, and minimization mode |
| **3-State Indicator** | ✅ Completed | **GREEN** = Running & allowed to execute, **ORANGE** = Paused with state preserved, **RED** = Emergency Stop (all gestures halted) | Color-coded pulsing visual states with tactile feedback |
| **Intelligent Pause & Resume** | ✅ Completed | `IntelligentResumeManager.kt` (7-Step Protocol: Load saved state, inspect screen, check completed steps, detect changes, recalculate plan, continue from safest step, never repeat destructive actions) | Interactive visual resume modal with state comparison ledger and duplicate action filter |
| **Explicit Application Closing** | ✅ Completed | Stops active tasks, removes floating overlay view, stops foreground service, removes ongoing notification | One-click "Close AutoPilot" handler with complete resource release |
| **Adaptive Task Intelligence** | ✅ Completed | `AdaptiveTaskPlanner.kt` (10-Step Process: Intent, Constraints, Trade-offs, Screen Drift Replan, User Corrections) | Multi-approach radar matrix, live visual task timeline, constraint sentinel, drift simulator |
| **AI AutoPilot Safety Manager** | ✅ Completed | `SecurityManager.kt` & `AutoPilotAccessibilityService.kt` (Accessible Emergency Stop on Main App, Floating Bubble, and Ongoing Notification; 6-Action Confirmation Gate for messages, deletion, payments, sensitive forms, personal info, irreversible actions; permanent kernel block on passwords/OTPs/banking PINs; transparent permissions & OEM revocation instructions for Samsung, Xiaomi, and Stock Android) | Dedicated Safety Manager tab, interactive confirmation dialogs, zero-credential shield, immutable local audit ledger, and full device ownership guarantees |
| **Gameplay Cooling Cooldowns** | ✅ Completed | `AdaptivePerformanceManager.kt` (Anti-overheating governor: forces 5–10s pause every X minutes of continuous Free Fire play, PowerManager thermal listeners, cooldown countdown) | Performance settings controls (slider 5–10s, interval 3–30m, presets 5/10/15/20m), real-time runtime tracker, on-screen cooldown countdown banner, and skip button |
| **Adaptive Performance Manager** | ✅ Completed | `AdaptivePerformanceManager.kt` (4GB Lite Mode vs 8GB Advanced Mode, single-task constraint, 400MB memory cap, 0.5 FPS capture rate, 3s idle sleep, event-driven accessibility, cooldown breathers, PowerManager thermal listener, mobile data payload compression, video download suppression, offline Room DB execution) | Complete dedicated settings page, hardware auto-recommendation profiler, real-time RAM/CPU/thermal gauges, honest thermodynamic physics disclosure, live stress test governor |
| **Humanized Delay Randomizer** | ✅ Completed | `HumanTouchSimulator.kt` & `TouchSettingsStore.kt` (Randomized jitters ±50ms default, 10–150ms range, Box-Muller organic Gaussian bell curve vs uniform linear distribution, persistent SharedPreferences) | Interactive slider, bell curve selector, live 5-interval organic thumb sampler, and telemetry canvas |
| **Human Touch Simulator** | ✅ Completed | `HumanTouchSimulator.kt` & `TouchSettingsStore.kt` (8 presets: 100ms–2000ms & custom, tap timing, swipe speed/distance, scrolling speed, natural pauses, typing interval, ±% timing variation, 5 gesture profiles, per-task timing, strict boundary clamping, strict gaming-only whitelist lock, SharedPreferences persistence) | Dedicated interactive settings page with live canvas tactile pad, real-time animation previews, reset-to-default, and gaming app guard |
| **Strict Gaming-Only Lockdown** | ✅ Completed | Hardcoded whitelist: Free Fire (`com.dts.freefireth`, `com.dts.freefiremax`, `com.dts.freefirein`) and gaming packages only. Completely blocks non-gaming apps (Banking, UPI, Settings, Messaging). | Real-time guardrail badge and security blocked logs |
| **Live Voice Companion** | ✅ Completed | `VoiceCompanionEngine.kt` (Android TTS in Hindi & English, SpeechRecognizer) | Web Speech API speech synthesis & recognition |
| **Fast Talk Mode** | ✅ Completed | Trims announcements to < 80 characters, speech rate 1.25x | Concise status updates without filler |
| **Automatic Phone Call Mode** | ✅ Completed | `CallModeManager.kt` & `PhoneCallStateReceiver.kt` (Dual API 31+ `TelephonyCallback` / `PhoneStateListener`, auto-mutes TTS speech, switches to written command mode, preserves active automation tasks, restores previous voice settings on call end, zero telecom call screening or answering permissions) | Clear pulsating `CALL MODE ACTIVE` indicator in header, on-screen call status pill, in-game mini HUD badge, manual quiet mode fallback switch, silent written command tester |
| **Offline Support** | ✅ Completed | `AppDatabase.kt` (Local SQLite for workflows & logs) | Offline rule fallback when Gemini disconnected |
| **Video & Tutorial Learning** | ✅ Completed | Safety audit filters credential inputs before macro creation | Transcript parser extracting executable steps |
| **Emergency Stop (RED)** | ✅ Completed | Atomic boolean halt cancelling all queued gestures, active tasks, and returning control to user immediately | Accessible in Main App, Floating Bubble, and Ongoing Notification with instant control return |
| **Genuine APK Cloud Build** | ✅ Completed | Gradle 8.7, JDK 17, Android SDK 34, `.github/workflows/build-apk.yml` | 1-Click ZIP exporter with mobile build guide |

---

## 2. Floating Assistant Lifecycle & Behaviour Verification

1. **User opens AutoPilot**: Launches into full interface, checks device profile (4GB Lite vs 8GB Advanced), loads saved settings from `TouchSettingsStore`.
2. **User activates assistant**: Starts `FloatingAssistantOverlayService` in the foreground.
3. **Android displays ongoing notification**: Posts notification on channel `autopilot_assistant_channel` with low importance (silent) and persistent ongoing flag.
4. **User minimizes application**: AutoPilot main interface collapses to background; `FloatingAssistantOverlayService` maintains the small green floating indicator at top-left of the screen.
5. **Floating control remains visible**: Draggable anywhere, compact 42dp diameter, does not obstruct Free Fire crosshairs.
6. **User pauses/resumes using floating control**:
   - Single tap toggles between **GREEN** (Running) and **ORANGE** (Paused).
   - Tapping PAUSE (OFF) preserves current step index and screen state without closing AutoPilot.
   - Tapping RESUME (ON) triggers the **Intelligent Pause and Resume Engine**, verifying current screen state and continuing from the safest next step.
   - Emergency Stop sets indicator to **RED** and severs all touch dispatching.
7. **User reopens main interface**: Double-tapping the floating bubble or tapping the "Open App" button in the ongoing notification restores the full interface.
8. **Explicit Close**: Tapping "Close AutoPilot" stops automation, cancels active task execution, removes floating controls from `WindowManager`, stops the foreground service, and clears the ongoing notification.

---

## 3. Automatic Call Mode & Privacy Compliance Architecture

When a phone call is incoming or in progress (`CALL_STATE_RINGING` or `CALL_STATE_OFFHOOK`), AutoPilot executes the 6-Step Call Mode Protocol:

1. **Automatically Mute AI AutoPilot Speech Output:** Immediately halts internal `TextToSpeech` queue and cancels all audio prompts.
2. **Switch to Written Command Mode:** Voice recognition microphone listener is automatically suspended, and the input interface transforms into an active text/typing command bar.
3. **Continue Accepting Permitted Written Commands:** The user can continue issuing tactical macros, Free Fire sensitivity changes, and permitted game automations via written commands without generating audio.
4. **Avoid Unnecessary Audio Playback:** All sound effects, synthesized speech, and completion chimes are suppressed during call duration.
5. **Preserve Task State:** Ongoing automation plans, current step indices, floating overlay coordinates, and touch settings remain completely intact and active.
6. **Restore Previous Voice Settings on Call End:** When `CALL_STATE_IDLE` is broadcast, AutoPilot retrieves the stored voice settings snapshot (pitch, speech rate, fast-talk mode, language) and restores prior user settings seamlessly.

### Strict Privacy & Telecom Guardrails:
• **Zero Telecom Interference:** AutoPilot **never** mutes, controls, modifies, or routes the actual phone call audio or cellular stream.  
• **No Automated Call Actions:** AutoPilot **never** automatically answers, screens, rejects, or hangs up telephone calls.  
• **Minimum Android Permissions:** AutoPilot requests only `android.permission.READ_PHONE_STATE` for `TelephonyCallback` / `PhoneStateListener`. It **never** requests `RECORD_AUDIO` for calls, never accesses call logs, and never collects phone numbers.  
• **Manual Quiet Mode Fallback:** If `READ_PHONE_STATE` permission is denied by the user or unavailable on the OEM build, AutoPilot provides an instant one-tap **Manual Quiet Mode** switch that enforces the identical speech-muted written command behavior.  
• **High-Visibility UI Indicators:** Clear pulsating `CALL MODE ACTIVE` status displays in the top bar, ongoing notification shade, on-screen simulator banner, and floating assistant bubble.

---

## 4. Features That Cannot Remain Active Under Android System Restrictions

As a genuine Android application adhering to platform security standards, the following restrictions apply:

1. **Touch Injection When Screen is Turned OFF:**
   - *Android Restriction:* The Linux display kernel and Android Accessibility framework suspend gesture dispatching whenever the phone screen is turned off or locked.
   - *Reason:* Platform security prevents phantom touches, pocket dialing, and battery drain.
2. **Screen Capture Without Interactive User Consent:**
   - *Android Restriction:* On Android 14+ (API 34), `MediaProjection` requires an explicit system dialog confirmation by the user each session. Background services cannot silently grab screen buffers without user awareness.
   - *Resolution:* AutoPilot utilizes pre-calibrated HUD coordinates and Bézier gestures for Open-GL games.
3. **Starting Background Activities Directly:**
   - *Android Restriction:* Since Android 10 (API 29), background services are prohibited from launching activities to the foreground unprompted.
   - *Resolution:* Main interface restoration is triggered via user interaction with the ongoing notification (`PendingIntent`) or floating bubble double-tap.
4. **Automation on Non-Gaming Applications:**
   - *Policy Restriction:* AutoPilot is hard-locked to Free Fire and approved gaming apps. Automation is strictly prohibited and automatically blocked on Banking, UPI, and System Settings apps.

---

## 4. OEM Manufacturer Whitelisting (Preventing Background App Killing)

Aggressive OEM power managers terminate background accessibility services unless whitelisted:

- **Xiaomi / HyperOS / MIUI:**
  - Settings → Apps → Manage Apps → AI AutoPilot → Enable **Autostart**.
  - Battery Saver → Set to **No restrictions**.
  - Other permissions → Enable **Display pop-up windows while running in background**.
  - Lock app in Recent Tasks screen.
- **Samsung One UI:**
  - Settings → Battery and Device Care → Battery → Background usage limits → **Never sleeping apps** → Add AI AutoPilot.
  - App Info → Battery → Select **Unrestricted**.
- **Vivo (Funtouch OS) & Oppo (ColorOS):**
  - Settings → Battery → High background power consumption → Enable AI AutoPilot.
  - App Management → Enable **Auto-launch** and **Floating Window**.
- **Generic Android 13/14/15:**
  - Whitelist via `Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`.

---

## 5. Permissions Required & Rationale

| Permission | Android Manifest Identifier | Why It Is Strictly Required |
| :--- | :--- | :--- |
| **Accessibility Service** | `android.permission.BIND_ACCESSIBILITY_SERVICE` | Required to read screen text, find buttons, and dispatch taps/swipes hands-free. |
| **Display Over Other Apps** | `android.permission.SYSTEM_ALERT_WINDOW` | Required to render the movable GREEN/ORANGE/RED floating control bubble over Free Fire. |
| **Foreground Service** | `android.permission.FOREGROUND_SERVICE` & `FOREGROUND_SERVICE_SPECIAL_USE` | Prevents the Android operating system from killing AutoPilot when minimized. |
| **Notifications** | `android.permission.POST_NOTIFICATIONS` | Required on Android 13+ to show the persistent running notification. |
| **Phone Call Detection** | `android.permission.READ_PHONE_STATE` | Detects when a phone call starts to immediately mute voice speech for privacy. |
| **Voice Microphone** | `android.permission.RECORD_AUDIO` | Required by Android `SpeechRecognizer` to capture voice commands in Hindi and English. |
| **Internet Access** | `android.permission.INTERNET` | Queries cloud AI reasoning (with 100% offline rule fallback). |

---

## 6. How to Build the Genuine APK (No Computer Required)

1. **Download Source:** In the web companion under the **APK Studio** tab, tap **"DOWNLOAD ANDROID PROJECT (.ZIP)"**.
2. **Open GitHub on Mobile:** In Google Chrome on your phone, open [github.com](https://github.com), sign in to your free account, and create a new repository called `AI-AutoPilot`.
3. **Upload Files:** Upload the downloaded ZIP contents.
4. **Automatic Compilation:** GitHub Actions will automatically detect `.github/workflows/build-apk.yml`, allocate a cloud runner with JDK 17 and Android SDK 34, and compile `app-debug.apk` in approximately 2–3 minutes.
5. **Download & Install:** In the **Actions** tab on GitHub, tap the latest workflow run, download the `AI-AutoPilot-Debug-APK` artifact, and tap **Install** on your phone!
