export type AssistantStatus = 'GREEN_RUNNING' | 'ORANGE_PAUSED' | 'RED_EMERGENCY_STOP' | 'COOLING_PAUSED' | 'IDLE';

export type DeviceMode = 'lite' | 'advanced'; // 4GB RAM vs 8GB RAM

export type ThermalState = 'normal' | 'warm' | 'elevated' | 'throttling';

export interface DeviceRecommendation {
  recommendedMode: DeviceMode;
  detectedMemoryGb: number;
  detectedCores: number;
  batteryLevelPct: number;
  isCharging: boolean;
  networkType: 'mobile_4g' | 'mobile_5g' | 'wifi' | 'metered';
  reasons: string[];
  autoApplied: boolean;
}

export interface PerformanceMetrics {
  estimatedRamUsageMb: number;
  maxRamAllocationMb: number;
  cpuLoadPct: number;
  thermalState: ThermalState;
  batteryDischargeRateMw: number;
  mobileDataSavedKb: number;
  screenshotFrequencyFps: number;
  cachedWorkflowsCount: number;
  activeParallelTasksCount: number;
  pollingIntervalMs: number;
  cooldownPeriodMs: number;
  idleReductionActive: boolean;
  thermalNote: string;
}

export interface AdaptivePerformanceSettings {
  mode: DeviceMode;
  autoRecommendationEnabled: boolean;

  // LITE MODE — 4 GB RAM
  singleTaskOnly: boolean;
  minimalBackgroundProcessing: boolean;
  reducedScreenshotFrequency: boolean; // e.g. 0.5 FPS instead of 3.0 FPS
  smallerAiRequests: boolean; // Compact payload and strict token truncation
  limitedWorkflowCache: boolean; // Keep only recent 5 vs 50 macros
  minimalAnimations: boolean; // Turn off complex UI canvas repaints
  aggressiveIdleReduction: boolean; // Sleep services after 3s inactivity

  // ADVANCED MODE — 8 GB RAM
  detailedTaskAnalysis: boolean;
  expandedWorkflowCache: boolean; // Keep up to 50 macros preloaded
  advancedVisualVerification: boolean; // Multi-pass OCR and template bounding
  complexTaskPlanning: boolean; // Multi-path reasoning
  controlledParallelProcessing: boolean; // Safe parallel verification and prefetching

  // BATTERY SAVING
  batterySaverEnabled: boolean;
  reducedPolling: boolean;
  pollingIntervalMs: number; // e.g. 1500ms instead of 400ms
  avoidContinuousCapture: boolean; // Strict event-driven onAccessibilityEvent vs continuous bitmap capture
  reducedBackgroundCpu: boolean;
  eventDrivenProcessing: boolean;
  cooldownPeriodsEnabled: boolean;
  cooldownDurationMs: number; // e.g. 800ms throttle between heavy analyses
  stopExpensiveAnalysisWhenIdle: boolean;

  // NETWORK & MOBILE DATA
  mobileDataOptimizer: boolean;
  compressPayloads: boolean;
  avoidVideoDownloads: boolean; // Extract tutorial from transcript/metadata without downloading large video files
  intelligentRetry: boolean; // Exponential backoff with jitter
  offlineExecutionPreferred: boolean; // Run local Room database workflows offline

  // CUSTOM GAMEPLAY COOLING COOLDOWNS (Anti-Overheating)
  periodicCoolingEnabled: boolean;
  coolingIntervalMinutes: number; // Force a pause every X minutes of continuous gameplay (e.g. 5, 10, 15m)
  coolingPauseDurationSec: number; // 5 to 10 seconds forced pause
}

export interface SensitiveActionRequest {
  id: string;
  type: 
    | 'send_message' 
    | 'delete_data' 
    | 'make_payment' 
    | 'sensitive_form' 
    | 'share_personal_info' 
    | 'irreversible_action'
    | 'blocked_credentials';
  title: string;
  description: string;
  targetApp: string;
  timestamp: string;
  payloadSummary: string;
  isBlockedByPolicy: boolean; // If true (e.g. password, OTP, banking PIN), cannot be approved
  policyReason: string;
  status: 'pending' | 'approved' | 'rejected' | 'blocked_permanently';
}

export type ReactionPresetId = 
  | 'fastest' 
  | 'very_fast' 
  | 'fast' 
  | 'normal' 
  | 'relaxed' 
  | 'slow' 
  | 'very_slow' 
  | 'custom';

export type GestureProfileId = 
  | 'free_fire_gloo'
  | 'free_fire_headshot'
  | 'free_fire_quick_scope'
  | 'casual_gaming'
  | 'precision'
  | 'custom';

export interface ReactionPreset {
  id: ReactionPresetId;
  label: string;
  delayMs: number;
  description: string;
}

export interface PerTaskTiming {
  preset: ReactionPresetId;
  delayMs: number;
  jitterPx: number;
  description: string;
}

export interface TouchSettings {
  // Reaction Presets (100ms - 2000ms & Custom 50-3000ms)
  preset: ReactionPresetId;
  customDelayMs: number;

  // 1. Adjustable Tap Timing
  tapHoldDurationMs: number; // 30ms to 400ms down-up physical contact
  tapPreDelayMs: number;     // 20ms to 500ms pre-tap aim delay

  // 2. Adjustable Swipe Controls
  swipeDurationMs: number;   // 80ms to 1200ms swipe speed
  swipeDistancePx: number;   // 80px to 800px swipe sweep length
  swipeCurveCurvature: number; // 0 to 1 Bézier arc intensity
  freeFireDragCurveShape: 'j_curve' | 'straight_up' | 'rotation_curve';

  // 3. Adjustable Scrolling Controls
  scrollSpeedMs: number;     // 100ms to 1000ms velocity duration
  scrollStepPx: number;      // 100px to 1200px distance per scroll step
  scrollSmoothness: number;  // 1 to 5 interpolation steps

  // 4. Natural Pauses & Configurable Timing Variation
  naturalPauseMinMs: number; // 50ms to 800ms minimum inter-action pause
  naturalPauseMaxMs: number; // 100ms to 2000ms maximum inter-action pause
  timingVariationPct: number; // 0% to 35% randomized human variance

  // 5. Adjustable Typing Intervals
  typingIntervalMs: number;  // 20ms to 300ms delay per keypress
  typingJitterMs: number;    // 0ms to 40ms micro-variance per character

  // 6. Safety & Verified Target Boundaries
  boundaryClampingEnabled: boolean; // Strictly keep touches inside target boundaries
  targetPaddingPx: number;   // Safe inner margin inset (never click outside target)
  jitterEnabled: boolean;
  jitterRadiusPx: number;    // 2px to 20px target landing variance

  // 7. Timing Scope Selection (Where timing applies)
  appliedScopes: {
    tap: boolean;
    swipe: boolean;
    scroll: boolean;
    type: boolean;
    workflows: boolean;
    allActions: boolean;
  };

  // 8. Gesture Profiles
  activeProfile: GestureProfileId;

  // 9. Per-Task Timing Settings
  perTaskSettings: Record<string, PerTaskTiming>;

  // 10. Strict Gaming-Only Lockdown (Never touch non-gaming apps)
  gamingOnlyRestriction: boolean;
  allowedGamingPackages: string[];

  // Free Fire Pro Tuning
  freeFireProTuning: boolean;

  // 11. Humanized Delay Randomizer (Organic thumb-tap jitter for competitive gaming)
  humanizedDelayEnabled: boolean;
  humanizedDelayJitterMs: number; // default ±50ms
  humanizedDelayDistribution: 'organic_gaussian' | 'uniform';
}

export interface TaskStep {
  id: string;
  action: 'tap' | 'swipe' | 'scroll' | 'type' | 'wait' | 'find_element' | 'verify_state' | 'launch_app' | 'inspect_screen';
  target: string;
  description: string;
  estimatedTimeMs: number;
  verification: string;
  riskLevel: 'safe' | 'needs_confirmation' | 'high_risk';
  touchParams?: {
    x?: number;
    y?: number;
    targetX?: number;
    targetY?: number;
    delay?: number;
    text?: string;
  };
  isCompleted?: boolean;
  isCurrent?: boolean;
  isFailed?: boolean;
  completedAt?: string;
  retryCount?: number;
}

export interface AdaptiveStrategy {
  name: string;
  reliabilityScore: number; // 0 - 100
  safetyScore: number; // 0 - 100
  estimatedTime: string;
  timeMs: number;
  batteryImpact: 'very_low' | 'low' | 'medium' | 'high';
  memoryImpactKb: number;
  description: string;
  tradeoffSummary: string;
  isPermitted: boolean;
  isBest?: boolean;
}

export interface ConstraintItem {
  id: string;
  text: string;
  type: 'hard_constraint' | 'safety_boundary' | 'preference';
  isViolated: boolean;
  status: 'enforced' | 'checked' | 'blocked';
  explanation: string;
}

export interface RecoveryRecord {
  id: string;
  timestamp: string;
  stepId: string;
  errorDescription: string;
  recoveryAction: string;
  recoveredStrategy: string;
  result: 'recovered' | 'unrecoverable';
}

export interface UserCorrection {
  id: string;
  timestamp: string;
  originalTarget: string;
  correctedTarget: string;
  learnedRule: string;
  appliedStepId?: string;
}

export interface TaskPlan {
  taskName: string;
  originalCommand: string;
  summary: string;
  languageDetected: string;
  intendedResult: string;
  steps: TaskStep[];
  adaptiveStrategies: AdaptiveStrategy[];
  selectedStrategy: string;
  restrictionsFollowed: string[];
  hardConstraints: ConstraintItem[];
  recoveryHistory: RecoveryRecord[];
  userCorrections: UserCorrection[];
  failedMethodsBlacklist: string[];
  screenDriftDetected?: boolean;
  isOfflineRule?: boolean;
  completionReport?: {
    status: 'success' | 'partial' | 'blocked_by_constraint' | 'failed';
    explanation: string;
    language: string;
    completedStepsCount: number;
    totalStepsCount: number;
  };
}

export interface CallModeState {
  isCallActive: boolean;
  callState: 'IDLE' | 'RINGING' | 'OFFHOOK';
  callerLabel: string;
  callDurationSeconds: number;
  speechMuted: boolean;
  audioPlaybackBlocked: boolean;
  writtenCommandModeActive: boolean;
  detectionAvailable: boolean;
  manualQuietModeFallback: boolean;
  savedVoiceSnapshot: {
    voiceEnabled: boolean;
    speechSpeed: number;
    speechPitch: number;
    quietMode: boolean;
    fastTalkMode: boolean;
  } | null;
}

export interface VoiceSettings {
  voiceEnabled: boolean;
  language: 'hi' | 'en' | 'auto';
  fastTalkMode: boolean;
  quietMode: boolean;
  speechSpeed: number; // 0.8 to 1.5
  speechPitch: number; // 0.8 to 1.2
  isCallMuted: boolean;
  callMode?: CallModeState;
}

export interface IntelligentResumeInspection {
  savedCheckpointStepIndex: number;
  savedTaskName: string;
  screenDetected: string;
  completedSteps: string[];
  changesDetected: string[];
  recalculatedAction: string;
  destructiveActionsBlocked: string[];
  timestamp: string;
  safeNextStepIndex: number;
  confidenceScore: number;
}

export interface FloatingAssistantState {
  status: AssistantStatus;
  x: number;
  y: number;
  isOverlayActive: boolean;
  opacity: number;
  sizePx: number;
  isMinimized: boolean;
  isServiceActive: boolean;
  ongoingNotificationVisible: boolean;
  isExpandedHUD?: boolean;
  lastInspection?: IntelligentResumeInspection | null;
}

export interface LogEntry {
  id: string;
  timestamp: string;
  type: 'info' | 'success' | 'warning' | 'error' | 'security';
  message: string;
  details?: string;
}

export interface WorkflowItem {
  id: string;
  title: string;
  category: 'free_fire' | 'system' | 'custom' | 'learning';
  description: string;
  stepsCount: number;
  steps: TaskStep[];
  lastUsed?: string;
  isRestrictedToFreeFire?: boolean;
}
