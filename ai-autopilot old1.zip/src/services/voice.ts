import { VoiceSettings } from '../types/autopilot';

class VoiceCompanionService {
  private synth: SpeechSynthesis | null = null;
  private isSpeaking = false;
  private recognition: any = null;

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.synth = window.speechSynthesis;
    }
  }

  public isAvailable(): boolean {
    return !!this.synth;
  }

  public isSpeechAllowed(settings: VoiceSettings): boolean {
    if (!this.synth || !settings.voiceEnabled || settings.quietMode || settings.isCallMuted) {
      return false;
    }
    if (settings.callMode && (settings.callMode.isCallActive || settings.callMode.speechMuted || settings.callMode.manualQuietModeFallback)) {
      return false;
    }
    return true;
  }

  public speak(
    text: string,
    settings: VoiceSettings,
    forcedLang?: 'hi' | 'en'
  ) {
    if (!this.synth) {
      return;
    }

    if (!this.isSpeechAllowed(settings)) {
      this.synth.cancel();
      return;
    }

    try {
      this.synth.cancel(); // Stop any pending speech

      // Detect Hindi if contains Devanagari or hinglish words
      const hasDevanagari = /[\u0900-\u097F]/.test(text);
      const isHindi = forcedLang === 'hi' || hasDevanagari || (settings.language === 'hi');

      // Fast Talk mode trims unnecessary explanations
      let speakText = text;
      if (settings.fastTalkMode) {
        // Keep concise
        if (speakText.length > 70) {
          speakText = speakText.slice(0, 70);
        }
      }

      const utterance = new SpeechSynthesisUtterance(speakText);
      utterance.rate = settings.fastTalkMode ? 1.25 : settings.speechSpeed;
      utterance.pitch = settings.speechPitch;

      // Select voice matching language
      const voices = this.synth.getVoices();
      if (isHindi) {
        utterance.lang = 'hi-IN';
        const hindiVoice = voices.find((v) => v.lang.includes('hi') || v.lang.includes('HI'));
        if (hindiVoice) utterance.voice = hindiVoice;
      } else {
        utterance.lang = 'en-US';
        const maleOrNatural = voices.find((v) => v.lang.startsWith('en') && (v.name.includes('Male') || v.name.includes('Natural') || v.name.includes('David') || v.name.includes('Google US')));
        if (maleOrNatural) utterance.voice = maleOrNatural;
      }

      this.synth.speak(utterance);
    } catch (err) {
      console.warn('SpeechSynthesis error:', err);
    }
  }

  public stop() {
    if (this.synth) {
      this.synth.cancel();
    }
  }

  /**
   * Start Speech-to-Text Recognition for voice commands
   */
  public startListening(
    onResult: (transcript: string) => void,
    onError: (err: string) => void,
    onEnd: () => void,
    lang: string = 'en-US'
  ): boolean {
    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRec) {
      onError('Speech Recognition not supported in this browser. Please type your command.');
      return false;
    }

    try {
      if (this.recognition) {
        this.recognition.abort();
      }

      this.recognition = new SpeechRec();
      this.recognition.lang = lang;
      this.recognition.interimResults = false;
      this.recognition.maxAlternatives = 1;

      this.recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        onResult(transcript);
      };

      this.recognition.onerror = (event: any) => {
        onError(event.error || 'Voice input failed');
      };

      this.recognition.onend = () => {
        onEnd();
      };

      this.recognition.start();
      return true;
    } catch (e) {
      onError('Could not start microphone');
      return false;
    }
  }

  public stopListening() {
    if (this.recognition) {
      this.recognition.stop();
    }
  }
}

export const voiceCompanion = new VoiceCompanionService();
