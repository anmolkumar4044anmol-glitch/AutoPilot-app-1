import React from 'react';
import { 
  ShieldAlert, 
  AlertTriangle, 
  Check, 
  X, 
  Lock, 
  CreditCard, 
  MessageSquare, 
  Trash2, 
  FileText, 
  UserCheck, 
  ShieldX,
  Smartphone
} from 'lucide-react';
import { SensitiveActionRequest } from '../types/autopilot';

interface ImportantActionConfirmationModalProps {
  request: SensitiveActionRequest | null;
  isOpen: boolean;
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
}

export const ImportantActionConfirmationModal: React.FC<ImportantActionConfirmationModalProps> = ({
  request,
  isOpen,
  onApprove,
  onReject,
}) => {
  if (!isOpen || !request) return null;

  const getActionIcon = () => {
    switch (request.type) {
      case 'make_payment':
        return <CreditCard className="w-6 h-6 text-rose-400" />;
      case 'send_message':
        return <MessageSquare className="w-6 h-6 text-amber-400" />;
      case 'delete_data':
        return <Trash2 className="w-6 h-6 text-rose-400" />;
      case 'sensitive_form':
        return <FileText className="w-6 h-6 text-cyan-400" />;
      case 'share_personal_info':
        return <UserCheck className="w-6 h-6 text-purple-400" />;
      case 'blocked_credentials':
        return <ShieldX className="w-6 h-6 text-rose-500 animate-pulse" />;
      default:
        return <AlertTriangle className="w-6 h-6 text-amber-400" />;
    }
  };

  const isBlockedPermanently = request.isBlockedByPolicy;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-2xl p-6 shadow-2xl space-y-5 text-slate-100">
        {/* Header Badge */}
        <div className="flex items-start gap-4">
          <div className={`w-12 h-12 rounded-xl flex items-center justify-center border shadow-inner ${
            isBlockedPermanently 
              ? 'bg-rose-950/80 border-rose-600 text-rose-400 ring-2 ring-rose-500/50' 
              : 'bg-amber-950/80 border-amber-600 text-amber-400'
          }`}>
            {getActionIcon()}
          </div>

          <div className="flex-1 space-y-1">
            <div className="flex items-center justify-between">
              <span className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded font-bold border ${
                isBlockedPermanently
                  ? 'bg-rose-950 text-rose-300 border-rose-700'
                  : 'bg-amber-950 text-amber-300 border-amber-700'
              }`}>
                {isBlockedPermanently ? 'CRITICAL POLICY ENFORCEMENT' : 'USER CONFIRMATION REQUIRED'}
              </span>
              <span className="text-[10px] font-mono text-slate-500">{request.timestamp}</span>
            </div>
            <h3 className="text-base font-bold text-white">{request.title}</h3>
            <p className="text-xs text-slate-400">{request.description}</p>
          </div>
        </div>

        {/* Target App & Action Details Ledger */}
        <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
          <div className="flex items-center justify-between text-slate-400">
            <span>Target Application:</span>
            <span className="font-mono text-cyan-300 font-semibold">{request.targetApp}</span>
          </div>
          <div className="flex items-center justify-between text-slate-400">
            <span>Payload / Parameter:</span>
            <span className="font-mono text-slate-200">{request.payloadSummary}</span>
          </div>
          <div className="pt-2 border-t border-slate-800/80 flex items-start gap-2 text-slate-300">
            <Lock className="w-3.5 h-3.5 text-slate-500 shrink-0 mt-0.5" />
            <span className="text-[11px] text-slate-400 leading-relaxed">
              {request.policyReason}
            </span>
          </div>
        </div>

        {/* Permanent Block Warning if Credentials Detected */}
        {isBlockedPermanently ? (
          <div className="p-3.5 rounded-xl bg-rose-950/30 border border-rose-500/40 text-rose-300 text-xs space-y-1.5">
            <div className="font-bold flex items-center gap-1.5 text-rose-400">
              <ShieldAlert className="w-4 h-4" />
              <span>SAFETY MANAGER ZERO-TOLERANCE RULE:</span>
            </div>
            <p className="text-[11px] text-rose-200/90 leading-relaxed">
              AutoPilot is strictly hardcoded to <strong>never automatically enter passwords, OTPs, banking PINs, or payment credentials</strong>. This action is permanently blocked by kernel-level security rules and cannot be bypassed.
            </p>
          </div>
        ) : (
          <div className="p-3 rounded-xl bg-amber-950/20 border border-amber-600/30 text-amber-300 text-xs flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <p className="text-[11px] text-amber-200/90 leading-relaxed">
              AutoPilot will pause and wait for your explicit permission. You always retain complete control of your device.
            </p>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            onClick={() => onReject(request.id)}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors border border-slate-700"
          >
            <X className="w-4 h-4" />
            <span>{isBlockedPermanently ? 'Dismiss & Abort Task' : 'Reject Action'}</span>
          </button>

          {!isBlockedPermanently && (
            <button
              onClick={() => onApprove(request.id)}
              className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-lg shadow-emerald-950/50 transition-colors"
            >
              <Check className="w-4 h-4" />
              <span>Approve &amp; Continue Task</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
