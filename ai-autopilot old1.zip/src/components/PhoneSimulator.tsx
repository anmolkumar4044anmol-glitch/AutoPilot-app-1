import React, { useState, useRef, useEffect } from 'react';
import { 
  AssistantStatus, 
  TaskStep, 
  FloatingAssistantState,
  TouchSettings,
  CallModeState
} from '../types/autopilot';
import { 
  Crosshair, 
  Flame, 
  Shield, 
  Maximize2, 
  Minimize2, 
  Play, 
  Pause, 
  Square, 
  Sparkles, 
  Power, 
  ShieldAlert,
  Bell,
  Home,
  Menu,
  ChevronLeft,
  PhoneCall,
  Send
} from 'lucide-react';
import { FloatingMiniHUD } from './FloatingMiniHUD';
import { OngoingNotificationBar } from './OngoingNotificationBar';

interface PhoneSimulatorProps {
  status: AssistantStatus;
  onStatusChange: (status: AssistantStatus) => void;
  floatingState: FloatingAssistantState;
  onUpdateFloatingState: (state: Partial<FloatingAssistantState>) => void;
  currentStep?: TaskStep;
  touchSettings: TouchSettings;
  activeApp: string;
  onActiveAppChange: (app: string) => void;
  onTogglePauseResume?: () => void;
  onEmergencyStop?: () => void;
  onReopenApp?: () => void;
  onCloseAutoPilot?: () => void;
  onOpenInspector?: () => void;
  isAppMinimized?: boolean;
  onToggleMinimize?: () => void;
  callMode?: CallModeState;
  onExecuteWrittenCommand?: (command: string) => void;
}

export const PhoneSimulator: React.FC<PhoneSimulatorProps> = ({
  status,
  onStatusChange,
  floatingState,
  onUpdateFloatingState,
  currentStep,
  touchSettings,
  activeApp,
  onActiveAppChange,
  onTogglePauseResume,
  onEmergencyStop,
  onReopenApp,
  onCloseAutoPilot,
  onOpenInspector,
  isAppMinimized = false,
  onToggleMinimize,
  callMode,
  onExecuteWrittenCommand,
}) => {
  const [writtenInput, setWrittenInput] = useState('');
  const [isDraggingBubble, setIsDraggingBubble] = useState(false);
  // Default position: top-left of screen (16, 36)
  const [bubblePos, setBubblePos] = useState({ x: 16, y: 36 });
  const [isHUDOpen, setIsHUDOpen] = useState(false);
  const [showNotificationDrawer, setShowNotificationDrawer] = useState(true);
  const [lastTapRipple, setLastTapRipple] = useState<{ x: number; y: number; time: number } | null>(null);
  const [swipeTrace, setSwipeTrace] = useState<{ startX: number; startY: number; endX: number; endY: number } | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Sync bubblePos with floatingState if updated externally
  useEffect(() => {
    if (floatingState.x !== undefined && floatingState.y !== undefined) {
      setBubblePos({ x: floatingState.x, y: floatingState.y });
    }
  }, [floatingState.x, floatingState.y]);

  // When step changes, visualize simulated action on phone screen
  useEffect(() => {
    if (!currentStep || status !== 'GREEN_RUNNING') return;

    if (currentStep.action === 'tap' && currentStep.touchParams?.x && currentStep.touchParams?.y) {
      // Scale down coordinates to fit mockup (standard 1080x2400 to 320x540)
      const mockX = (currentStep.touchParams.x / 1080) * 320;
      const mockY = (currentStep.touchParams.y / 2400) * 540;
      setLastTapRipple({ x: mockX, y: mockY, time: Date.now() });
      setSwipeTrace(null);
    } else if (currentStep.action === 'swipe' && currentStep.touchParams?.x && currentStep.touchParams?.targetX) {
      const sX = (currentStep.touchParams.x / 1080) * 320;
      const sY = ((currentStep.touchParams.y || 400) / 2400) * 540;
      const eX = (currentStep.touchParams.targetX / 1080) * 320;
      const eY = ((currentStep.touchParams.targetY || 400) / 2400) * 540;
      setSwipeTrace({ startX: sX, startY: sY, endX: eX, endY: eY });
      setLastTapRipple(null);
    }
  }, [currentStep, status]);

  // Dragging the small floating assistant indicator
  const handleBubblePointerDown = (e: React.PointerEvent) => {
    e.stopPropagation();
    setIsDraggingBubble(true);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDraggingBubble || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const size = floatingState.sizePx || 42;
    const x = Math.max(8, Math.min(rect.width - size - 8, e.clientX - rect.left - size / 2));
    const y = Math.max(26, Math.min(rect.height - size - 26, e.clientY - rect.top - size / 2));
    setBubblePos({ x, y });
    onUpdateFloatingState({ x, y });
  };

  const handlePointerUp = () => {
    setIsDraggingBubble(false);
  };

  const handleBubbleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    // Toggle mini-HUD drawer
    setIsHUDOpen((prev) => !prev);
  };

  // State styling for the small floating indicator:
  // GREEN: AutoPilot is active and allowed to execute tasks.
  // ORANGE: AutoPilot is paused.
  // RED: Emergency stop activated.
  const getBubbleColor = () => {
    switch (status) {
      case 'GREEN_RUNNING':
        return 'bg-emerald-500 shadow-emerald-500/80 border-emerald-300 ring-2 ring-emerald-400/50 text-white animate-pulse';
      case 'ORANGE_PAUSED':
        return 'bg-amber-500 shadow-amber-500/80 border-amber-300 ring-2 ring-amber-400/40 text-slate-950';
      case 'COOLING_PAUSED':
        return 'bg-cyan-500 shadow-cyan-500/80 border-cyan-300 ring-2 ring-cyan-400/50 text-white animate-pulse';
      case 'RED_EMERGENCY_STOP':
        return 'bg-rose-600 shadow-rose-600/90 border-rose-300 ring-4 ring-rose-500/60 text-white animate-bounce';
      default:
        return 'bg-slate-600 shadow-slate-600/50 border-slate-400 text-white';
    }
  };

  const isServiceActive = floatingState.isServiceActive !== false;

  return (
    <div className="flex flex-col items-center w-full max-w-sm">
      {/* Top Controls: Target App Switcher & Minimization State */}
      <div className="w-full flex items-center justify-between gap-2 mb-2 bg-slate-900/90 p-1.5 rounded-xl border border-slate-800 text-xs">
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => onActiveAppChange('Free Fire India')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition-all ${
              activeApp === 'Free Fire India'
                ? 'bg-amber-600 text-white font-semibold shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Flame className="w-3.5 h-3.5" />
            <span>Free Fire</span>
          </button>
          <button
            onClick={() => onActiveAppChange('System Settings')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition-all ${
              activeApp === 'System Settings'
                ? 'bg-indigo-600 text-white font-semibold shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>Settings</span>
          </button>
        </div>

        {/* Minimize / Maximize Simulator Button */}
        {onToggleMinimize && (
          <button
            onClick={onToggleMinimize}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg font-medium text-[11px] transition-all border ${
              isAppMinimized
                ? 'bg-cyan-950 border-cyan-600 text-cyan-300'
                : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
            }`}
            title={isAppMinimized ? 'Restore AI AutoPilot Main Window' : 'Minimize AI AutoPilot to background'}
          >
            {isAppMinimized ? (
              <>
                <Maximize2 className="w-3 h-3 text-cyan-400" />
                <span>Restored</span>
              </>
            ) : (
              <>
                <Minimize2 className="w-3 h-3 text-slate-400" />
                <span>Minimize</span>
              </>
            )}
          </button>
        )}
      </div>

      {/* Simulated Android Phone Frame */}
      <div 
        ref={containerRef}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        className="relative w-[320px] h-[550px] bg-slate-950 rounded-[40px] border-4 border-slate-700/80 shadow-2xl shadow-cyan-950/40 overflow-hidden select-none"
      >
        {/* Android Punch Hole Camera */}
        <div className="absolute top-2 left-1/2 -translate-x-1/2 w-3.5 h-3.5 bg-black rounded-full border border-slate-800 z-40"></div>

        {/* Android Status Bar */}
        <div className="absolute top-0 left-0 right-0 h-6 px-4 flex items-center justify-between text-[10px] text-slate-300 font-mono z-30 bg-black/50 backdrop-blur-xs">
          <span>10:30 AM</span>
          <div className="flex items-center gap-1.5">
            <button 
              onClick={() => setShowNotificationDrawer((prev) => !prev)}
              className="text-cyan-400 hover:text-cyan-300"
              title="Toggle Ongoing Notification Shade"
            >
              <Bell className="w-3 h-3" />
            </button>
            <span className="text-[9px]">5G</span>
            <span>88%</span>
          </div>
        </div>

        {/* ANDROID SYSTEM PHONE CALL BAR (Privacy Safe: Call audio untouched, AutoPilot speech muted) */}
        {callMode?.isCallActive && (
          <div className="absolute top-6 left-2 right-2 z-36 animate-in slide-in-from-top-1 duration-150">
            <div className="bg-gradient-to-r from-rose-950/95 via-amber-950/95 to-slate-900/95 border border-rose-500/80 rounded-xl p-2 shadow-2xl backdrop-blur-md text-[10px] text-white">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
                  <PhoneCall className="w-3.5 h-3.5 text-rose-400" />
                  <span className="font-bold text-amber-300">
                    Call Active ({Math.floor(callMode.callDurationSeconds / 60)}:{(callMode.callDurationSeconds % 60).toString().padStart(2, '0')})
                  </span>
                </div>
                <span className="text-[9px] bg-rose-900/80 text-rose-200 px-1 rounded font-mono font-bold">
                  AI SPEECH MUTED
                </span>
              </div>
              <div className="flex items-center justify-between text-[9px] text-slate-300 mt-1">
                <span>Phone audio untouched</span>
                <span className="text-amber-300 font-semibold">Written Mode Active</span>
              </div>
            </div>
          </div>
        )}

        {/* SIMULATED ANDROID ONGOING NOTIFICATION (Section 3 Requirement) */}
        {isServiceActive && showNotificationDrawer && (
          <div className={`absolute ${callMode?.isCallActive ? 'top-18' : 'top-6'} left-2 right-2 z-35 animate-in slide-in-from-top-2 duration-150`}>
            <div className="bg-slate-900/95 border border-cyan-800/60 rounded-xl p-2 shadow-xl backdrop-blur-md text-[10px]">
              <div className="flex items-center justify-between border-b border-slate-800 pb-1 mb-1.5">
                <span className="flex items-center gap-1 text-slate-300 font-bold">
                  <Flame className="w-3 h-3 text-amber-500" />
                  <span>AI AutoPilot Notification</span>
                </span>
                <span className={`px-1.5 py-0.2 rounded font-mono font-bold ${
                  status === 'GREEN_RUNNING' ? 'text-emerald-400 bg-emerald-950' :
                  status === 'ORANGE_PAUSED' ? 'text-amber-400 bg-amber-950' :
                  'text-rose-400 bg-rose-950'
                }`}>
                  {status === 'GREEN_RUNNING' ? 'RUNNING' : status === 'ORANGE_PAUSED' ? 'PAUSED' : 'STOP'}
                </span>
              </div>
              <p className="text-slate-300 text-[10px] truncate mb-1.5">
                {currentStep ? currentStep.description : 'Monitoring Free Fire Battleground HUD'}
              </p>
              <div className="flex items-center justify-between gap-1">
                <button
                  onClick={onTogglePauseResume}
                  className="px-2 py-0.5 rounded bg-slate-800 text-white font-medium hover:bg-slate-700"
                >
                  {status === 'GREEN_RUNNING' ? 'Pause' : 'Resume'}
                </button>
                <button
                  onClick={onEmergencyStop}
                  className="px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800 hover:bg-rose-900"
                >
                  Stop
                </button>
                {onReopenApp && (
                  <button
                    onClick={onReopenApp}
                    className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 hover:bg-cyan-900"
                  >
                    Open App
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        {/* SCREEN CONTENT: FREE FIRE OR SETTINGS */}
        {activeApp === 'Free Fire India' ? (
          <div className="w-full h-full pt-6 relative bg-gradient-to-b from-amber-950/40 via-slate-900 to-slate-950 flex flex-col justify-between p-3">
            {/* Game Header */}
            <div className="flex items-center justify-between text-xs mt-3 bg-black/60 p-2 rounded-lg border border-amber-900/30">
              <span className="font-bold text-amber-400 flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 text-amber-500" /> FREE FIRE INDIA
              </span>
              <span className="text-[10px] font-mono text-emerald-400">PING: 22ms</span>
            </div>

            {/* Battleground Crosshair View with Target Boundary Safety Indicator */}
            <div className="relative flex-1 my-2 flex items-center justify-center border border-dashed border-amber-800/40 rounded-xl overflow-hidden bg-slate-950/70">
              <div className="w-12 h-12 rounded-full border border-amber-500/40 flex items-center justify-center">
                <Crosshair className="w-6 h-6 text-amber-400/70" />
              </div>
              <div className="absolute top-2 left-2 text-[9px] font-mono text-emerald-300 bg-emerald-950/90 px-1.5 py-0.5 rounded border border-emerald-800 flex items-center gap-1">
                <Shield className="w-2.5 h-2.5" /> Target Safe ({touchSettings.targetPaddingPx}px Inset)
              </div>
              <div className="absolute bottom-2 left-2 text-[10px] font-mono text-amber-300/80 bg-black/70 px-2 py-0.5 rounded">
                Sensitivity: 98% ({touchSettings.freeFireDragCurveShape === 'j_curve' ? 'J-Curve' : 'Arc'})
              </div>
            </div>

            {/* In-Game Touch HUD Elements */}
            <div className="grid grid-cols-3 gap-2 text-[10px] text-center font-bold">
              {/* Virtual Movement Joystick */}
              <div className="p-2 bg-blue-950/50 border border-blue-600/40 rounded-xl text-blue-300 flex flex-col items-center">
                <span>JOYSTICK</span>
                <span className="text-[8px] text-blue-400">Movement</span>
              </div>

              {/* Gloo Wall Shield Trigger */}
              <div className="p-2 bg-emerald-950/60 border border-emerald-500/50 rounded-xl text-emerald-300 flex flex-col items-center">
                <Shield className="w-3.5 h-3.5 mb-0.5" />
                <span>GLOO WALL</span>
                <span className="text-[8px] text-emerald-400">{touchSettings.customDelayMs}ms Macro</span>
              </div>

              {/* Fire Button */}
              <div className="p-2 bg-rose-950/60 border border-rose-500/50 rounded-xl text-rose-300 flex flex-col items-center">
                <Flame className="w-3.5 h-3.5 mb-0.5" />
                <span>FIRE KEY</span>
                <span className="text-[8px] text-rose-400">Jitter ±{touchSettings.jitterRadiusPx}px</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="w-full h-full pt-6 p-4 flex flex-col justify-between bg-slate-950">
            <div className="space-y-3">
              <div className="flex items-center justify-between mt-2">
                <h3 className="text-sm font-bold text-white">Android Settings</h3>
                <span className="text-[9px] font-mono text-slate-400">System App</span>
              </div>

              {/* STRICT GAMING-ONLY LOCK WARNING */}
              <div className="p-3 rounded-xl bg-amber-950/50 border border-amber-600/60 text-amber-200 space-y-1.5">
                <div className="flex items-center gap-1.5 font-bold text-xs text-amber-300">
                  <ShieldAlert className="w-4 h-4 text-amber-400 flex-shrink-0" />
                  <span>AUTOTOUCH LOCKED</span>
                </div>
                <p className="text-[10px] text-amber-200/90 leading-relaxed">
                  AutoPilot is strictly locked to Free Fire and gaming apps. AutoTouch gestures are <strong>completely deactivated</strong> on Android Settings, Banking, and Messaging apps.
                </p>
                <div className="text-[9px] font-mono text-amber-300/80 bg-black/40 px-2 py-0.5 rounded">
                  Status: NON_GAMING_APP_BLOCKED
                </div>
              </div>

              <div className="space-y-1.5 text-xs">
                <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
                  <span className="text-slate-200">AutoPilot Status</span>
                  <span className="text-[10px] text-amber-400 bg-amber-950 px-2 py-0.5 rounded">Gaming Guard Active</span>
                </div>
                <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
                  <span className="text-slate-200">Accessibility Service</span>
                  <span className="text-[10px] text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded">Armed for Free Fire</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => onActiveAppChange('Free Fire India')}
              className="w-full py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow"
            >
              <Flame className="w-3.5 h-3.5" />
              <span>Switch to Free Fire India</span>
            </button>
          </div>
        )}

        {/* TAP RIPPLE VISUALIZATION */}
        {lastTapRipple && (
          <div
            key={lastTapRipple.time}
            style={{ left: lastTapRipple.x - 20, top: lastTapRipple.y - 20 }}
            className="absolute w-10 h-10 rounded-full border-2 border-cyan-400 bg-cyan-400/30 animate-ping pointer-events-none z-30"
          />
        )}

        {/* SWIPE CURVE VISUALIZATION */}
        {swipeTrace && (
          <svg className="absolute inset-0 w-full h-full pointer-events-none z-30">
            <line
              x1={swipeTrace.startX}
              y1={swipeTrace.startY}
              x2={swipeTrace.endX}
              y2={swipeTrace.endY}
              stroke="#38bdf8"
              strokeWidth="4"
              strokeDasharray="4 2"
              className="animate-pulse"
            />
            <circle cx={swipeTrace.endX} cy={swipeTrace.endY} r="6" fill="#38bdf8" />
          </svg>
        )}

        {/* MOVABLE FLOATING ASSISTANT OVERLAY CONTROL */}
        {/* Specification Requirements:
            - Default position: top-left of screen (16, 36)
            - Small green floating indicator
            - Movable by the user
            - Must not cover the entire screen
            - Must not unnecessarily obstruct other applications
            - STATES:
              GREEN: AutoPilot is active and allowed to execute tasks.
              ORANGE: AutoPilot is paused.
              RED: Emergency stop activated.
        */}
        {isServiceActive ? (
          <div
            onPointerDown={handleBubblePointerDown}
            onClick={handleBubbleClick}
            style={{
              transform: `translate(${bubblePos.x}px, ${bubblePos.y}px)`,
              touchAction: 'none',
              width: `${floatingState.sizePx || 42}px`,
              height: `${floatingState.sizePx || 42}px`,
              opacity: floatingState.opacity || 0.95,
            }}
            className={`absolute top-0 left-0 rounded-full cursor-grab active:cursor-grabbing flex items-center justify-center shadow-2xl border-2 transition-transform duration-75 z-40 select-none ${getBubbleColor()}`}
            title="Draggable Floating Assistant. Tap to open Quick HUD. GREEN=Running, ORANGE=Paused, RED=Stopped."
          >
            {status === 'GREEN_RUNNING' ? (
              <Play className="w-4 h-4 fill-current ml-0.5" />
            ) : status === 'ORANGE_PAUSED' ? (
              <Pause className="w-4 h-4 fill-current" />
            ) : status === 'COOLING_PAUSED' ? (
              <span className="text-[11px] font-bold">❄️</span>
            ) : status === 'RED_EMERGENCY_STOP' ? (
              <Square className="w-4 h-4 fill-current" />
            ) : (
              <Sparkles className="w-4 h-4" />
            )}

            {/* Small State Pill */}
            <span className="absolute -bottom-3.5 bg-black/90 text-[7px] font-mono font-bold text-white px-1 rounded whitespace-nowrap border border-white/20">
              {status === 'GREEN_RUNNING' ? 'ON' : status === 'ORANGE_PAUSED' ? 'PAUSE' : 'STOP'}
            </span>

            {/* Small Call Indicator Badge on Bubble */}
            {callMode?.isCallActive && (
              <span className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-rose-500 text-[9px] font-bold text-white flex items-center justify-center border border-slate-950 shadow-md animate-bounce" title="Call Mode Active (Speech Muted)">
                📞
              </span>
            )}
          </div>
        ) : (
          /* AutoPilot Closed State Notification */
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-xs flex flex-col items-center justify-center p-4 text-center z-40">
            <div className="w-12 h-12 rounded-2xl bg-slate-900 border border-slate-700 flex items-center justify-center text-slate-400 mb-2">
              <Power className="w-6 h-6 text-rose-400" />
            </div>
            <h4 className="text-sm font-bold text-white">AutoPilot Service Closed</h4>
            <p className="text-[11px] text-slate-400 mt-1 max-w-[200px]">
              Foreground service, overlay, and tasks are terminated.
            </p>
            {onTogglePauseResume && (
              <button
                onClick={onTogglePauseResume}
                className="mt-3 px-4 py-1.5 bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl shadow"
              >
                Start AutoPilot
              </button>
            )}
          </div>
        )}

        {/* FLOATING MINI-HUD POPUP (WHEN TAPPED) */}
        {isHUDOpen && isServiceActive && (
          <div 
            style={{
              position: 'absolute',
              top: Math.min(320, Math.max(30, bubblePos.y + 10)),
              left: Math.min(60, Math.max(10, bubblePos.x)),
            }}
            className="z-50"
          >
            <FloatingMiniHUD
              status={status}
              currentStep={currentStep}
              onTogglePauseResume={() => {
                if (onTogglePauseResume) onTogglePauseResume();
              }}
              onEmergencyStop={() => {
                if (onEmergencyStop) onEmergencyStop();
              }}
              onReopenApp={() => {
                setIsHUDOpen(false);
                if (onReopenApp) onReopenApp();
              }}
              onCloseAutoPilot={() => {
                setIsHUDOpen(false);
                if (onCloseAutoPilot) onCloseAutoPilot();
              }}
              onOpenInspector={() => {
                setIsHUDOpen(false);
                if (onOpenInspector) onOpenInspector();
              }}
              onCloseHUD={() => setIsHUDOpen(false)}
              activeApp={activeApp}
              isCallActive={callMode?.isCallActive}
            />
          </div>
        )}

        {/* Current Active Step Banner on screen */}
        {currentStep && status === 'GREEN_RUNNING' && !isHUDOpen && !callMode?.isCallActive && (
          <div className="absolute bottom-8 left-3 right-3 bg-slate-900/95 border border-cyan-500/50 p-2 rounded-xl shadow-xl z-20 backdrop-blur-md">
            <div className="flex items-center justify-between text-[10px] text-cyan-400 font-bold mb-0.5">
              <span>EXECUTING ACTION</span>
              <span className="animate-spin text-cyan-300">⚙</span>
            </div>
            <p className="text-xs text-white font-medium truncate">{currentStep.description}</p>
            <div className="flex items-center justify-between text-[9px] text-slate-400 mt-0.5">
              <span>Target: {currentStep.target}</span>
              <span>Delay: {touchSettings.customDelayMs}ms</span>
            </div>
          </div>
        )}

        {/* SILENT WRITTEN COMMAND INPUT IN CALL MODE */}
        {callMode?.isCallActive && (
          <form 
            onSubmit={(e) => {
              e.preventDefault();
              if (writtenInput.trim() && onExecuteWrittenCommand) {
                onExecuteWrittenCommand(writtenInput.trim());
                setWrittenInput('');
              }
            }}
            className="absolute bottom-8 left-2 right-2 bg-slate-900/95 border border-amber-500/80 p-1.5 rounded-xl shadow-2xl z-35 backdrop-blur-md flex items-center gap-1.5 animate-in slide-in-from-bottom-2 duration-150"
          >
            <input
              type="text"
              value={writtenInput}
              onChange={(e) => setWrittenInput(e.target.value)}
              placeholder="Silent command (e.g. gloo wall macro)..."
              className="flex-1 bg-slate-950 text-white text-[10px] px-2 py-1 rounded-lg border border-slate-700 focus:outline-none focus:border-amber-400 placeholder:text-slate-500"
            />
            <button
              type="submit"
              className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-[10px] flex items-center gap-1 shadow"
            >
              <Send className="w-2.5 h-2.5" />
              <span>Send</span>
            </button>
          </form>
        )}

        {/* Android Navigation Bar (Back, Home, Recents) */}
        <div className="absolute bottom-0 left-0 right-0 h-6 bg-black/70 flex items-center justify-around text-slate-400 z-30">
          <button 
            onClick={() => onActiveAppChange('Free Fire India')}
            className="p-1 hover:text-white"
            title="Back"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
          <button 
            onClick={onToggleMinimize}
            className="w-3 h-3 rounded-full border border-slate-400 hover:border-white"
            title="Android Home Button (Minimizes/Restores AutoPilot)"
          />
          <button 
            onClick={onReopenApp}
            className="w-3 h-3 border border-slate-400 hover:border-white"
            title="Android Recent Apps"
          />
        </div>
      </div>

      <p className="text-[11px] text-slate-400 mt-2 text-center max-w-[320px]">
        Default position: <strong>top-left</strong>. Movable by dragging. Tap bubble for <strong>Mini-HUD</strong> (Pause/Resume, Stop, Reopen).
      </p>
    </div>
  );
};
