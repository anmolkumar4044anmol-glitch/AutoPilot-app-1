import React, { useState, useRef, useEffect } from 'react';
import { 
  Sliders, 
  RotateCcw, 
  Flame, 
  CheckCircle2, 
  Zap, 
  MousePointer2, 
  ShieldCheck, 
  AlertCircle, 
  Play, 
  Crosshair, 
  Sparkles, 
  ChevronRight, 
  Smartphone, 
  Layers, 
  Lock, 
  Clock, 
  Volume2, 
  Move, 
  Compass, 
  Type, 
  HelpCircle,
  Save,
  Check
} from 'lucide-react';
import { 
  TouchSettings, 
  ReactionPreset, 
  ReactionPresetId, 
  GestureProfileId 
} from '../../types/autopilot';
import { 
  REACTION_PRESETS, 
  GESTURE_PROFILES, 
  DEFAULT_TOUCH_SETTINGS,
  LOCAL_STORAGE_TOUCH_KEY,
  calculateHumanizedDelay
} from '../../data/defaultTouchSettings';

interface HumanTouchTabProps {
  settings: TouchSettings;
  onUpdateSettings: (newSettings: Partial<TouchSettings>) => void;
  onResetSettings: () => void;
}

export const HumanTouchTab: React.FC<HumanTouchTabProps> = ({
  settings,
  onUpdateSettings,
  onResetSettings,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'timing' | 'gestures' | 'profiles' | 'per_task' | 'safety'>('timing');
  const [previewLog, setPreviewLog] = useState<string>('Ready. Click any simulation button below or tap inside the target box.');
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [saveToast, setSaveToast] = useState<boolean>(false);
  const [simulatedTypingText, setSimulatedTypingText] = useState<string>('');
  
  // Canvas telemetry
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [touchHistory, setTouchHistory] = useState<Array<{
    type: 'tap' | 'swipe' | 'scroll';
    targetX: number;
    targetY: number;
    actualX: number;
    actualY: number;
    endX?: number;
    endY?: number;
    curveOffset?: number;
    inBounds: boolean;
    timestamp: number;
  }>>([]);

  // Verified target box coordinates inside canvas (340x200 canvas)
  const targetBox = {
    x: 40,
    y: 35,
    w: 260,
    h: 130,
    label: 'Verified Target Button HUD (e.g., Free Fire Gloo Wall / Fire)',
  };

  // Clamp touch point to verified target box minus padding
  const calculateClampedLanding = (tx: number, ty: number): { x: number; y: number; inBounds: boolean } => {
    let jX = tx;
    let jY = ty;

    if (settings.jitterEnabled) {
      const radius = settings.jitterRadiusPx;
      const angle = Math.random() * Math.PI * 2;
      const distance = Math.random() * radius;
      jX += Math.cos(angle) * distance;
      jY += Math.sin(angle) * distance;
    }

    if (settings.boundaryClampingEnabled) {
      const pad = settings.targetPaddingPx;
      const minX = targetBox.x + pad;
      const maxX = targetBox.x + targetBox.w - pad;
      const minY = targetBox.y + pad;
      const maxY = targetBox.y + targetBox.h - pad;

      jX = Math.max(minX, Math.min(maxX, jX));
      jY = Math.max(minY, Math.min(maxY, jY));
    }

    const inBounds = (
      jX >= targetBox.x && 
      jX <= targetBox.x + targetBox.w && 
      jY >= targetBox.y && 
      jY <= targetBox.y + targetBox.h
    );

    return { x: jX, y: jY, inBounds };
  };

  // Redraw canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // 1. Draw subtle tactical grid
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 1;
    for (let x = 0; x < canvas.width; x += 20) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }
    for (let y = 0; y < canvas.height; y += 20) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }

    // 2. Draw Target Boundary Outer Box
    ctx.fillStyle = 'rgba(6, 78, 59, 0.15)';
    ctx.fillRect(targetBox.x, targetBox.y, targetBox.w, targetBox.h);

    ctx.strokeStyle = '#10b981';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([6, 3]);
    ctx.strokeRect(targetBox.x, targetBox.y, targetBox.w, targetBox.h);
    ctx.setLineDash([]);

    // 3. Draw Safe Inner Padding Inset (never touched zone outside this boundary)
    if (settings.boundaryClampingEnabled) {
      const pad = settings.targetPaddingPx;
      ctx.strokeStyle = 'rgba(52, 211, 153, 0.4)';
      ctx.lineWidth = 1;
      ctx.setLineDash([2, 2]);
      ctx.strokeRect(targetBox.x + pad, targetBox.y + pad, targetBox.w - pad * 2, targetBox.h - pad * 2);
      ctx.setLineDash([]);
    }

    // Target Label
    ctx.fillStyle = '#10b981';
    ctx.font = '10px Inter, sans-serif';
    ctx.fillText('VERIFIED TARGET BOUNDS (100% CONTAINMENT)', targetBox.x + 8, targetBox.y + 16);
    ctx.fillStyle = '#6ee7b7';
    ctx.font = '9px monospace';
    ctx.fillText(`Safe Inset Padding: ${settings.targetPaddingPx}px | Clamping: ACTIVE`, targetBox.x + 8, targetBox.y + 28);

    // 4. Render Touch Trails & Bézier Swipes
    touchHistory.forEach((item, index) => {
      const isLatest = index === touchHistory.length - 1;

      if (item.type === 'tap') {
        // True planned coordinate point
        ctx.beginPath();
        ctx.arc(item.targetX, item.targetY, 3, 0, Math.PI * 2);
        ctx.fillStyle = '#94a3b8';
        ctx.fill();

        // Humanized Landing Point
        ctx.beginPath();
        ctx.arc(item.actualX, item.actualY, isLatest ? 9 : 6, 0, Math.PI * 2);
        ctx.fillStyle = item.inBounds ? (isLatest ? '#06b6d4' : '#0284c7') : '#ef4444';
        ctx.fill();
        ctx.strokeStyle = item.inBounds ? '#38bdf8' : '#f87171';
        ctx.lineWidth = 2;
        ctx.stroke();

        // Target-to-actual connector
        ctx.beginPath();
        ctx.moveTo(item.targetX, item.targetY);
        ctx.lineTo(item.actualX, item.actualY);
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 1;
        ctx.stroke();

        if (isLatest) {
          // Pulse shockwave
          ctx.beginPath();
          ctx.arc(item.actualX, item.actualY, 18, 0, Math.PI * 2);
          ctx.strokeStyle = 'rgba(6, 182, 212, 0.4)';
          ctx.lineWidth = 2;
          ctx.stroke();
        }
      } else if (item.type === 'swipe' && item.endX && item.endY) {
        // Draw Bézier trajectory
        ctx.beginPath();
        ctx.moveTo(item.actualX, item.actualY);

        const curveIntensity = (item.curveOffset ?? 0.35) * 50;
        let cpx = (item.actualX + item.endX) / 2;
        let cpy = (item.actualY + item.endY) / 2;

        if (settings.freeFireDragCurveShape === 'j_curve') {
          // Free Fire J-curve: dips slightly before upward drag
          cpx += curveIntensity * 0.8;
          cpy += curveIntensity * 0.4;
        } else if (settings.freeFireDragCurveShape === 'rotation_curve') {
          cpx -= curveIntensity;
          cpy -= curveIntensity * 0.5;
        } else {
          // Straight up slight thumb deflection
          cpx += curveIntensity * 0.3;
        }

        ctx.quadraticCurveTo(cpx, cpy, item.endX, item.endY);
        ctx.strokeStyle = isLatest ? '#10b981' : '#059669';
        ctx.lineWidth = 3;
        ctx.stroke();

        // Start & End markers
        ctx.beginPath();
        ctx.arc(item.actualX, item.actualY, 5, 0, Math.PI * 2);
        ctx.fillStyle = '#06b6d4';
        ctx.fill();

        ctx.beginPath();
        ctx.arc(item.endX, item.endY, 6, 0, Math.PI * 2);
        ctx.fillStyle = '#f59e0b';
        ctx.fill();
      }
    });
  }, [touchHistory, settings]);

  // Click on canvas
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const tx = (e.clientX - rect.left) * scaleX;
    const ty = (e.clientY - rect.top) * scaleY;

    const { x, y, inBounds } = calculateClampedLanding(tx, ty);

    const newTouch = {
      type: 'tap' as const,
      targetX: Math.round(tx),
      targetY: Math.round(ty),
      actualX: Math.round(x),
      actualY: Math.round(y),
      inBounds,
      timestamp: Date.now(),
    };

    setTouchHistory((prev) => [...prev.slice(-5), newTouch]);
    setPreviewLog(
      `Dispatched Tap at (${newTouch.targetX}, ${newTouch.targetY}) -> Clamped Landing (${newTouch.actualX}, ${newTouch.actualY}) | Boundary Status: ${inBounds ? 'SAFE (Inside Target)' : 'OUTSIDE'} | Reaction: ${settings.customDelayMs}ms`
    );
  };

  // Simulate Actions
  const simulateTap = () => {
    if (isSimulating) return;
    setIsSimulating(true);
    const { actualDelayMs, jitterMs } = calculateHumanizedDelay(settings.customDelayMs, settings);
    const jitterText = settings.humanizedDelayEnabled
      ? ` (Humanized Jitter: ${jitterMs >= 0 ? '+' : ''}${jitterMs}ms -> ${actualDelayMs}ms)`
      : ` (Delay: ${settings.customDelayMs}ms)`;
    setPreviewLog(`Aiming at Target Center${jitterText}...`);

    setTimeout(() => {
      const centerX = targetBox.x + targetBox.w / 2;
      const centerY = targetBox.y + targetBox.h / 2;
      const { x, y, inBounds } = calculateClampedLanding(centerX, centerY);

      setTouchHistory((prev) => [
        ...prev.slice(-5),
        {
          type: 'tap',
          targetX: Math.round(centerX),
          targetY: Math.round(centerY),
          actualX: Math.round(x),
          actualY: Math.round(y),
          inBounds,
          timestamp: Date.now(),
        },
      ]);

      setPreviewLog(
        `✓ Tap Executed in ${actualDelayMs}ms (Jitter: ${jitterMs >= 0 ? '+' : ''}${jitterMs}ms): Hold ${settings.tapHoldDurationMs}ms, Pre-delay ${settings.tapPreDelayMs}ms, Landing (${Math.round(x)}, ${Math.round(y)}) strictly within target boundaries.`
      );
      setIsSimulating(false);
    }, Math.max(60, actualDelayMs));
  };

  const simulateSwipe = () => {
    if (isSimulating) return;
    setIsSimulating(true);
    const { actualDelayMs, jitterMs } = calculateHumanizedDelay(settings.customDelayMs, settings);
    setPreviewLog(`Initiating Free Fire ${settings.freeFireDragCurveShape.toUpperCase()} Drag Sweep (~${actualDelayMs}ms, jitter: ${jitterMs >= 0 ? '+' : ''}${jitterMs}ms)...`);

    setTimeout(() => {
      const startX = targetBox.x + targetBox.w * 0.3;
      const startY = targetBox.y + targetBox.h * 0.75;
      const endX = targetBox.x + targetBox.w * 0.7;
      const endY = targetBox.y + targetBox.h * 0.25;

      const { x: sx, y: sy, inBounds } = calculateClampedLanding(startX, startY);
      const { x: ex, y: ey } = calculateClampedLanding(endX, endY);

      setTouchHistory((prev) => [
        ...prev.slice(-5),
        {
          type: 'swipe',
          targetX: Math.round(startX),
          targetY: Math.round(startY),
          actualX: Math.round(sx),
          actualY: Math.round(sy),
          endX: Math.round(ex),
          endY: Math.round(ey),
          curveOffset: settings.swipeCurveCurvature,
          inBounds,
          timestamp: Date.now(),
        },
      ]);

      setPreviewLog(
        `✓ Swipe Completed in ${actualDelayMs}ms: Duration ${settings.swipeDurationMs}ms, Distance ${settings.swipeDistancePx}px, Shape: ${settings.freeFireDragCurveShape}`
      );
      setIsSimulating(false);
    }, Math.max(80, actualDelayMs));
  };

  const simulateTyping = () => {
    if (isSimulating) return;
    setIsSimulating(true);
    setSimulatedTypingText('');
    setPreviewLog('Simulating human keyboard input with natural keystroke timing...');

    const sample = 'FREE_FIRE_BOOYAH_MACRO';
    let idx = 0;

    const typeNextChar = () => {
      if (idx < sample.length) {
        setSimulatedTypingText((prev) => prev + sample[idx]);
        idx++;
        // Apply key interval + jitter variation
        const jitter = (Math.random() * 2 - 1) * settings.typingJitterMs;
        const delay = Math.max(20, settings.typingIntervalMs + jitter);
        setTimeout(typeNextChar, delay);
      } else {
        setIsSimulating(false);
        setPreviewLog(`✓ Keystroke stream finished: ${sample.length} characters dispatched at ${settings.typingIntervalMs}ms/key with ±${settings.typingJitterMs}ms jitter.`);
      }
    };

    setTimeout(typeNextChar, 150);
  };

  const simulateGlooWallMacro = () => {
    if (isSimulating) return;
    setIsSimulating(true);
    setPreviewLog('⚡ Free Fire Pro Gloo Wall Sequence Started (Step 1/3: Tap Gloo Wall)...');

    const step1X = targetBox.x + 50;
    const step1Y = targetBox.y + 70;
    const p1 = calculateClampedLanding(step1X, step1Y);

    setTouchHistory((prev) => [
      ...prev.slice(-4),
      {
        type: 'tap',
        targetX: step1X,
        targetY: step1Y,
        actualX: p1.x,
        actualY: p1.y,
        inBounds: p1.inBounds,
        timestamp: Date.now(),
      },
    ]);

    // Natural pause before drag down
    const pause1 = Math.max(50, settings.naturalPauseMinMs);
    setTimeout(() => {
      setPreviewLog('⚡ Free Fire Pro Gloo Wall (Step 2/3: Drag Camera Down to Feet)...');
      const startX = targetBox.x + targetBox.w * 0.5;
      const startY = targetBox.y + 40;
      const endX = targetBox.x + targetBox.w * 0.5;
      const endY = targetBox.y + targetBox.h - 20;

      setTouchHistory((prev) => [
        ...prev.slice(-4),
        {
          type: 'swipe',
          targetX: startX,
          targetY: startY,
          actualX: startX,
          actualY: startY,
          endX,
          endY,
          curveOffset: 0.15,
          inBounds: true,
          timestamp: Date.now(),
        },
      ]);

      // Natural pause before final deploy
      setTimeout(() => {
        setPreviewLog('⚡ Free Fire Pro Gloo Wall (Step 3/3: Deploy Wall & Crouch Trigger)...');
        const deployX = targetBox.x + targetBox.w - 50;
        const deployY = targetBox.y + targetBox.h - 30;
        const p3 = calculateClampedLanding(deployX, deployY);

        setTouchHistory((prev) => [
          ...prev.slice(-4),
          {
            type: 'tap',
            targetX: deployX,
            targetY: deployY,
            actualX: p3.x,
            actualY: p3.y,
            inBounds: p3.inBounds,
            timestamp: Date.now(),
          },
        ]);

        setPreviewLog('✓ Free Fire Instant Gloo Wall deployed flawlessly in 280ms total with natural human thumb arcs!');
        setIsSimulating(false);
      }, settings.naturalPauseMinMs + 30);
    }, pause1);
  };

  const handleApplyPreset = (preset: ReactionPreset) => {
    onUpdateSettings({
      preset: preset.id,
      customDelayMs: preset.delayMs,
    });
    setPreviewLog(`Preset Applied: ${preset.label} -> Base delay set to ${preset.delayMs}ms`);
  };

  const handleApplyProfile = (profile: typeof GESTURE_PROFILES[0]) => {
    onUpdateSettings({
      activeProfile: profile.id,
      ...profile.settings,
    });
    setPreviewLog(`✓ Loaded Profile: "${profile.name}" (${profile.badge})`);
    triggerSaveToast();
  };

  const triggerSaveToast = () => {
    setSaveToast(true);
    setTimeout(() => setSaveToast(false), 2400);
  };

  // Toggle timing scope
  const handleToggleScope = (scopeKey: keyof TouchSettings['appliedScopes']) => {
    if (scopeKey === 'allActions') {
      const nextVal = !settings.appliedScopes.allActions;
      onUpdateSettings({
        appliedScopes: {
          tap: nextVal,
          swipe: nextVal,
          scroll: nextVal,
          type: nextVal,
          workflows: nextVal,
          allActions: nextVal,
        },
      });
    } else {
      const updated = {
        ...settings.appliedScopes,
        [scopeKey]: !settings.appliedScopes[scopeKey],
      };
      // If any is false, allActions is false
      updated.allActions = updated.tap && updated.swipe && updated.scroll && updated.type && updated.workflows;
      onUpdateSettings({ appliedScopes: updated });
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Main Hero Header */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-cyan-950/60 border border-slate-800 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2 py-0.5 rounded-full bg-cyan-900/60 text-cyan-300 border border-cyan-700/60 text-[10px] font-semibold tracking-wider uppercase">
              Tactile Engine v2.6
            </span>
            <span className="px-2 py-0.5 rounded-full bg-amber-950/60 text-amber-300 border border-amber-800/60 text-[10px] font-semibold flex items-center gap-1">
              <Flame className="w-3 h-3 text-amber-400" />
              Free Fire Esports Calibrated
            </span>
            <span className="px-2 py-0.5 rounded-full bg-emerald-950/60 text-emerald-300 border border-emerald-800/60 text-[10px] font-semibold flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-emerald-400" />
              Gaming-Only Locked
            </span>
          </div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Sliders className="w-5 h-5 text-cyan-400" />
            <span>Dedicated Human Touch Simulator Settings</span>
          </h3>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Replaces rigid robotic taps with organic finger dynamics: adjustable reaction latencies, Bézier thumb arcs, target boundary clipping, natural inter-action pauses, and strict gaming-only enforcement.
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => {
              triggerSaveToast();
            }}
            className="px-3.5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow transition-all active:scale-95"
          >
            {saveToast ? <Check className="w-4 h-4 text-emerald-200" /> : <Save className="w-4 h-4" />}
            <span>{saveToast ? 'Settings Saved' : 'Save & Persist'}</span>
          </button>

          <button
            onClick={() => {
              onResetSettings();
              setPreviewLog('Settings restored to factory defaults.');
              triggerSaveToast();
            }}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium flex items-center gap-1.5 border border-slate-700 transition-all"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset to Default</span>
          </button>
        </div>
      </div>

      {/* STRICT GAMING APPS ONLY ENFORCEMENT BANNER (User's core requirement) */}
      <div className="p-4 rounded-xl bg-amber-950/30 border border-amber-600/40 text-amber-200 text-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-lg">
        <div className="flex items-start gap-2.5">
          <ShieldCheck className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
          <div>
            <div className="font-bold text-amber-300 flex items-center gap-2">
              <span>STRICT GAMING APPS & WEB GAMES RESTRICTION: ACTIVE</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-900/60 border border-amber-700 text-amber-200 font-mono">
                Hard Boundary Locked
              </span>
            </div>
            <p className="text-[11px] text-amber-300/80 mt-0.5">
              AutoTouch is exclusively authorized to run inside <strong>Free Fire (India, MAX, Global)</strong>, gaming apps, and gaming web pages. It is <strong>100% hard-blocked</strong> from activating on banking, UPI payments, messaging, or non-gaming system apps.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-shrink-0">
          <label className="flex items-center gap-2 text-xs font-semibold cursor-pointer select-none">
            <input
              type="checkbox"
              checked={settings.gamingOnlyRestriction}
              onChange={(e) => onUpdateSettings({ gamingOnlyRestriction: e.target.checked })}
              className="rounded accent-amber-500 w-4 h-4 cursor-pointer"
            />
            <span className="text-amber-100">Enforce Game-Only Whitelist</span>
          </label>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2 overflow-x-auto text-xs">
        <button
          onClick={() => setActiveSubTab('timing')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${
            activeSubTab === 'timing'
              ? 'bg-cyan-950 text-cyan-300 border border-cyan-700 font-semibold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          <span>Reaction Presets & Timing</span>
        </button>

        <button
          onClick={() => setActiveSubTab('gestures')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${
            activeSubTab === 'gestures'
              ? 'bg-cyan-950 text-cyan-300 border border-cyan-700 font-semibold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Move className="w-3.5 h-3.5" />
          <span>Tap, Swipe, Scroll & Typing</span>
        </button>

        <button
          onClick={() => setActiveSubTab('profiles')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${
            activeSubTab === 'profiles'
              ? 'bg-cyan-950 text-cyan-300 border border-cyan-700 font-semibold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Flame className="w-3.5 h-3.5" />
          <span>Gesture Profiles</span>
        </button>

        <button
          onClick={() => setActiveSubTab('per_task')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${
            activeSubTab === 'per_task'
              ? 'bg-cyan-950 text-cyan-300 border border-cyan-700 font-semibold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Per-Task Timing Settings</span>
        </button>

        <button
          onClick={() => setActiveSubTab('safety')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${
            activeSubTab === 'safety'
              ? 'bg-cyan-950 text-cyan-300 border border-cyan-700 font-semibold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>Target Boundary & Safety</span>
        </button>
      </div>

      {/* Interactive Live Tactile Test Pad & Preview Canvas (Visible at top of settings) */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <Crosshair className="w-4 h-4 text-cyan-400" />
              <span>Interactive Live Preview & Tactile Pad</span>
            </h4>
            <p className="text-xs text-slate-400">
              Visualizes real-time touch landing, verified target boundaries, Bézier curves, and natural delays.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono text-cyan-400 bg-cyan-950/80 px-2 py-1 rounded border border-cyan-800">
              Active Latency: {settings.customDelayMs}ms
            </span>
            <button
              onClick={() => setTouchHistory([])}
              className="text-[11px] text-slate-400 hover:text-slate-200 underline px-2 py-1"
            >
              Clear Canvas
            </button>
          </div>
        </div>

        {/* Canvas & Simulation Buttons Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-center">
          <div className="lg:col-span-8">
            <canvas
              ref={canvasRef}
              width={340}
              height={190}
              onClick={handleCanvasClick}
              className="w-full h-[190px] bg-slate-950 rounded-xl border border-slate-800 cursor-crosshair shadow-inner"
              title="Click anywhere inside the box to test verified target boundary clamping"
            />
          </div>

          <div className="lg:col-span-4 flex flex-col gap-2">
            <button
              onClick={simulateTap}
              disabled={isSimulating}
              className="w-full py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-between transition-all disabled:opacity-50"
            >
              <span className="flex items-center gap-1.5">
                <MousePointer2 className="w-3.5 h-3.5 text-cyan-400" />
                Simulate Tap
              </span>
              <span className="text-[10px] font-mono text-cyan-300">{settings.tapHoldDurationMs}ms</span>
            </button>

            <button
              onClick={simulateSwipe}
              disabled={isSimulating}
              className="w-full py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-between transition-all disabled:opacity-50"
            >
              <span className="flex items-center gap-1.5">
                <Move className="w-3.5 h-3.5 text-emerald-400" />
                Simulate {settings.freeFireDragCurveShape === 'j_curve' ? 'J-Curve' : 'Drag'}
              </span>
              <span className="text-[10px] font-mono text-emerald-300">{settings.swipeDurationMs}ms</span>
            </button>

            <button
              onClick={simulateTyping}
              disabled={isSimulating}
              className="w-full py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-between transition-all disabled:opacity-50"
            >
              <span className="flex items-center gap-1.5">
                <Type className="w-3.5 h-3.5 text-amber-400" />
                Simulate Typing
              </span>
              <span className="text-[10px] font-mono text-amber-300">{settings.typingIntervalMs}ms/key</span>
            </button>

            <button
              onClick={simulateGlooWallMacro}
              disabled={isSimulating}
              className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white text-xs font-bold flex items-center justify-between shadow transition-all disabled:opacity-50"
            >
              <span className="flex items-center gap-1.5">
                <Flame className="w-3.5 h-3.5" />
                Simulate Gloo Wall Combo
              </span>
              <span className="text-[10px] font-mono text-amber-200">Multi-step</span>
            </button>
          </div>
        </div>

        {/* Real-time Telemetry Status Bar */}
        <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-[11px] font-mono">
          <div className="text-cyan-300 truncate max-w-xl">
            <span className="text-slate-500 mr-2">LOG:</span>
            {previewLog}
          </div>
          <div className="flex items-center gap-3 text-slate-400 flex-shrink-0">
            <span className="flex items-center gap-1 text-emerald-400">
              <CheckCircle2 className="w-3 h-3" />
              Target Clamping: ON
            </span>
            <span className="flex items-center gap-1 text-amber-400">
              <Lock className="w-3 h-3" />
              Game Sandbox: ON
            </span>
          </div>
        </div>

        {/* Typing Preview Display if typing is simulated */}
        {simulatedTypingText && (
          <div className="p-2.5 rounded-lg bg-slate-950 border border-amber-900/40 flex items-center gap-2 text-xs font-mono">
            <span className="text-amber-400 font-bold">Key Buffer:</span>
            <span className="text-slate-100 bg-slate-900 px-2 py-0.5 rounded border border-slate-700 tracking-wider">
              {simulatedTypingText}
              <span className="animate-pulse">|</span>
            </span>
          </div>
        )}
      </div>

      {/* TAB 1: REACTION TIME PRESETS & TIMING SCOPES */}
      {activeSubTab === 'timing' && (
        <div className="space-y-6">
          {/* Reaction Time Presets (All 8 presets strictly as requested) */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <Zap className="w-4 h-4 text-cyan-400" />
                  <span>Reaction Time Presets (8 Presets)</span>
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  Select a standardized reaction latency or use custom 50–3000 ms tuning.
                </p>
              </div>
              <span className="text-xs font-mono font-bold text-cyan-400 bg-cyan-950 px-2.5 py-1 rounded-lg border border-cyan-800">
                Selected: {settings.customDelayMs} ms
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {REACTION_PRESETS.map((preset) => {
                const isSelected = settings.preset === preset.id;
                return (
                  <button
                    key={preset.id}
                    onClick={() => handleApplyPreset(preset)}
                    className={`p-3.5 rounded-xl border text-left transition-all ${
                      isSelected
                        ? 'bg-cyan-950/80 border-cyan-500 text-white shadow-lg shadow-cyan-950/50 ring-1 ring-cyan-500'
                        : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white">{preset.label}</span>
                      {isSelected && <Zap className="w-3.5 h-3.5 text-cyan-400 fill-current" />}
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1.5 leading-relaxed line-clamp-2">
                      {preset.description}
                    </p>
                  </button>
                );
              })}
            </div>

            {/* Custom Slider (50–3000 ms) */}
            <div className="mt-4 pt-4 border-t border-slate-800/80 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300 font-medium">
                  Custom Reaction Delay Slider (50 ms – 3000 ms):
                </span>
                <span className="text-cyan-400 font-mono font-bold text-sm bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                  {settings.customDelayMs} ms
                </span>
              </div>
              <input
                type="range"
                min="50"
                max="3000"
                step="25"
                value={settings.customDelayMs}
                onChange={(e) =>
                  onUpdateSettings({
                    customDelayMs: Number(e.target.value),
                    preset: 'custom',
                  })
                }
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-500"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>50ms (Super reflex)</span>
                <span>500ms</span>
                <span>1000ms</span>
                <span>2000ms</span>
                <span>3000ms (Maximum deliberate)</span>
              </div>
            </div>
          </div>

          {/* HUMANIZED DELAY RANDOMIZER (±50ms Organic Thumb-Tap Jitter) */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-purple-400" />
                  <span>Humanized Delay Randomizer (Organic Thumb Jitter)</span>
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  Introduces subtle, randomized jitters (±50ms) to touch execution intervals to mimic organic thumb behavior in competitive gaming.
                </p>
              </div>

              <label className="flex items-center gap-2 text-xs font-semibold cursor-pointer select-none bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800">
                <input
                  type="checkbox"
                  checked={settings.humanizedDelayEnabled}
                  onChange={(e) => onUpdateSettings({ humanizedDelayEnabled: e.target.checked })}
                  className="rounded accent-purple-500 w-4 h-4 cursor-pointer"
                />
                <span className={settings.humanizedDelayEnabled ? 'text-purple-300 font-bold' : 'text-slate-400'}>
                  {settings.humanizedDelayEnabled ? 'Randomizer Active' : 'Disabled (Fixed Delay)'}
                </span>
              </label>
            </div>

            {settings.humanizedDelayEnabled && (
              <div className="space-y-4 pt-2 border-t border-slate-800/80">
                {/* Jitter range slider */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-300 font-medium">Jitter Range Amplitude:</span>
                    <span className="text-purple-400 font-mono font-bold bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                      ±{settings.humanizedDelayJitterMs} ms
                    </span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="150"
                    step="5"
                    value={settings.humanizedDelayJitterMs}
                    onChange={(e) => onUpdateSettings({ humanizedDelayJitterMs: Number(e.target.value) })}
                    className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-purple-500"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>±10ms (Imperceptible)</span>
                    <span className="text-purple-400 font-semibold">±50ms (Esport Pro Standard)</span>
                    <span>±100ms</span>
                    <span>±150ms (Casual)</span>
                  </div>
                </div>

                {/* Distribution selector */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <button
                    onClick={() => onUpdateSettings({ humanizedDelayDistribution: 'organic_gaussian' })}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      settings.humanizedDelayDistribution === 'organic_gaussian'
                        ? 'bg-purple-950/60 border-purple-500 text-white shadow-lg ring-1 ring-purple-500'
                        : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs font-bold text-white mb-1">
                      <span>Organic Gaussian (Bell Curve)</span>
                      {settings.humanizedDelayDistribution === 'organic_gaussian' && (
                        <Check className="w-3.5 h-3.5 text-purple-400" />
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Real biological thumb latency modeled via Box-Muller transform: ~70% cluster within ±20ms with natural rare micro-pauses.
                    </p>
                  </button>

                  <button
                    onClick={() => onUpdateSettings({ humanizedDelayDistribution: 'uniform' })}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      settings.humanizedDelayDistribution === 'uniform'
                        ? 'bg-purple-950/60 border-purple-500 text-white shadow-lg ring-1 ring-purple-500'
                        : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs font-bold text-white mb-1">
                      <span>Uniform Linear Range</span>
                      {settings.humanizedDelayDistribution === 'uniform' && (
                        <Check className="w-3.5 h-3.5 text-purple-400" />
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Flat random distribution across the entire ±{settings.humanizedDelayJitterMs}ms window.
                    </p>
                  </button>
                </div>

                {/* Live Jitter Tester */}
                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                  <div>
                    <span className="font-bold text-slate-200">Test Organic Jitter Sequence:</span>
                    <p className="text-[11px] text-slate-400">Generate 5 consecutive sample intervals based on current {settings.customDelayMs}ms base.</p>
                  </div>
                  <button
                    onClick={() => {
                      const samples = Array.from({ length: 5 }, () => calculateHumanizedDelay(settings.customDelayMs, settings));
                      const sampleStr = samples.map(s => `${s.actualDelayMs}ms (${s.jitterMs >= 0 ? '+' : ''}${s.jitterMs})`).join('  |  ');
                      setPreviewLog(`Jitter Samples [${settings.humanizedDelayDistribution}]: ${sampleStr}`);
                    }}
                    className="px-3 py-1.5 rounded-lg bg-purple-900/60 hover:bg-purple-800 text-purple-200 font-mono text-[11px] border border-purple-700 transition-colors whitespace-nowrap self-start sm:self-auto"
                  >
                    Sample Intervals
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* ALLOW USER TO APPLY TIMING TO (As required in prompt) */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <Layers className="w-4 h-4 text-emerald-400" />
                  <span>Apply Timing To Actions</span>
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  Select which automated action types will observe this reaction timing configuration.
                </p>
              </div>

              <button
                onClick={() => handleToggleScope('allActions')}
                className={`text-xs px-3 py-1 rounded-lg font-semibold border transition-all ${
                  settings.appliedScopes.allActions
                    ? 'bg-emerald-950 text-emerald-300 border-emerald-700'
                    : 'bg-slate-800 text-slate-400 border-slate-700'
                }`}
              >
                {settings.appliedScopes.allActions ? 'All Actions Selected' : 'Select All'}
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              {[
                { key: 'tap' as const, label: 'Tap', icon: MousePointer2, desc: 'Buttons & HUD clicks' },
                { key: 'swipe' as const, label: 'Swipe', icon: Move, desc: 'Aim drags & gestures' },
                { key: 'scroll' as const, label: 'Scroll', icon: Compass, desc: 'Lists & bag browsing' },
                { key: 'type' as const, label: 'Typing', icon: Type, desc: 'Chat & text input' },
                { key: 'workflows' as const, label: 'Multi-Step Workflows', icon: Flame, desc: 'Chained Free Fire macros' },
                { key: 'allActions' as const, label: 'All Actions', icon: CheckCircle2, desc: 'Global master enforcement' },
              ].map((scope) => {
                const Icon = scope.icon;
                const isChecked = settings.appliedScopes[scope.key];
                return (
                  <label
                    key={scope.key}
                    onClick={(e) => {
                      e.preventDefault();
                      handleToggleScope(scope.key);
                    }}
                    className={`p-3 rounded-xl border text-left cursor-pointer transition-all flex flex-col justify-between ${
                      isChecked
                        ? 'bg-emerald-950/50 border-emerald-500 text-white'
                        : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <Icon className={`w-4 h-4 ${isChecked ? 'text-emerald-400' : 'text-slate-500'}`} />
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => {}} // handled by container
                        className="rounded accent-emerald-500 w-3.5 h-3.5"
                      />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white">{scope.label}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{scope.desc}</div>
                    </div>
                  </label>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: DETAILED GESTURE DYNAMICS (Tap, Swipe, Scroll, Typing, Pauses) */}
      {activeSubTab === 'gestures' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* 1. Tap Timing Card */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <MousePointer2 className="w-4 h-4 text-cyan-400" />
              <span>1. Adjustable Tap Timing</span>
            </h4>

            {/* Tap Hold Contact Duration */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300">Tap Physical Hold Duration (Glass Contact):</span>
                <span className="font-mono text-cyan-400 font-bold">{settings.tapHoldDurationMs} ms</span>
              </div>
              <input
                type="range"
                min="30"
                max="400"
                step="5"
                value={settings.tapHoldDurationMs}
                onChange={(e) => onUpdateSettings({ tapHoldDurationMs: Number(e.target.value) })}
                className="w-full h-1.5 bg-slate-800 rounded appearance-none accent-cyan-500"
              />
              <p className="text-[10px] text-slate-500">
                Determines how long the touch event remains DOWN before ACTION_UP. Fast pro taps are 60–90ms.
              </p>
            </div>

            {/* Pre-Tap Aim Delay */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300">Pre-Tap Aim Delay:</span>
                <span className="font-mono text-cyan-400 font-bold">{settings.tapPreDelayMs} ms</span>
              </div>
              <input
                type="range"
                min="20"
                max="500"
                step="10"
                value={settings.tapPreDelayMs}
                onChange={(e) => onUpdateSettings({ tapPreDelayMs: Number(e.target.value) })}
                className="w-full h-1.5 bg-slate-800 rounded appearance-none accent-cyan-500"
              />
              <p className="text-[10px] text-slate-500">
                Cognitive pause before finger touches the screen to simulate human visual orientation.
              </p>
            </div>
          </div>

          {/* 2. Swipe Speed & Distance Card */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <Move className="w-4 h-4 text-emerald-400" />
              <span>2. Adjustable Swipe Speed & Distance</span>
            </h4>

            {/* Swipe Speed */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300">Swipe Duration / Speed:</span>
                <span className="font-mono text-emerald-400 font-bold">{settings.swipeDurationMs} ms</span>
              </div>
              <input
                type="range"
                min="80"
                max="1200"
                step="20"
                value={settings.swipeDurationMs}
                onChange={(e) => onUpdateSettings({ swipeDurationMs: Number(e.target.value) })}
                className="w-full h-1.5 bg-slate-800 rounded appearance-none accent-emerald-500"
              />
              <p className="text-[10px] text-slate-500">
                Duration of the drag gesture. 120–160ms for fast headshot flicks; 400ms for slow camera panning.
              </p>
            </div>

            {/* Swipe Distance */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300">Swipe Distance (Screen Pixels):</span>
                <span className="font-mono text-emerald-400 font-bold">{settings.swipeDistancePx} px</span>
              </div>
              <input
                type="range"
                min="80"
                max="800"
                step="20"
                value={settings.swipeDistancePx}
                onChange={(e) => onUpdateSettings({ swipeDistancePx: Number(e.target.value) })}
                className="w-full h-1.5 bg-slate-800 rounded appearance-none accent-emerald-500"
              />
            </div>

            {/* Free Fire Drag Curve Shape */}
            <div className="space-y-1.5">
              <span className="text-xs text-slate-300 block">Free Fire Aim Drag Curve Shape:</span>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'j_curve' as const, label: 'J-Curve Drag', desc: 'Down dip then upward flick' },
                  { id: 'straight_up' as const, label: 'Straight Drag', desc: 'Direct vertical aim lock' },
                  { id: 'rotation_curve' as const, label: 'Rotation Drag', desc: 'Lateral headshot sweep' },
                ].map((shape) => (
                  <button
                    key={shape.id}
                    onClick={() => onUpdateSettings({ freeFireDragCurveShape: shape.id })}
                    className={`p-2 rounded-lg border text-left text-[11px] font-semibold transition-all ${
                      settings.freeFireDragCurveShape === shape.id
                        ? 'bg-emerald-950 border-emerald-500 text-emerald-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div>{shape.label}</div>
                    <div className="text-[9px] text-slate-500 font-normal">{shape.desc}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* 3. Scrolling Speed & Step Card */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <Compass className="w-4 h-4 text-amber-400" />
              <span>3. Adjustable Scrolling Speed</span>
            </h4>

            {/* Scroll Speed */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300">Scrolling Velocity Duration:</span>
                <span className="font-mono text-amber-400 font-bold">{settings.scrollSpeedMs} ms</span>
              </div>
              <input
                type="range"
                min="100"
                max="1000"
                step="25"
                value={settings.scrollSpeedMs}
                onChange={(e) => onUpdateSettings({ scrollSpeedMs: Number(e.target.value) })}
                className="w-full h-1.5 bg-slate-800 rounded appearance-none accent-amber-500"
              />
            </div>

            {/* Scroll Step Distance */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300">Distance Per Scroll Step:</span>
                <span className="font-mono text-amber-400 font-bold">{settings.scrollStepPx} px</span>
              </div>
              <input
                type="range"
                min="100"
                max="1200"
                step="50"
                value={settings.scrollStepPx}
                onChange={(e) => onUpdateSettings({ scrollStepPx: Number(e.target.value) })}
                className="w-full h-1.5 bg-slate-800 rounded appearance-none accent-amber-500"
              />
              <p className="text-[10px] text-slate-500">
                Controls the length of one continuous scroll stroke in inventories or store menus.
              </p>
            </div>
          </div>

          {/* 4. Natural Pauses & Configurable Timing Variation */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <Clock className="w-4 h-4 text-purple-400" />
              <span>4. Natural Pauses & Timing Variation</span>
            </h4>

            {/* Inter-Action Natural Pause Range */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300">Natural Inter-Action Pause Range:</span>
                <span className="font-mono text-purple-400 font-bold">
                  {settings.naturalPauseMinMs} ms – {settings.naturalPauseMaxMs} ms
                </span>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] text-slate-400 block mb-1">Min Pause (ms):</label>
                  <input
                    type="range"
                    min="50"
                    max="600"
                    step="10"
                    value={settings.naturalPauseMinMs}
                    onChange={(e) => onUpdateSettings({ naturalPauseMinMs: Number(e.target.value) })}
                    className="w-full h-1.5 bg-slate-800 rounded appearance-none accent-purple-500"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-400 block mb-1">Max Pause (ms):</label>
                  <input
                    type="range"
                    min="100"
                    max="2000"
                    step="20"
                    value={settings.naturalPauseMaxMs}
                    onChange={(e) => onUpdateSettings({ naturalPauseMaxMs: Math.max(settings.naturalPauseMinMs + 20, Number(e.target.value)) })}
                    className="w-full h-1.5 bg-slate-800 rounded appearance-none accent-purple-500"
                  />
                </div>
              </div>
              <p className="text-[10px] text-slate-500">
                Natural cognitive hesitation between consecutive macro steps. Prevents clock-like repetitive intervals.
              </p>
            </div>

            {/* Timing Variation % */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300">Configurable Timing Variation (Jitter):</span>
                <span className="font-mono text-purple-400 font-bold">±{settings.timingVariationPct}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="35"
                step="1"
                value={settings.timingVariationPct}
                onChange={(e) => onUpdateSettings({ timingVariationPct: Number(e.target.value) })}
                className="w-full h-1.5 bg-slate-800 rounded appearance-none accent-purple-500"
              />
              <p className="text-[10px] text-slate-500">
                Randomizes each action duration by ±{settings.timingVariationPct}%. Prevents rigid mechanical rhythms.
              </p>
            </div>

            {/* Typing Interval */}
            <div className="space-y-1.5 pt-2 border-t border-slate-800">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300">Typing Key Interval & Micro-Variance:</span>
                <span className="font-mono text-cyan-400 font-bold">
                  {settings.typingIntervalMs} ms (±{settings.typingJitterMs}ms)
                </span>
              </div>
              <input
                type="range"
                min="20"
                max="250"
                step="5"
                value={settings.typingIntervalMs}
                onChange={(e) => onUpdateSettings({ typingIntervalMs: Number(e.target.value) })}
                className="w-full h-1.5 bg-slate-800 rounded appearance-none accent-cyan-500"
              />
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: GESTURE PROFILES */}
      {activeSubTab === 'profiles' && (
        <div className="space-y-4">
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
            <div>
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <Flame className="w-4 h-4 text-amber-400" />
                <span>Pre-Configured Gesture Profiles</span>
              </h4>
              <p className="text-xs text-slate-400 mt-1">
                Optimized combinations of reaction time, tap down-up, swipe distance, and curve shapes.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {GESTURE_PROFILES.map((profile) => {
                const isActive = settings.activeProfile === profile.id;
                return (
                  <div
                    key={profile.id}
                    className={`p-4 rounded-xl border flex flex-col justify-between transition-all ${
                      isActive
                        ? 'bg-slate-950 border-amber-500 shadow-lg shadow-amber-950/40 ring-1 ring-amber-500/60'
                        : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-bold text-white">{profile.name}</span>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-950 text-amber-300 border border-amber-800">
                          {profile.badge}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 leading-relaxed mb-3">
                        {profile.description}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
                      <span className="text-[10px] font-mono text-cyan-400">
                        {profile.settings.customDelayMs || 100}ms | {profile.settings.freeFireDragCurveShape || 'curve'}
                      </span>
                      <button
                        onClick={() => handleApplyProfile(profile)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all ${
                          isActive
                            ? 'bg-amber-600 text-white shadow'
                            : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                        }`}
                      >
                        {isActive ? <Check className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                        <span>{isActive ? 'Active Profile' : 'Apply Profile'}</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: PER-TASK TIMING SETTINGS */}
      {activeSubTab === 'per_task' && (
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-cyan-400" />
                <span>Per-Task Timing Settings</span>
              </h4>
              <p className="text-xs text-slate-400 mt-1">
                Customize reaction times and jitter radii for distinct game tasks and macros individually.
              </p>
            </div>
            <span className="text-xs font-mono text-cyan-400 bg-cyan-950/80 px-2.5 py-1 rounded border border-cyan-800">
              5 Calibrated Tasks
            </span>
          </div>

          <div className="divide-y divide-slate-800">
            {Object.entries(settings.perTaskSettings).map(([taskId, taskTiming]) => (
              <div key={taskId} className="py-3.5 flex flex-col md:flex-row md:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white">{taskTiming.description}</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                      ID: {taskId}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Assigned Preset: <strong className="text-cyan-300">{taskTiming.preset}</strong> ({taskTiming.delayMs}ms) | Jitter: ±{taskTiming.jitterPx}px
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-slate-400">Delay:</span>
                    <input
                      type="range"
                      min="50"
                      max="1500"
                      step="25"
                      value={taskTiming.delayMs}
                      onChange={(e) => {
                        const newDelay = Number(e.target.value);
                        onUpdateSettings({
                          perTaskSettings: {
                            ...settings.perTaskSettings,
                            [taskId]: {
                              ...taskTiming,
                              delayMs: newDelay,
                            },
                          },
                        });
                      }}
                      className="w-28 h-1.5 bg-slate-800 rounded appearance-none accent-cyan-500"
                    />
                    <span className="text-[11px] font-mono text-cyan-400 w-14 text-right">
                      {taskTiming.delayMs}ms
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: TARGET BOUNDARIES & SAFETY ENFORCEMENT */}
      {activeSubTab === 'safety' && (
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-5">
          <div>
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Target Boundary Sentinel & Anti-Stray Protection</span>
            </h4>
            <p className="text-xs text-slate-400 mt-1">
              Guarantees that automated touches <strong>never click outside the intended target</strong> element or HUD button.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Boundary Clamping Toggle */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white">Strict Target Boundary Clamping</span>
                <input
                  type="checkbox"
                  checked={settings.boundaryClampingEnabled}
                  onChange={(e) => onUpdateSettings({ boundaryClampingEnabled: e.target.checked })}
                  className="rounded accent-emerald-500 w-4 h-4 cursor-pointer"
                />
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                When enabled, calculated jitter coordinates are mathematically bounded to the element's verified <code className="text-emerald-300">Rect</code> minus safe inset padding. Any stray touch is instantly prevented.
              </p>
            </div>

            {/* Target Inset Padding */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-white font-bold">Target Safe Inset Padding:</span>
                <span className="font-mono text-emerald-400 font-bold">{settings.targetPaddingPx} px</span>
              </div>
              <input
                type="range"
                min="2"
                max="25"
                step="1"
                value={settings.targetPaddingPx}
                onChange={(e) => onUpdateSettings({ targetPaddingPx: Number(e.target.value) })}
                className="w-full h-1.5 bg-slate-800 rounded appearance-none accent-emerald-500"
              />
              <p className="text-[10px] text-slate-500">
                Safe boundary buffer from the edge of the button. Higher padding keeps all touches safely towards the center.
              </p>
            </div>

            {/* Jitter Radius */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-white font-bold">Micro-Jitter Radius:</span>
                <span className="font-mono text-cyan-400 font-bold">±{settings.jitterRadiusPx} px</span>
              </div>
              <input
                type="range"
                min="2"
                max="20"
                step="1"
                value={settings.jitterRadiusPx}
                onChange={(e) => onUpdateSettings({ jitterRadiusPx: Number(e.target.value) })}
                className="w-full h-1.5 bg-slate-800 rounded appearance-none accent-cyan-500"
              />
              <p className="text-[10px] text-slate-500">
                Microscopic finger displacement simulating natural flesh deformation on glass screens.
              </p>
            </div>

            {/* Safety & Compliance Assurance */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
                <span>Responsible Automation Architecture</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Operates standard Android <code className="text-slate-300">AccessibilityService.dispatchGesture</code> paths without memory injection, code hooking, or binary tampering. Gesture curves provide comfortable ergonomic interactions within verified bounding boxes.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
