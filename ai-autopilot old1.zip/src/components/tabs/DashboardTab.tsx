import React, { useState } from 'react';
import { 
  Play, 
  Pause, 
  Square, 
  Mic, 
  MicOff, 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle, 
  Flame, 
  Layers, 
  Clock, 
  ShieldCheck,
  RefreshCw,
  Cpu,
  ArrowRight
} from 'lucide-react';
import { 
  AssistantStatus, 
  TaskPlan, 
  TaskStep, 
  DeviceMode, 
  VoiceSettings,
  CallModeState
} from '../../types/autopilot';
import { PhoneCall, PhoneOff } from 'lucide-react';

interface DashboardTabProps {
  status: AssistantStatus;
  onStatusChange: (status: AssistantStatus) => void;
  activePlan: TaskPlan | null;
  currentStepIndex: number;
  onExecutePlan: (command: string, language: string) => void;
  isPlanning: boolean;
  deviceMode: DeviceMode;
  voiceSettings: VoiceSettings;
  onStartVoiceInput: () => void;
  isListening: boolean;
  onSimulateErrorRecovery: () => void;
  callMode?: CallModeState;
  onToggleCallMode?: () => void;
}

export const DashboardTab: React.FC<DashboardTabProps> = ({
  status,
  onStatusChange,
  activePlan,
  currentStepIndex,
  onExecutePlan,
  isPlanning,
  deviceMode,
  voiceSettings,
  onStartVoiceInput,
  isListening,
  onSimulateErrorRecovery,
  callMode,
  onToggleCallMode,
}) => {
  const [commandInput, setCommandInput] = useState('');
  const [selectedLang, setSelectedLang] = useState('auto');
  const isCallActive = callMode?.isCallActive || voiceSettings.isCallMuted;

  const suggestions = [
    {
      title: 'Free Fire India Pro Macro',
      cmd: 'Open Free Fire India, tune general sensitivity to 98 and equip instant gloo wall drop macro without closing game',
      tag: 'Gaming Pro',
      color: 'amber',
    },
    {
      title: 'Hinglish Command',
      cmd: 'Free Fire me sensitivity 98 set karo aur fast gloo wall button attach karo',
      tag: 'Hinglish',
      color: 'indigo',
    },
    {
      title: 'Settings Screen Constraint',
      cmd: 'Find battery saver in settings and turn on low-heating mode without leaving current screen',
      tag: 'System',
      color: 'emerald',
    },
    {
      title: 'Hindi Command (हिंदी)',
      cmd: 'फ्री फायर में तुरंत ग्लू वॉल लगाने के लिए मैक्रो चालू करो',
      tag: 'हिंदी',
      color: 'cyan',
    },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commandInput.trim() || isPlanning) return;
    onExecutePlan(commandInput.trim(), selectedLang);
  };

  const handleActivate = () => {
    if (!activePlan) {
      onExecutePlan('Configure Free Fire pro macros and attach floating overlay', selectedLang);
    } else {
      onStatusChange('GREEN_RUNNING');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Hero Banner & Voice Command Input */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-indigo-950/40 border border-slate-800 shadow-xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-4">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <span>Personal AI Automation Hub</span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800/60 font-mono">
                {deviceMode === 'lite' ? '4 GB RAM Lite' : '8 GB Advanced'}
              </span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Natural commands in English, Hindi & Hinglish. Autonomous screen execution via Android Accessibility Service.
            </p>
          </div>

          {/* Large ACTIVATE / PAUSE Toggle Button */}
          <div className="flex items-center gap-2 w-full md:w-auto">
            {status === 'GREEN_RUNNING' ? (
              <button
                onClick={() => onStatusChange('ORANGE_PAUSED')}
                className="flex-1 md:flex-none px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-950/50 transition-all active:scale-95"
              >
                <Pause className="w-4 h-4 fill-current" />
                <span>PAUSE AUTOPILOT (ORANGE)</span>
              </button>
            ) : (
              <button
                onClick={handleActivate}
                disabled={isPlanning}
                className="flex-1 md:flex-none px-6 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/50 transition-all active:scale-95 disabled:opacity-50"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>ACTIVATE AUTOPILOT (GREEN)</span>
              </button>
            )}

            {/* Error Recovery Test trigger */}
            <button
              onClick={onSimulateErrorRecovery}
              className="px-3.5 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium flex items-center gap-1.5 border border-slate-700"
              title="Simulates unexpected screen change or failure to verify AI Adaptive Recovery"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Test Error Recovery</span>
            </button>
          </div>
        </div>

        {/* CALL MODE ACTIVE BANNER ON DASHBOARD */}
        {isCallActive && (
          <div className="mb-4 p-3.5 rounded-xl bg-gradient-to-r from-amber-950 via-rose-950 to-amber-950 border border-amber-500/70 text-amber-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 shadow-lg animate-in fade-in duration-150">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-rose-500 text-white animate-pulse">
                <PhoneCall className="w-4 h-4" />
              </span>
              <div>
                <span className="font-bold text-xs text-white block">
                  CALL MODE ACTIVE — WRITTEN COMMAND MODE ENFORCED
                </span>
                <span className="text-[11px] text-amber-300">
                  AI AutoPilot speech output is automatically muted. Type your commands below to execute silently without interrupting the phone call.
                </span>
              </div>
            </div>
            {onToggleCallMode && (
              <button
                type="button"
                onClick={onToggleCallMode}
                className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1 shrink-0"
              >
                <PhoneOff className="w-3.5 h-3.5" />
                <span>End Call</span>
              </button>
            )}
          </div>
        )}

        {/* Command Form */}
        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="relative flex items-center">
            <input
              type="text"
              value={commandInput}
              onChange={(e) => setCommandInput(e.target.value)}
              placeholder={
                isCallActive
                  ? "Type command silently during active call (e.g. 'Sensitivity 98 set karo')..."
                  : "Give a command (e.g., 'Free Fire me fast gloo wall macro lagao without closing game')..."
              }
              className={`w-full pl-4 pr-28 py-3.5 rounded-xl bg-slate-950/90 border text-white placeholder-slate-500 text-sm focus:outline-none shadow-inner ${
                isCallActive
                  ? 'border-amber-500/60 focus:border-amber-400 focus:ring-1 focus:ring-amber-400'
                  : 'border-slate-700 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500'
              }`}
            />

            <div className="absolute right-2 flex items-center gap-1.5">
              {/* Mic Voice Command Button or Disabled in Call Mode */}
              {isCallActive ? (
                <div 
                  className="p-2 rounded-lg bg-amber-950/60 border border-amber-700/60 text-amber-300 cursor-not-allowed"
                  title="Voice mic disabled during active phone call. Written Command Mode is active."
                >
                  <MicOff className="w-4 h-4" />
                </div>
              ) : (
                <button
                  type="button"
                  onClick={onStartVoiceInput}
                  className={`p-2 rounded-lg border transition-all ${
                    isListening
                      ? 'bg-rose-500 border-rose-400 text-white animate-pulse'
                      : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                  }`}
                  title="Speak voice command in English or Hindi"
                >
                  {isListening ? <Mic className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                </button>
              )}

              {/* Submit Planning Button */}
              <button
                type="submit"
                disabled={!commandInput.trim() || isPlanning}
                className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs transition-all disabled:opacity-40 flex items-center gap-1 shadow"
              >
                {isPlanning ? (
                  <span className="flex items-center gap-1">
                    <span className="w-3 h-3 border-2 border-white/20 border-t-white rounded-full animate-spin"></span>
                    Thinking...
                  </span>
                ) : (
                  <>
                    <span>Plan</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Quick Prompts Chips */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
            <span className="text-[11px] text-slate-500 font-medium whitespace-nowrap">Try commands:</span>
            {suggestions.map((s, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setCommandInput(s.cmd)}
                className="px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-800 border border-slate-700/60 text-slate-300 hover:text-white whitespace-nowrap transition-colors flex items-center gap-1.5 text-[11px]"
              >
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
                <span>{s.title}</span>
              </button>
            ))}
          </div>
        </form>
      </div>

      {/* Task Plan & Step Execution Pipeline */}
      {activePlan && (
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 border-b border-slate-800 pb-3">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white">{activePlan.taskName}</h3>
                {activePlan.isOfflineRule ? (
                  <span className="text-[10px] px-2 py-0.5 rounded bg-amber-950 text-amber-400 border border-amber-800/50 font-mono">
                    Local Offline Rule
                  </span>
                ) : (
                  <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800/50 font-mono">
                    Gemini 3.8 Verified
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400 mt-0.5">{activePlan.summary}</p>
            </div>

            {/* Constraints & Safety Badges */}
            <div className="flex items-center gap-1.5 flex-wrap">
              {activePlan.restrictionsFollowed.map((res, i) => (
                <span
                  key={i}
                  className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 border border-slate-700 flex items-center gap-1"
                >
                  <ShieldCheck className="w-3 h-3 text-emerald-400" />
                  <span>{res}</span>
                </span>
              ))}
            </div>
          </div>

          {/* Steps Timeline */}
          <div className="space-y-2.5">
            {activePlan.steps.map((step, index) => {
              const isPast = index < currentStepIndex;
              const isCurrent = index === currentStepIndex && status === 'GREEN_RUNNING';
              const isPending = index > currentStepIndex;

              return (
                <div
                  key={step.id}
                  className={`p-3 rounded-xl border transition-all flex items-start gap-3 ${
                    isCurrent
                      ? 'bg-cyan-950/40 border-cyan-500 shadow-md shadow-cyan-950/50'
                      : isPast
                      ? 'bg-slate-950/60 border-emerald-900/40 text-slate-300'
                      : 'bg-slate-950/30 border-slate-800/60 opacity-60'
                  }`}
                >
                  <div className="mt-0.5">
                    {isPast ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    ) : isCurrent ? (
                      <div className="w-5 h-5 rounded-full border-2 border-cyan-400 border-t-transparent animate-spin"></div>
                    ) : (
                      <div className="w-5 h-5 rounded-full border border-slate-700 flex items-center justify-center text-[10px] font-mono text-slate-500">
                        {index + 1}
                      </div>
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-semibold text-white truncate">
                        Step {index + 1}: {step.action.toUpperCase()} — {step.target}
                      </span>
                      <span className="text-[10px] font-mono text-slate-400 whitespace-nowrap">
                        ~{step.estimatedTimeMs}ms
                      </span>
                    </div>

                    <p className="text-xs text-slate-400 mt-0.5">{step.description}</p>

                    <div className="flex items-center gap-3 mt-1.5 text-[11px] text-slate-400">
                      <span className="flex items-center gap-1 text-slate-300">
                        <span className="text-slate-500">Verification:</span> {step.verification}
                      </span>
                      <span className="text-slate-600">•</span>
                      <span className="text-emerald-400 font-medium capitalize">
                        {step.riskLevel}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
