import React, { useState } from 'react';
import { 
  ShieldCheck, 
  ShieldAlert, 
  Lock, 
  Trash2, 
  AlertTriangle, 
  CheckCircle2, 
  Flame, 
  Smartphone,
  EyeOff,
  History,
  Square,
  Power,
  Info,
  CreditCard,
  MessageSquare,
  FileText,
  UserCheck,
  ChevronDown,
  ChevronUp,
  Download,
  AlertOctagon,
  RefreshCcw,
  Check
} from 'lucide-react';
import { LogEntry, AssistantStatus, SensitiveActionRequest } from '../../types/autopilot';

interface SecurityAuditTabProps {
  logs: LogEntry[];
  onClearLogs: () => void;
  onEmergencyStop: () => void;
  status?: AssistantStatus;
  onRequestSensitiveActionTest?: (type: SensitiveActionRequest['type']) => void;
  activeApp?: string;
}

export const SecurityAuditTab: React.FC<SecurityAuditTabProps> = ({
  logs,
  onClearLogs,
  onEmergencyStop,
  status = 'IDLE',
  onRequestSensitiveActionTest,
  activeApp = 'Free Fire India',
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'overview' | 'actions' | 'permissions' | 'revocation' | 'history'>('overview');
  const [expandedRevokeGuide, setExpandedRevokeGuide] = useState<string | null>('samsung');
  const [testTriggerToast, setTestTriggerToast] = useState<string | null>(null);

  const permissions = [
    {
      name: 'Accessibility Service (BIND_ACCESSIBILITY_SERVICE)',
      status: 'Required & Verified',
      color: 'emerald',
      description: 'Reads screen element nodes and dispatches humanized touch gestures (taps, swipes, typing) hands-free.',
      whyNeeded: 'Enables AutoPilot to trigger Free Fire Gloo Wall macros and menu navigation without root access.',
      boundaries: 'Hard-coded to execute only within approved gaming packages; never captures banking apps.',
    },
    {
      name: 'Floating Window Overlay (SYSTEM_ALERT_WINDOW)',
      status: 'Granted',
      color: 'emerald',
      description: 'Draws the small movable GREEN/ORANGE/RED floating bubble on top of other running applications.',
      whyNeeded: 'Provides an instant one-tap pause, emergency stop, and status indicator while playing full-screen games.',
      boundaries: 'Compact 42dp diameter, user-draggable, transparent background, does not block crosshairs.',
    },
    {
      name: 'Foreground Service & Ongoing Notification',
      status: 'Granted',
      color: 'emerald',
      description: 'Prevents Android OS from killing AutoPilot when you minimize the app to enter a game.',
      whyNeeded: 'Required by Android to maintain background service with a persistent ongoing notification.',
      boundaries: 'Contains quick action buttons to pause, emergency stop, or close the service cleanly.',
    },
    {
      name: 'Phone State Detection (READ_PHONE_STATE)',
      status: 'Active (Auto-Mute)',
      color: 'cyan',
      description: 'Detects incoming or active phone calls to immediately mute voice speech and protect your privacy.',
      whyNeeded: 'Does NOT record or listen to phone calls. Only inspects CALL_STATE to mute TTS during conversations.',
      boundaries: 'Zero telecom control: cannot answer, reject, route, or listen to actual calls.',
    },
    {
      name: 'Network Access (INTERNET / ACCESS_NETWORK_STATE)',
      status: 'Active (Offline Safe)',
      color: 'indigo',
      description: 'Queries Gemini 3.8 Flash for complex planning. Features 100% offline rule fallback when disconnected.',
      whyNeeded: 'Enables cloud AI reasoning while saving mobile data.',
      boundaries: 'All personal macros and touch settings remain strictly stored in local Room SQLite database.',
    },
  ];

  const sensitiveActionTests: Array<{
    type: SensitiveActionRequest['type'];
    label: string;
    icon: any;
    desc: string;
    isBlocked: boolean;
  }> = [
    {
      type: 'make_payment',
      label: 'Payment Confirmation Guard',
      icon: CreditCard,
      desc: 'Halts automation before in-game diamond purchases or checkout screens.',
      isBlocked: false,
    },
    {
      type: 'send_message',
      label: 'Message Dispatch Guard',
      icon: MessageSquare,
      desc: 'Requires explicit user confirmation before sending any in-game or chat messages.',
      isBlocked: false,
    },
    {
      type: 'delete_data',
      label: 'Data Deletion Guard',
      icon: Trash2,
      desc: 'Stops before removing saved macros, configuration files, or local storage.',
      isBlocked: false,
    },
    {
      type: 'sensitive_form',
      label: 'Sensitive Form Guard',
      icon: FileText,
      desc: 'Intercepts forms requesting user profile, account settings, or email inputs.',
      isBlocked: false,
    },
    {
      type: 'share_personal_info',
      label: 'Personal Info Guard',
      icon: UserCheck,
      desc: 'Blocks unauthorized sharing of device identifiers, contact details, or location.',
      isBlocked: false,
    },
    {
      type: 'blocked_credentials',
      label: 'Credential Zero-Tolerance Shield',
      icon: Lock,
      desc: 'Passwords, OTPs, and banking PINs are strictly blacklisted from automated entry.',
      isBlocked: true,
    },
  ];

  const handleTriggerTest = (type: SensitiveActionRequest['type']) => {
    if (onRequestSensitiveActionTest) {
      onRequestSensitiveActionTest(type);
    } else {
      setTestTriggerToast(`Test dispatched for: ${type}`);
      setTimeout(() => setTestTriggerToast(null), 3000);
    }
  };

  const handleExportLogs = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(logs, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `ai_autopilot_safety_audit_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="space-y-6">
      {/* Overview & Emergency Stop Master Banner */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-950 text-rose-400 flex items-center justify-center border border-rose-800 shadow-inner">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span>AI AutoPilot Safety Manager</span>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase ${
                  status === 'GREEN_RUNNING' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' :
                  status === 'ORANGE_PAUSED' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                  status === 'RED_EMERGENCY_STOP' ? 'bg-rose-950 text-rose-300 border border-rose-800 animate-pulse' :
                  'bg-slate-800 text-slate-300 border border-slate-700'
                }`}>
                  {status === 'GREEN_RUNNING' ? 'GREEN • EXECUTING' :
                   status === 'ORANGE_PAUSED' ? 'ORANGE • PAUSED' :
                   status === 'RED_EMERGENCY_STOP' ? 'RED • EMERGENCY STOPPED' :
                   'STANDBY'}
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Zero-trust user control, mandatory confirmation gates, emergency stop, and permission revocation.
              </p>
            </div>
          </div>

          {/* Master Emergency Stop Button */}
          <button
            onClick={onEmergencyStop}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-red-700 hover:from-rose-500 hover:to-red-600 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-rose-950/60 border border-rose-400/40 transition-all active:scale-95"
            title="Instant Emergency Stop: Halts all gestures, cancels active task queues, and returns control immediately"
          >
            <Square className="w-4 h-4 fill-current" />
            <span>Emergency Stop</span>
          </button>
        </div>

        {/* Emergency Stop Guarantees Notice */}
        <div className="p-3.5 rounded-xl bg-rose-950/30 border border-rose-600/40 text-xs text-rose-200 flex items-start gap-2.5">
          <AlertOctagon className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
          <div className="space-y-0.5">
            <strong className="text-white block font-semibold">Emergency Stop Protocol Guarantees:</strong>
            <p className="text-rose-200/90 leading-relaxed text-[11px]">
              When Emergency Stop is activated (via Top Bar, Floating Assistant, or Ongoing Notification), AutoPilot <strong>immediately cancels queued actions</strong>, <strong>stops ongoing gesture dispatch</strong>, <strong>cancels active task execution</strong>, <strong>preserves task history</strong>, and <strong>returns 100% control to you</strong>.
            </p>
          </div>
        </div>

        {/* STRICT GAMING-ONLY ENFORCEMENT BANNER (PROMPT REQUIREMENT) */}
        <div className="p-3.5 rounded-xl bg-amber-950/30 border border-amber-500/40 text-xs text-amber-200 flex items-start gap-2.5 shadow-md">
          <Flame className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div className="space-y-0.5">
            <div className="flex items-center gap-2 flex-wrap">
              <strong className="text-white font-bold">STRICT GAMING-ONLY LOCKDOWN ENFORCED:</strong>
              <span className="text-[10px] font-mono px-2 py-0.2 rounded bg-amber-900 text-amber-200 border border-amber-700">
                Free Fire Only
              </span>
            </div>
            <p className="text-amber-200/90 leading-relaxed text-[11px]">
              This application is strictly engineered for <strong>Free Fire gaming</strong> and approved gaming web applications. AutoTouch is <strong>100% hard-blocked</strong> from activating on non-gaming apps (Banking, UPI payments, System Settings, SMS, WhatsApp).
            </p>
            <p className="text-[10px] text-amber-400 font-mono pt-0.5">
              Current Target App: {activeApp} • Status: Authorized Game Sandbox
            </p>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2 text-xs overflow-x-auto">
        <button
          onClick={() => setActiveSubTab('overview')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${
            activeSubTab === 'overview'
              ? 'bg-rose-950 text-rose-300 border border-rose-700 font-semibold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>User Control &amp; Safety Guards</span>
        </button>

        <button
          onClick={() => setActiveSubTab('actions')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${
            activeSubTab === 'actions'
              ? 'bg-rose-950 text-rose-300 border border-rose-700 font-semibold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <AlertTriangle className="w-3.5 h-3.5" />
          <span>Important Actions Confirmation</span>
        </button>

        <button
          onClick={() => setActiveSubTab('permissions')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${
            activeSubTab === 'permissions'
              ? 'bg-rose-950 text-rose-300 border border-rose-700 font-semibold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>Permissions Transparency</span>
        </button>

        <button
          onClick={() => setActiveSubTab('revocation')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${
            activeSubTab === 'revocation'
              ? 'bg-rose-950 text-rose-300 border border-rose-700 font-semibold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Power className="w-3.5 h-3.5" />
          <span>Permission Revocation Instructions</span>
        </button>

        <button
          onClick={() => setActiveSubTab('history')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${
            activeSubTab === 'history'
              ? 'bg-rose-950 text-rose-300 border border-rose-700 font-semibold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <History className="w-3.5 h-3.5" />
          <span>Task History ({logs.length})</span>
        </button>
      </div>

      {/* SUBTAB 1: USER CONTROL & SAFETY GUARDS */}
      {activeSubTab === 'overview' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 shadow-lg space-y-2">
              <div className="flex items-center gap-2 text-rose-400 font-bold">
                <EyeOff className="w-4 h-4" />
                <span>Zero-Credential Rule</span>
              </div>
              <p className="text-slate-300 text-[11px] leading-relaxed">
                AutoPilot is hardcoded to <strong>never automatically enter passwords, OTPs, banking PINs or payment credentials</strong>. Such input fields trigger an instant hard block.
              </p>
              <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> Kernel-level blacklist verified
              </span>
            </div>

            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 shadow-lg space-y-2">
              <div className="flex items-center gap-2 text-amber-400 font-bold">
                <AlertTriangle className="w-4 h-4" />
                <span>Important Actions Confirmation</span>
              </div>
              <p className="text-slate-300 text-[11px] leading-relaxed">
                Requires explicit user approval before sending messages, deleting data, making payments, submitting sensitive forms, or performing irreversible actions.
              </p>
              <span className="text-[10px] font-mono text-amber-300 flex items-center gap-1">
                <Lock className="w-3 h-3" /> Two-step approval gate active
              </span>
            </div>

            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 shadow-lg space-y-2">
              <div className="flex items-center gap-2 text-cyan-400 font-bold">
                <Smartphone className="w-4 h-4" />
                <span>User Retains Total Control</span>
              </div>
              <p className="text-slate-300 text-[11px] leading-relaxed">
                You can pause and resume anytime, trigger emergency stop with one tap, or revoke any Android permission immediately from your phone settings.
              </p>
              <span className="text-[10px] font-mono text-cyan-300 flex items-center gap-1">
                <Check className="w-3 h-3" /> Transparent ownership guaranteed
              </span>
            </div>
          </div>

          {/* Quick Emergency Stop Verification */}
          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div>
              <span className="text-white font-bold block">Instant Emergency Stop Test</span>
              <span className="text-slate-400 text-[11px]">
                Verify that clicking STOP immediately severs touch dispatch and cancels all active task planning.
              </span>
            </div>
            <button
              onClick={onEmergencyStop}
              className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-lg font-bold text-xs flex items-center gap-1.5 transition-colors shadow flex-shrink-0"
            >
              <Square className="w-3.5 h-3.5 fill-current" />
              <span>Trigger Emergency Stop</span>
            </button>
          </div>
        </div>
      )}

      {/* SUBTAB 2: IMPORTANT ACTIONS CONFIRMATION TESTING */}
      {activeSubTab === 'actions' && (
        <div className="space-y-4">
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-3">
            <div>
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                <span>Important Actions Confirmation Interceptor</span>
              </h4>
              <p className="text-xs text-slate-400 mt-0.5">
                Test how AI AutoPilot intercepts critical tasks and requires user approval before taking action.
              </p>
            </div>

            {testTriggerToast && (
              <div className="p-2.5 rounded-lg bg-emerald-950 text-emerald-300 text-xs border border-emerald-800">
                {testTriggerToast}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-2">
              {sensitiveActionTests.map((item) => {
                const Icon = item.icon;
                return (
                  <div
                    key={item.type}
                    className={`p-3.5 rounded-xl border flex flex-col justify-between gap-3 transition-all ${
                      item.isBlocked
                        ? 'bg-rose-950/30 border-rose-800/80'
                        : 'bg-slate-950/70 border-slate-800'
                    }`}
                  >
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <Icon className={`w-4 h-4 ${item.isBlocked ? 'text-rose-400' : 'text-amber-400'}`} />
                          <span className="text-xs font-bold text-white">{item.label}</span>
                        </div>
                        {item.isBlocked && (
                          <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-rose-900 text-rose-200 border border-rose-700 font-bold">
                            ZERO TOLERANCE
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-400 leading-relaxed">{item.desc}</p>
                    </div>

                    <button
                      onClick={() => handleTriggerTest(item.type)}
                      className={`w-full py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors border shadow-sm ${
                        item.isBlocked
                          ? 'bg-rose-900/60 hover:bg-rose-800 text-rose-200 border-rose-700'
                          : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
                      }`}
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>{item.isBlocked ? 'Test Password Block' : 'Simulate Action Intercept'}</span>
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 3: PERMISSIONS TRANSPARENCY */}
      {activeSubTab === 'permissions' && (
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
          <div>
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-cyan-400" />
              <span>Transparent Android Permissions Audit</span>
            </h4>
            <p className="text-xs text-slate-400 mt-0.5">
              AutoPilot requests the strict minimum permissions necessary for hands-free Free Fire macro execution.
            </p>
          </div>

          <div className="space-y-3">
            {permissions.map((perm, idx) => (
              <div
                key={idx}
                className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 space-y-2 text-xs"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                  <span className="font-bold text-white text-xs">{perm.name}</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800/60 self-start sm:self-auto">
                    {perm.status}
                  </span>
                </div>
                <p className="text-slate-300 text-[11px]">{perm.description}</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 border-t border-slate-900 text-[11px]">
                  <p className="text-slate-400">
                    <strong className="text-cyan-400">Why needed:</strong> {perm.whyNeeded}
                  </p>
                  <p className="text-slate-400">
                    <strong className="text-amber-400">Safety Boundaries:</strong> {perm.boundaries}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUBTAB 4: PERMISSION REVOCATION INSTRUCTIONS */}
      {activeSubTab === 'revocation' && (
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
          <div>
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <Power className="w-4 h-4 text-rose-400" />
              <span>Permission Revocation Instructions (Complete User Control)</span>
            </h4>
            <p className="text-xs text-slate-400 mt-0.5">
              You always retain complete control over your Android device. Follow these exact steps for your phone manufacturer to revoke any granted permissions at any time.
            </p>
          </div>

          <div className="space-y-3">
            {/* Samsung One UI */}
            <div className="rounded-xl bg-slate-950 border border-slate-800 overflow-hidden text-xs">
              <button
                onClick={() => setExpandedRevokeGuide(expandedRevokeGuide === 'samsung' ? null : 'samsung')}
                className="w-full p-3.5 flex items-center justify-between text-left hover:bg-slate-900/60 transition-colors"
              >
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
                  <span className="font-bold text-white">Samsung One UI (Galaxy Devices)</span>
                </div>
                {expandedRevokeGuide === 'samsung' ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
              </button>

              {expandedRevokeGuide === 'samsung' && (
                <div className="p-4 pt-1 border-t border-slate-800/80 space-y-2 text-slate-300 text-[11px] leading-relaxed">
                  <ol className="list-decimal list-inside space-y-1 text-slate-300">
                    <li>Open <strong>Settings</strong> on your Samsung Galaxy phone.</li>
                    <li>Scroll down and tap <strong>Accessibility</strong>.</li>
                    <li>Tap <strong>Installed apps</strong> (or Installed services).</li>
                    <li>Select <strong>AI AutoPilot Assistant</strong>.</li>
                    <li>Toggle the switch to <strong>OFF</strong> and confirm Turn Off.</li>
                    <li>To revoke Floating Overlay: Settings → Apps → 3-dots menu → <strong>Special access</strong> → <strong>Appear on top</strong> → Turn off AI AutoPilot.</li>
                  </ol>
                </div>
              )}
            </div>

            {/* Xiaomi / HyperOS / MIUI */}
            <div className="rounded-xl bg-slate-950 border border-slate-800 overflow-hidden text-xs">
              <button
                onClick={() => setExpandedRevokeGuide(expandedRevokeGuide === 'xiaomi' ? null : 'xiaomi')}
                className="w-full p-3.5 flex items-center justify-between text-left hover:bg-slate-900/60 transition-colors"
              >
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
                  <span className="font-bold text-white">Xiaomi / Redmi / POCO (HyperOS &amp; MIUI)</span>
                </div>
                {expandedRevokeGuide === 'xiaomi' ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
              </button>

              {expandedRevokeGuide === 'xiaomi' && (
                <div className="p-4 pt-1 border-t border-slate-800/80 space-y-2 text-slate-300 text-[11px] leading-relaxed">
                  <ol className="list-decimal list-inside space-y-1 text-slate-300">
                    <li>Open <strong>Settings</strong> → <strong>Additional settings</strong>.</li>
                    <li>Tap <strong>Accessibility</strong> → Switch to the <strong>Downloaded apps</strong> tab.</li>
                    <li>Tap <strong>AI AutoPilot Assistant</strong> and toggle the switch to <strong>OFF</strong>.</li>
                    <li>To revoke Pop-up Overlay: Settings → Apps → Manage Apps → AI AutoPilot → Other permissions → Revoke <strong>Display pop-up windows</strong>.</li>
                  </ol>
                </div>
              )}
            </div>

            {/* Stock Android / Pixel / Motorola */}
            <div className="rounded-xl bg-slate-950 border border-slate-800 overflow-hidden text-xs">
              <button
                onClick={() => setExpandedRevokeGuide(expandedRevokeGuide === 'stock' ? null : 'stock')}
                className="w-full p-3.5 flex items-center justify-between text-left hover:bg-slate-900/60 transition-colors"
              >
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                  <span className="font-bold text-white">Stock Android (Google Pixel, Motorola, OnePlus)</span>
                </div>
                {expandedRevokeGuide === 'stock' ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
              </button>

              {expandedRevokeGuide === 'stock' && (
                <div className="p-4 pt-1 border-t border-slate-800/80 space-y-2 text-slate-300 text-[11px] leading-relaxed">
                  <ol className="list-decimal list-inside space-y-1 text-slate-300">
                    <li>Open <strong>Settings</strong> → <strong>Accessibility</strong>.</li>
                    <li>Tap <strong>AI AutoPilot</strong> under Downloaded apps.</li>
                    <li>Turn the toggle switch <strong>OFF</strong>.</li>
                    <li>To revoke Overlay: Settings → Apps → Special app access → <strong>Display over other apps</strong> → AI AutoPilot → Turn Off.</li>
                  </ol>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 5: TASK HISTORY & AUDIT LEDGER */}
      {activeSubTab === 'history' && (
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <History className="w-4 h-4 text-cyan-400" />
                <span>Local Task Execution History ({logs.length} entries)</span>
              </h4>
              <p className="text-xs text-slate-400 mt-0.5">
                Every action dispatched by AI AutoPilot is immutably logged locally on your device for security inspection.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleExportLogs}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors border border-slate-700"
                title="Export safety audit ledger as JSON"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export Audit</span>
              </button>

              <button
                onClick={onClearLogs}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-rose-950 hover:text-rose-300 text-slate-400 text-xs font-semibold flex items-center gap-1.5 transition-colors border border-slate-700"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear History</span>
              </button>
            </div>
          </div>

          <div className="space-y-2 max-h-[340px] overflow-y-auto pr-1">
            {logs.length === 0 ? (
              <div className="p-6 text-center text-slate-500 text-xs font-mono">
                No task history entries. History is clean.
              </div>
            ) : (
              logs.map((log) => (
                <div
                  key={log.id}
                  className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 flex items-start justify-between gap-3 text-xs font-mono"
                >
                  <div className="flex items-start gap-2.5">
                    <span className="text-[10px] text-slate-500 whitespace-nowrap mt-0.5">{log.timestamp}</span>
                    <span
                      className={
                        log.type === 'success'
                          ? 'text-emerald-400'
                          : log.type === 'error'
                          ? 'text-rose-400'
                          : log.type === 'security'
                          ? 'text-rose-300 font-bold bg-rose-950/60 px-1.5 py-0.5 rounded border border-rose-800'
                          : log.type === 'warning'
                          ? 'text-amber-400'
                          : 'text-slate-300'
                      }
                    >
                      {log.message}
                    </span>
                  </div>
                  {log.details && (
                    <span className="text-[10px] text-slate-500 whitespace-nowrap bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800">
                      {log.details}
                    </span>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};
