import React, { useState } from 'react';
import { 
  Volume2, 
  VolumeX, 
  Mic, 
  MicOff, 
  PhoneCall, 
  PhoneOff, 
  Zap, 
  MessageSquare, 
  Languages, 
  Play,
  RotateCcw,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Lock,
  Send,
  SlidersHorizontal
} from 'lucide-react';
import { VoiceSettings, CallModeState } from '../../types/autopilot';
import { voiceCompanion } from '../../services/voice';

interface VoiceCompanionTabProps {
  settings: VoiceSettings;
  onUpdateSettings: (newSettings: Partial<VoiceSettings>) => void;
  onTestPhrase: (phrase: string, isHindi?: boolean) => void;
  onSimulateIncomingCall: () => void;
  callMode?: CallModeState;
  onToggleCallMode?: (action?: 'start' | 'end') => void;
  onToggleManualQuietMode?: () => void;
  onExecuteWrittenCommand?: (command: string) => void;
}

export const VoiceCompanionTab: React.FC<VoiceCompanionTabProps> = ({
  settings,
  onUpdateSettings,
  onTestPhrase,
  onSimulateIncomingCall,
  callMode,
  onToggleCallMode,
  onToggleManualQuietMode,
  onExecuteWrittenCommand,
}) => {
  const [askQuery, setAskQuery] = useState('');
  const [askResponse, setAskResponse] = useState<string | null>(null);
  const [writtenTestCmd, setWrittenTestCmd] = useState('');
  const [writtenCmdStatus, setWrittenCmdStatus] = useState<string | null>(null);

  const isCallActive = callMode?.isCallActive || settings.isCallMuted;

  const samplePhrases = [
    { label: 'Task Started (EN)', text: 'Task started. Navigating to Free Fire sensitivity settings.' },
    { label: 'Hindi Alert (हिंदी)', text: 'टास्क शुरू हुआ। फ्री फायर सेंसिटिविटी सेट की जा रही है।', isHindi: true },
    { label: 'Progress Update', text: 'Step two of four completed. Sensitivity slider adjusted to 98.' },
    { label: 'Problem Recovery', text: 'Dialog appeared. Switching to alternative button path safely.' },
    { label: 'Task Completed', text: 'All steps verified successfully. AutoPilot standing by.' },
  ];

  const handleAskAutoPilot = (e: React.FormEvent) => {
    e.preventDefault();
    const query = askQuery.trim().toLowerCase();
    let reply = 'I am actively monitoring your screen and standing by for commands.';

    if (query.includes('what are you doing') || query.includes('kya kar rahe ho')) {
      reply = 'I am completing your task. Two steps are remaining.';
    } else if (query.includes('free fire') || query.includes('gloo')) {
      reply = 'Free fire pro macro is attached. Fast gloo wall response is set to 110 milliseconds.';
    } else if (query.includes('status')) {
      reply = 'All foreground systems operational. Human touch jitter active.';
    }

    setAskResponse(reply);
    onTestPhrase(reply);
    setAskQuery('');
  };

  const handleSendWrittenTest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!writtenTestCmd.trim()) return;
    if (onExecuteWrittenCommand) {
      onExecuteWrittenCommand(writtenTestCmd.trim());
    }
    setWrittenCmdStatus(`Silent command "${writtenTestCmd.trim()}" dispatched. Speech output suppressed.`);
    setWrittenTestCmd('');
    setTimeout(() => setWrittenCmdStatus(null), 4000);
  };

  const formatSeconds = (secs: number = 0) => {
    const mins = Math.floor(secs / 60);
    const rem = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${rem.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      {/* 1. DEDICATED AUTOMATIC CALL MODE & PRIVACY SHIELD CARD */}
      <div className={`p-5 rounded-2xl border shadow-xl space-y-4 transition-all ${
        isCallActive 
          ? 'bg-gradient-to-r from-amber-950/80 via-slate-900 to-rose-950/70 border-amber-500/70' 
          : 'bg-slate-900 border-slate-800'
      }`}>
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <div className={`p-2 rounded-xl ${isCallActive ? 'bg-amber-500 text-slate-950 animate-bounce' : 'bg-slate-800 text-slate-300'}`}>
                <PhoneCall className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <span>Automatic Call Mode</span>
                  {isCallActive ? (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-500 text-slate-950 animate-pulse">
                      ACTIVE • {formatSeconds(callMode?.callDurationSeconds)}
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-slate-800 text-slate-400">
                      STANDBY (LISTENING)
                    </span>
                  )}
                </h3>
                <p className="text-xs text-slate-400">
                  When a phone call is active, AutoPilot speech output is automatically muted and switched to written command mode.
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center flex-wrap gap-2">
            {/* Call Toggle Simulation Button */}
            <button
              onClick={onToggleCallMode ? () => onToggleCallMode(isCallActive ? 'end' : 'start') : onSimulateIncomingCall}
              className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 shadow transition-all ${
                isCallActive
                  ? 'bg-rose-600 hover:bg-rose-500 text-white'
                  : 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white'
              }`}
            >
              {isCallActive ? (
                <>
                  <PhoneOff className="w-4 h-4" />
                  <span>End Call (Restore Audio)</span>
                </>
              ) : (
                <>
                  <PhoneCall className="w-4 h-4" />
                  <span>Simulate Phone Call</span>
                </>
              )}
            </button>

            {/* Manual Quiet Mode Fallback */}
            {onToggleManualQuietMode && (
              <button
                onClick={onToggleManualQuietMode}
                className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-all ${
                  callMode?.manualQuietModeFallback
                    ? 'bg-amber-950/80 border-amber-500 text-amber-300'
                    : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                }`}
                title="Use if phone state detection is unavailable or denied"
              >
                <VolumeX className="w-3.5 h-3.5" />
                <span>{callMode?.manualQuietModeFallback ? 'Quiet Mode ON' : 'Manual Quiet Mode'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Live Call State Notification Banner */}
        {isCallActive && (
          <div className="p-3.5 rounded-xl bg-slate-950/90 border border-amber-500/50 space-y-2 animate-in fade-in duration-200">
            <div className="flex items-center justify-between text-xs">
              <span className="text-amber-300 font-bold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>
                Phone Call in Progress — AutoPilot Audio Suppressed
              </span>
              <span className="font-mono text-amber-400 text-xs">
                Duration: {formatSeconds(callMode?.callDurationSeconds)}
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px] text-slate-300">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>AI Speech: <strong>Muted</strong></span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Command Mode: <strong>Written Only</strong></span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Task State: <strong>Preserved</strong></span>
              </div>
            </div>
          </div>
        )}

        {/* 6 Strict Requirements & Compliance Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 pt-2">
          <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800 text-xs space-y-1">
            <span className="font-bold text-white flex items-center gap-1 text-[11px]">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>1. Speech Output Muted</span>
            </span>
            <p className="text-[10px] text-slate-400 leading-normal">
              Internal TTS and sound queues cancel immediately so AutoPilot never talks over your phone conversation.
            </p>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800 text-xs space-y-1">
            <span className="font-bold text-white flex items-center gap-1 text-[11px]">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>2. Written Command Mode</span>
            </span>
            <p className="text-[10px] text-slate-400 leading-normal">
              Voice listening pauses. Prompts switch to text input so you can type silently during gameplay.
            </p>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800 text-xs space-y-1">
            <span className="font-bold text-white flex items-center gap-1 text-[11px]">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>3. Accepts Permitted Commands</span>
            </span>
            <p className="text-[10px] text-slate-400 leading-normal">
              Tactical macros, sensitivity changes, and Free Fire triggers execute silently with visual feedback.
            </p>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800 text-xs space-y-1">
            <span className="font-bold text-white flex items-center gap-1 text-[11px]">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>4. Avoid Audio Playback</span>
            </span>
            <p className="text-[10px] text-slate-400 leading-normal">
              Audio effects and alerts are blocked. Phone call audio is completely untouched.
            </p>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800 text-xs space-y-1">
            <span className="font-bold text-white flex items-center gap-1 text-[11px]">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>5. Task State Preserved</span>
            </span>
            <p className="text-[10px] text-slate-400 leading-normal">
              Ongoing workflows and checkpoints remain intact. Automation never crashes or cancels upon incoming calls.
            </p>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800 text-xs space-y-1">
            <span className="font-bold text-white flex items-center gap-1 text-[11px]">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>6. Previous Voice Restored</span>
            </span>
            <p className="text-[10px] text-slate-400 leading-normal">
              When call ends, previous voice settings (speed, pitch, language, fast-talk) are restored automatically.
            </p>
          </div>
        </div>

        {/* Security & System Compliance Notice */}
        <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-slate-400 flex items-start gap-2">
          <ShieldCheck className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
          <div>
            <strong className="text-slate-200">Android Privacy &amp; Telecom Safety Rules:</strong> AutoPilot requests only minimum permission (<code className="text-cyan-300 font-mono">READ_PHONE_STATE</code>) to listen for <code className="text-cyan-300 font-mono">CALL_STATE_OFFHOOK</code> and <code className="text-cyan-300 font-mono">CALL_STATE_IDLE</code>. It <strong>never</strong> listens to call audio, records calls, or accesses phone numbers. It <strong>never</strong> auto-answers, rejects, or hangs up phone calls.
          </div>
        </div>
      </div>

      {/* 2. WRITTEN COMMAND MODE INTERACTIVE TESTER */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-sm font-bold text-white flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-amber-400" />
            <span>Written Command Mode (Silent Execution Tester)</span>
          </h4>
          <span className="text-[10px] font-mono text-slate-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
            {isCallActive ? 'CALL MODE: WRITTEN COMMANDS ENFORCED' : 'WRITTEN & VOICE READY'}
          </span>
        </div>
        <p className="text-xs text-slate-400">
          Type instructions in English, Hindi, or Hinglish. Commands are executed without emitting any audio or disturbing your active telephone call.
        </p>

        <form onSubmit={handleSendWrittenTest} className="flex gap-2">
          <input
            type="text"
            value={writtenTestCmd}
            onChange={(e) => setWrittenTestCmd(e.target.value)}
            placeholder="e.g. Free Fire me sensitivity 98 set karo aur fast gloo wall macro lagao..."
            className="flex-1 px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-amber-400"
          />
          <button
            type="submit"
            className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow flex items-center gap-1.5 transition-colors"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Dispatch Silent Command</span>
          </button>
        </form>

        {writtenCmdStatus && (
          <div className="p-2.5 rounded-xl bg-emerald-950/60 border border-emerald-600/70 text-emerald-300 text-xs flex items-center gap-2 animate-fadeIn">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{writtenCmdStatus}</span>
          </div>
        )}

        <div className="flex flex-wrap gap-2 pt-1 text-[11px]">
          <button
            type="button"
            onClick={() => {
              if (onExecuteWrittenCommand) onExecuteWrittenCommand('Free Fire sensitivity 98 set karo');
              setWrittenCmdStatus('Silent command dispatched: Free Fire sensitivity 98 set karo');
            }}
            className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white"
          >
            &quot;Sensitivity 98 set karo&quot;
          </button>
          <button
            type="button"
            onClick={() => {
              if (onExecuteWrittenCommand) onExecuteWrittenCommand('Equip instant gloo wall macro without closing game');
              setWrittenCmdStatus('Silent command dispatched: Equip instant gloo wall macro');
            }}
            className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white"
          >
            &quot;Equip instant gloo wall macro&quot;
          </button>
          <button
            type="button"
            onClick={() => {
              if (onExecuteWrittenCommand) onExecuteWrittenCommand('Check HUD crosshairs and touch boundaries');
              setWrittenCmdStatus('Silent command dispatched: Check HUD crosshairs');
            }}
            className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white"
          >
            &quot;Check HUD crosshairs&quot;
          </button>
        </div>
      </div>

      {/* 3. Voice Companion Settings: Fast Talk & Language */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Volume2 className="w-5 h-5 text-cyan-400" />
              <span>Voice Speech Configuration (Normal Mode)</span>
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Active when phone call is idle. Restored automatically upon call termination.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onUpdateSettings({ quietMode: !settings.quietMode })}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all border ${
                settings.quietMode
                  ? 'bg-rose-950/60 border-rose-500 text-rose-300'
                  : 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700'
              }`}
            >
              {settings.quietMode ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
              <span>{settings.quietMode ? 'Quiet Mode (Voice OFF)' : 'Quiet Mode (Turn OFF)'}</span>
            </button>
          </div>
        </div>

        {/* Feature Switches: Fast Talk Mode & Language */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-slate-800">
          {/* Fast Talk Mode (Section 7) */}
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <Zap className="w-4 h-4 text-amber-400" />
                <span>Fast Talk Mode</span>
              </span>
              <input
                type="checkbox"
                checked={settings.fastTalkMode}
                onChange={(e) => onUpdateSettings({ fastTalkMode: e.target.checked })}
                className="rounded accent-cyan-500 w-4 h-4 cursor-pointer"
              />
            </div>
            <p className="text-[11px] text-slate-400">
              Cuts verbosity. Speaks minimal, rapid updates under 12 words without interrupting workflow.
            </p>
          </div>

          {/* Automatic Language Detection */}
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <Languages className="w-4 h-4 text-indigo-400" />
                <span>Language Switch</span>
              </span>
              <select
                value={settings.language}
                onChange={(e) => onUpdateSettings({ language: e.target.value as any })}
                className="px-2 py-1 rounded bg-slate-900 border border-slate-700 text-[11px] text-white"
              >
                <option value="auto">Auto Detect</option>
                <option value="en">English (US/India)</option>
                <option value="hi">Hindi (हिंदी)</option>
              </select>
            </div>
            <p className="text-[11px] text-slate-400">
              Automatically switches between Hindi and English speech synthesis based on query language.
            </p>
          </div>
        </div>
      </div>

      {/* Interactive Speech Tester & "What are you doing?" Query Box */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Ask Assistant while running (Requirement 6) */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
          <h4 className="text-sm font-bold text-white flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-cyan-400" />
            <span>Interactive Q&amp;A While Automation Runs</span>
          </h4>
          <p className="text-xs text-slate-400">
            Ask questions like &quot;What are you doing?&quot; or &quot;Kya kar rahe ho?&quot; while AutoPilot is executing.
          </p>

          <form onSubmit={handleAskAutoPilot} className="flex gap-2">
            <input
              type="text"
              value={askQuery}
              onChange={(e) => setAskQuery(e.target.value)}
              placeholder="Ask: 'What are you doing?'..."
              className="flex-1 px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-500"
            />
            <button
              type="submit"
              className="px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs shadow"
            >
              Ask AI
            </button>
          </form>

          {askResponse && (
            <div className="p-3 rounded-xl bg-cyan-950/40 border border-cyan-500/50 text-cyan-200 text-xs flex items-start gap-2 animate-fadeIn">
              <Sparkles className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
              <div>
                <strong className="block text-white text-[11px] mb-0.5">AI AutoPilot Voice Answer:</strong>
                <span>&quot;{askResponse}&quot;</span>
              </div>
            </div>
          )}

          {/* Quick Click Prompts */}
          <div className="flex items-center gap-2 pt-2">
            <button
              type="button"
              onClick={() => {
                setAskResponse('I am completing your task. Two steps are remaining.');
                onTestPhrase('I am completing your task. Two steps are remaining.');
              }}
              className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700"
            >
              &quot;What are you doing?&quot;
            </button>
            <button
              type="button"
              onClick={() => {
                setAskResponse('टास्क चालू है। दो स्टेप बाकी हैं।');
                onTestPhrase('टास्क चालू है। दो स्टेप बाकी हैं।', true);
              }}
              className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700"
            >
              &quot;क्या कर रहे हो?&quot;
            </button>
          </div>
        </div>

        {/* Auditory Status Announcements */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-3">
          <h4 className="text-sm font-bold text-white flex items-center justify-between">
            <span>Auditory Status Announcements</span>
            <span className="text-xs text-slate-400">Click to preview</span>
          </h4>

          <div className="space-y-2">
            {samplePhrases.map((phrase, idx) => (
              <button
                key={idx}
                onClick={() => onTestPhrase(phrase.text, phrase.isHindi)}
                className="w-full text-left p-2.5 rounded-xl bg-slate-950/70 hover:bg-slate-950 border border-slate-800/80 hover:border-cyan-500/50 transition-all flex items-center justify-between gap-2 text-xs"
              >
                <div>
                  <span className="text-[10px] font-mono text-cyan-400 block">{phrase.label}</span>
                  <span className="text-slate-300">{phrase.text}</span>
                </div>
                <Play className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
