import React, { useState } from 'react';
import { 
  Layers, 
  Play, 
  Pause, 
  Square, 
  ShieldCheck, 
  Move, 
  Power,
  RotateCcw,
  Sparkles,
  Smartphone,
  Minimize2,
  Maximize2,
  AlertTriangle,
  Info,
  CheckCircle2,
  Flame,
  ShieldAlert,
  BatteryCharging,
  Settings,
  HelpCircle,
  ExternalLink
} from 'lucide-react';
import { 
  AssistantStatus, 
  FloatingAssistantState, 
  TaskPlan, 
  TaskStep,
  IntelligentResumeInspection 
} from '../../types/autopilot';

interface FloatingAssistantTabProps {
  status: AssistantStatus;
  onStatusChange: (status: AssistantStatus) => void;
  floatingState: FloatingAssistantState;
  onUpdateFloatingState: (state: Partial<FloatingAssistantState>) => void;
  activePlan: TaskPlan | null;
  currentStepIndex: number;
  onToggleMinimize?: () => void;
  isAppMinimized?: boolean;
  onTriggerIntelligentResume?: () => void;
  onCloseAutoPilot?: () => void;
  onOpenInspector?: () => void;
}

export const FloatingAssistantTab: React.FC<FloatingAssistantTabProps> = ({
  status,
  onStatusChange,
  floatingState,
  onUpdateFloatingState,
  activePlan,
  currentStepIndex,
  onToggleMinimize,
  isAppMinimized = false,
  onTriggerIntelligentResume,
  onCloseAutoPilot,
  onOpenInspector,
}) => {
  const [selectedOem, setSelectedOem] = useState<'xiaomi' | 'samsung' | 'oppo_vivo' | 'general'>('xiaomi');
  const completedSteps = activePlan ? activePlan.steps.slice(0, currentStepIndex) : [];
  const remainingSteps = activePlan ? activePlan.steps.slice(currentStepIndex) : [];
  const isServiceActive = floatingState.isServiceActive !== false;

  return (
    <div className="space-y-6 text-slate-100 font-sans">
      
      {/* 1. PRIMARY LIFECYCLE & MINIMIZATION CARD */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-400">
                <Layers className="w-4 h-4" />
              </div>
              <h3 className="text-base font-bold text-white">
                Floating Assistant & Foreground Service
              </h3>
            </div>
            <p className="text-xs text-slate-400 mt-1 max-w-xl">
              Allows you to minimize AutoPilot into the background while keeping a movable, small green indicator on top of Free Fire.
            </p>
          </div>

          {/* Quick Lifecycle Controls */}
          <div className="flex items-center flex-wrap gap-2">
            {/* Minimize / Restore Toggle */}
            {onToggleMinimize && (
              <button
                onClick={onToggleMinimize}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all border ${
                  isAppMinimized
                    ? 'bg-cyan-950 border-cyan-500 text-cyan-300 shadow-md shadow-cyan-950/50'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
                }`}
                title="Minimize AutoPilot so you can play Free Fire with the floating bubble"
              >
                {isAppMinimized ? (
                  <>
                    <Maximize2 className="w-3.5 h-3.5 text-cyan-400" />
                    <span>App Minimized (Click to Restore)</span>
                  </>
                ) : (
                  <>
                    <Minimize2 className="w-3.5 h-3.5 text-slate-400" />
                    <span>Minimize Application</span>
                  </>
                )}
              </button>
            )}

            {/* Pause / Resume Button with Intelligent Flow */}
            {status === 'GREEN_RUNNING' ? (
              <button
                onClick={() => onStatusChange('ORANGE_PAUSED')}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow"
                title="Pause task without closing AutoPilot (Turns indicator Orange)"
              >
                <Pause className="w-4 h-4 fill-current" />
                <span>Pause (Set Orange)</span>
              </button>
            ) : (
              <button
                onClick={() => {
                  if (onTriggerIntelligentResume) {
                    onTriggerIntelligentResume();
                  } else {
                    onStatusChange('GREEN_RUNNING');
                  }
                }}
                className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 active:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5 shadow"
                title="Intelligent Resume: verifies screen and continues safely"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>Resume (Set Green)</span>
              </button>
            )}

            {/* Explicit Close AutoPilot Button */}
            <button
              onClick={() => {
                if (onCloseAutoPilot) {
                  onCloseAutoPilot();
                } else {
                  onStatusChange('IDLE');
                }
              }}
              className="px-3.5 py-2 rounded-xl bg-rose-950/40 hover:bg-rose-900/40 text-rose-300 border border-rose-800/60 font-semibold text-xs flex items-center gap-1.5 transition-colors"
              title="Explicitly shuts down foreground service, removes overlay, and cancels ongoing tasks"
            >
              <Power className="w-3.5 h-3.5 text-rose-400" />
              <span>Close AutoPilot</span>
            </button>
          </div>
        </div>

        {/* 3 Floating Indicator State Legend */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3 border-t border-slate-800">
          <div className={`p-3 rounded-xl border flex items-center gap-3 transition-colors ${
            status === 'GREEN_RUNNING' 
              ? 'bg-emerald-950/60 border-emerald-500/80 shadow-md shadow-emerald-950/50' 
              : 'bg-slate-950/50 border-slate-800'
          }`}>
            <div className="w-4 h-4 rounded-full bg-emerald-500 ring-4 ring-emerald-500/30 animate-pulse flex-shrink-0"></div>
            <div>
              <span className="text-xs font-bold text-white block">GREEN: RUNNING</span>
              <span className="text-[10px] text-slate-400">Active & allowed to execute tasks</span>
            </div>
          </div>

          <div className={`p-3 rounded-xl border flex items-center gap-3 transition-colors ${
            status === 'ORANGE_PAUSED' 
              ? 'bg-amber-950/60 border-amber-500/80 shadow-md shadow-amber-950/50' 
              : 'bg-slate-950/50 border-slate-800'
          }`}>
            <div className="w-4 h-4 rounded-full bg-amber-500 ring-4 ring-amber-500/30 flex-shrink-0"></div>
            <div>
              <span className="text-xs font-bold text-white block">ORANGE: PAUSED</span>
              <span className="text-[10px] text-slate-400">Task paused, state preserved</span>
            </div>
          </div>

          <div className={`p-3 rounded-xl border flex items-center gap-3 transition-colors ${
            status === 'RED_EMERGENCY_STOP' 
              ? 'bg-rose-950/60 border-rose-500/80 shadow-md shadow-rose-950/50' 
              : 'bg-slate-950/50 border-slate-800'
          }`}>
            <div className="w-4 h-4 rounded-full bg-rose-600 ring-4 ring-rose-600/40 animate-ping flex-shrink-0"></div>
            <div>
              <span className="text-xs font-bold text-white block">RED: EMERGENCY STOP</span>
              <span className="text-[10px] text-slate-400">Instant gesture termination</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. INTELLIGENT PAUSE AND RESUME ENGINE */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-indigo-500/20 border border-indigo-400/40 flex items-center justify-center text-indigo-400">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">Intelligent Pause and Resume Engine</h4>
              <p className="text-[11px] text-slate-400">
                OFF pauses current task without closing. ON loads saved state, inspects screen, and resumes safely.
              </p>
            </div>
          </div>

          {onOpenInspector && (
            <button
              onClick={onOpenInspector}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-800/50 text-xs font-medium flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>Open Resume Inspector</span>
            </button>
          )}
        </div>

        {/* 7-Step Verification Workflow Diagram */}
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
          <h5 className="text-xs font-bold text-cyan-300 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-cyan-400" />
            <span>The 7-Step Resumption Protocol:</span>
          </h5>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 text-[11px]">
            <div className="p-2.5 rounded-lg bg-slate-900/90 border border-slate-800 space-y-1">
              <span className="font-mono text-[9px] text-cyan-400 block font-bold">STEP 1</span>
              <strong className="text-white block">Load Saved State</strong>
              <p className="text-slate-400 text-[10px]">Restores step index and target View ID.</p>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-900/90 border border-slate-800 space-y-1">
              <span className="font-mono text-[9px] text-cyan-400 block font-bold">STEP 2</span>
              <strong className="text-white block">Inspect Screen</strong>
              <p className="text-slate-400 text-[10px]">Scans Free Fire HUD for active overlay nodes.</p>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-900/90 border border-slate-800 space-y-1">
              <span className="font-mono text-[9px] text-emerald-400 block font-bold">STEP 3</span>
              <strong className="text-white block">Verify Completed</strong>
              <p className="text-slate-400 text-[10px]">Never repeats already completed clicks.</p>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-900/90 border border-slate-800 space-y-1">
              <span className="font-mono text-[9px] text-amber-400 block font-bold">STEP 4</span>
              <strong className="text-white block">Detect Changes</strong>
              <p className="text-slate-400 text-[10px]">Checks if game context or menu shifted.</p>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-900/90 border border-slate-800 space-y-1">
              <span className="font-mono text-[9px] text-indigo-400 block font-bold">STEP 5</span>
              <strong className="text-white block">Recalculate Plan</strong>
              <p className="text-slate-400 text-[10px]">Computes the optimal path forward.</p>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-900/90 border border-slate-800 space-y-1">
              <span className="font-mono text-[9px] text-cyan-400 block font-bold">STEP 6</span>
              <strong className="text-white block">Safest Step</strong>
              <p className="text-slate-400 text-[10px]">Continues from verified non-conflicting node.</p>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-900/90 border border-rose-900/40 col-span-1 sm:col-span-2 space-y-1 bg-rose-950/20">
              <span className="font-mono text-[9px] text-rose-400 block font-bold">STEP 7 • CRITICAL RULE</span>
              <strong className="text-rose-200 block">Never Repeat Destructive Actions</strong>
              <p className="text-rose-300/80 text-[10px]">Zero repeated payments, diamond spending, or weapon fire.</p>
            </div>
          </div>
        </div>

        {/* Live Step Tracker (Completed vs Remaining) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 rounded-xl bg-slate-950 border border-emerald-900/40 space-y-2">
            <span className="text-xs font-bold text-emerald-400 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" />
                <span>Verified Completed Steps ({completedSteps.length})</span>
              </span>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded">NO DUPLICATES</span>
            </span>

            {completedSteps.length === 0 ? (
              <p className="text-[11px] text-slate-500 italic py-2">No steps completed yet in active session.</p>
            ) : (
              <div className="space-y-1.5">
                {completedSteps.map((step) => (
                  <div key={step.id} className="text-xs p-2 rounded bg-slate-900/60 border border-slate-800 flex items-center justify-between text-slate-300">
                    <span className="truncate">✓ {step.description}</span>
                    <span className="text-[10px] text-emerald-400 font-mono">SAVED</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-cyan-900/40 space-y-2">
            <span className="text-xs font-bold text-cyan-400 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <RotateCcw className="w-4 h-4" />
                <span>Safe Next Actions ({remainingSteps.length})</span>
              </span>
              <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded">READY</span>
            </span>

            {remainingSteps.length === 0 ? (
              <p className="text-[11px] text-slate-500 italic py-2">All planned steps completed successfully.</p>
            ) : (
              <div className="space-y-1.5">
                {remainingSteps.map((step, idx) => (
                  <div key={step.id} className={`text-xs p-2 rounded border flex items-center justify-between ${
                    idx === 0 
                      ? 'bg-cyan-950/40 border-cyan-500 text-white font-medium' 
                      : 'bg-slate-900/40 border-slate-800 text-slate-400'
                  }`}>
                    <span className="truncate">{idx === 0 ? '▶ NEXT: ' : ''}{step.description}</span>
                    <span className="text-[10px] font-mono text-slate-400">~{step.estimatedTimeMs}ms</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 3. FLOATING BUBBLE POSITION & APPEARANCE CONFIGURATION */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <h4 className="text-sm font-bold text-white flex items-center gap-2">
            <Move className="w-4 h-4 text-cyan-400" />
            <span>Floating Indicator Layout & Ergonomics</span>
          </h4>
          <button
            onClick={() => onUpdateFloatingState({ x: 16, y: 36 })}
            className="text-[11px] text-cyan-400 hover:text-cyan-300 underline font-medium"
          >
            Reset to Default (Top-Left)
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div className="space-y-2">
            <div className="flex items-center justify-between text-slate-300">
              <span>Indicator Diameter</span>
              <span className="font-mono text-cyan-400">{floatingState.sizePx || 42} px (Small)</span>
            </div>
            <input
              type="range"
              min="34"
              max="58"
              value={floatingState.sizePx || 42}
              onChange={(e) => onUpdateFloatingState({ sizePx: Number(e.target.value) })}
              className="w-full h-1.5 bg-slate-800 rounded appearance-none accent-cyan-500"
            />
            <p className="text-[10px] text-slate-500">Compact design prevents obstructing Free Fire crosshairs.</p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between text-slate-300">
              <span>Overlay Opacity</span>
              <span className="font-mono text-cyan-400">{Math.round((floatingState.opacity || 0.95) * 100)}%</span>
            </div>
            <input
              type="range"
              min="0.35"
              max="1"
              step="0.05"
              value={floatingState.opacity || 0.95}
              onChange={(e) => onUpdateFloatingState({ opacity: Number(e.target.value) })}
              className="w-full h-1.5 bg-slate-800 rounded appearance-none accent-cyan-500"
            />
            <p className="text-[10px] text-slate-500">Adjust transparency for minimal visual interference.</p>
          </div>

          <div className="space-y-1.5 p-3 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-slate-400 text-[10px] block">Current Screen Position</span>
            <div className="flex items-center justify-between font-mono text-xs text-white">
              <span>X: {Math.round(floatingState.x)} px</span>
              <span>Y: {Math.round(floatingState.y)} px</span>
            </div>
            <span className="text-[10px] text-emerald-400 block font-medium">✓ User-movable anywhere</span>
          </div>
        </div>
      </div>

      {/* 4. ANDROID SYSTEM RESTRICTIONS & OEM BATTERY KILLER GUIDE */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400">
            <BatteryCharging className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-white">
              Android Background Execution Limits & OEM Whitelisting
            </h4>
            <p className="text-[11px] text-slate-400">
              How AutoPilot stays running in the background without being killed by Android or phone manufacturers.
            </p>
          </div>
        </div>

        {/* OEM Selector Tabs */}
        <div className="flex items-center gap-1.5 border-b border-slate-800 pb-2 overflow-x-auto text-xs">
          <button
            onClick={() => setSelectedOem('xiaomi')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
              selectedOem === 'xiaomi'
                ? 'bg-amber-950 text-amber-300 border border-amber-700/80'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Xiaomi / HyperOS / MIUI
          </button>
          <button
            onClick={() => setSelectedOem('samsung')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
              selectedOem === 'samsung'
                ? 'bg-blue-950 text-blue-300 border border-blue-700/80'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Samsung One UI
          </button>
          <button
            onClick={() => setSelectedOem('oppo_vivo')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
              selectedOem === 'oppo_vivo'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-700/80'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Vivo / Oppo / Realme
          </button>
          <button
            onClick={() => setSelectedOem('general')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
              selectedOem === 'general'
                ? 'bg-indigo-950 text-indigo-300 border border-indigo-700/80'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Stock Android 13/14/15
          </button>
        </div>

        {/* OEM Specific Instructions */}
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-2">
          {selectedOem === 'xiaomi' && (
            <div className="space-y-2 text-slate-300">
              <strong className="text-amber-400 block font-semibold">Xiaomi / HyperOS / Redmi Whitelist:</strong>
              <ol className="list-decimal list-inside space-y-1 text-slate-300 text-[11px]">
                <li>Open <strong>Settings → Apps → Manage Apps → AI AutoPilot</strong>.</li>
                <li>Enable <strong>Autostart</strong> (toggle ON).</li>
                <li>Under <strong>Battery Saver</strong>, change from "MIUI Battery Saver" to <strong>"No restrictions"</strong>.</li>
                <li>Under <strong>Other Permissions</strong>, allow <strong>"Display pop-up windows while running in background"</strong>.</li>
                <li>In Recent Apps screen, long-press AI AutoPilot and tap the <strong>Lock (🔒) icon</strong> to protect from memory cleaners.</li>
              </ol>
            </div>
          )}

          {selectedOem === 'samsung' && (
            <div className="space-y-2 text-slate-300">
              <strong className="text-blue-400 block font-semibold">Samsung One UI Whitelist:</strong>
              <ol className="list-decimal list-inside space-y-1 text-slate-300 text-[11px]">
                <li>Open <strong>Settings → Battery and Device Care → Battery</strong>.</li>
                <li>Tap <strong>Background usage limits</strong>.</li>
                <li>Tap <strong>Never sleeping apps</strong> → Tap <strong>(+)</strong> and select <strong>AI AutoPilot</strong>.</li>
                <li>Open <strong>App Info → Battery → Select "Unrestricted"</strong>.</li>
                <li>In Recent Apps, tap the app icon and select <strong>"Keep open"</strong>.</li>
              </ol>
            </div>
          )}

          {selectedOem === 'oppo_vivo' && (
            <div className="space-y-2 text-slate-300">
              <strong className="text-emerald-400 block font-semibold">Vivo (Funtouch OS) & Oppo (ColorOS):</strong>
              <ol className="list-decimal list-inside space-y-1 text-slate-300 text-[11px]">
                <li>Open <strong>Settings → Battery → High background power consumption</strong> → Allow <strong>AI AutoPilot</strong>.</li>
                <li>In <strong>App Management</strong>, enable <strong>Auto-launch</strong> and <strong>Floating Window</strong> permission.</li>
                <li>In Recent Tasks, swipe down on AI AutoPilot to lock it in memory.</li>
              </ol>
            </div>
          )}

          {selectedOem === 'general' && (
            <div className="space-y-2 text-slate-300">
              <strong className="text-indigo-400 block font-semibold">Stock Android 13, 14 & 15 System Standards:</strong>
              <ol className="list-decimal list-inside space-y-1 text-slate-300 text-[11px]">
                <li><strong>Foreground Service:</strong> Uses <code className="text-cyan-400">FOREGROUND_SERVICE_SPECIAL_USE</code> with an ongoing notification.</li>
                <li><strong>Notification Channel:</strong> Bound to <code className="text-cyan-400">autopilot_assistant_channel</code> with LOW importance so it stays silent.</li>
                <li><strong>Battery Optimization:</strong> Requests <code className="text-cyan-400">REQUEST_IGNORE_BATTERY_OPTIMIZATIONS</code> whitelist.</li>
                <li><strong>Overlay Permission:</strong> Granted via <code className="text-cyan-400">Settings.ACTION_MANAGE_OVERLAY_PERMISSION</code>.</li>
              </ol>
            </div>
          )}
        </div>

        {/* EXPLANATION OF FEATURES THAT CANNOT REMAIN ACTIVE UNDER ANDROID RESTRICTIONS */}
        <div className="p-4 rounded-xl bg-amber-950/30 border border-amber-600/40 text-amber-200 text-xs space-y-2.5">
          <div className="flex items-center gap-1.5 font-bold text-amber-300">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <span>Important System Limitations (What Android Does Not Allow):</span>
          </div>
          <p className="text-[11px] text-amber-200/90 leading-relaxed">
            As a genuine Android application, AI AutoPilot respects official Android security boundaries. The following features cannot stay active under system restrictions:
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[10px] text-amber-100">
            <div className="p-2 rounded bg-black/40 border border-amber-900/40 space-y-1">
              <strong className="text-amber-300 block">1. Touch Injection When Screen is OFF</strong>
              <p className="text-slate-300">Android kernel suspends Accessibility gesture dispatch when the screen is locked or asleep to prevent pocket dialing and save power.</p>
            </div>
            <div className="p-2 rounded bg-black/40 border border-amber-900/40 space-y-1">
              <strong className="text-amber-300 block">2. Screen Capture Without Consent Dialog</strong>
              <p className="text-slate-300">Android 14+ requires an interactive user confirmation dialog every session before granting VirtualDisplay screen capture.</p>
            </div>
            <div className="p-2 rounded bg-black/40 border border-amber-900/40 space-y-1">
              <strong className="text-amber-300 block">3. Launching Apps Without Notification Tap</strong>
              <p className="text-slate-300">Android 10+ blocks background services from launching new activities directly; the user must tap the ongoing notification.</p>
            </div>
            <div className="p-2 rounded bg-black/40 border border-amber-900/40 space-y-1">
              <strong className="text-amber-300 block">4. Non-Gaming App Automation</strong>
              <p className="text-slate-300">AutoPilot strictly blocks automation on banking, system settings, or personal messaging apps to maintain total account safety.</p>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
};
