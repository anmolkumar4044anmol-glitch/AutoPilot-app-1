import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Cpu, 
  Activity, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw, 
  ArrowRight, 
  Lock,
  Layers,
  Sparkles,
  Zap,
  BatteryCharging,
  HardDrive,
  Clock,
  AlertTriangle,
  RotateCcw,
  Check,
  XCircle,
  HelpCircle,
  MessageSquare,
  Flame,
  Plus
} from 'lucide-react';
import { 
  AdaptiveStrategy, 
  TaskPlan, 
  TaskStep, 
  ConstraintItem, 
  RecoveryRecord, 
  UserCorrection 
} from '../../types/autopilot';
import { requestReplanning, requestUserCorrection } from '../../services/api';

interface AdaptiveIntelligenceTabProps {
  activePlan: TaskPlan | null;
  onUpdatePlan: (plan: TaskPlan) => void;
  currentStepIndex: number;
  status: string;
}

export const AdaptiveIntelligenceTab: React.FC<AdaptiveIntelligenceTabProps> = ({
  activePlan,
  onUpdatePlan,
  currentStepIndex,
  status,
}) => {
  const [selectedConstraintTest, setSelectedConstraintTest] = useState('Do not close the current application');
  const [testConstraintOutput, setTestConstraintOutput] = useState<string | null>(null);
  const [correctionInput, setCorrectionInput] = useState('');
  const [selectedStepToCorrect, setSelectedStepToCorrect] = useState<string>('');
  const [isReplanning, setIsReplanning] = useState(false);
  const [isApplyingCorrection, setIsApplyingCorrection] = useState(false);

  // Default hard constraints if not populated
  const hardConstraints: ConstraintItem[] = activePlan?.hardConstraints && activePlan.hardConstraints.length > 0
    ? activePlan.hardConstraints
    : [
        {
          id: 'hc-1',
          text: 'Do not close the current application',
          type: 'hard_constraint',
          isViolated: false,
          status: 'enforced',
          explanation: 'Actions remain strictly constrained within the active application window.',
        },
        {
          id: 'hc-2',
          text: 'Do not switch applications',
          type: 'hard_constraint',
          isViolated: false,
          status: 'enforced',
          explanation: 'Home and App-Switcher key events are blocked during execution.',
        },
        {
          id: 'hc-3',
          text: 'Do not send a message without confirmation',
          type: 'safety_boundary',
          isViolated: false,
          status: 'enforced',
          explanation: 'Outbound communications require explicit user verification.',
        },
        {
          id: 'hc-4',
          text: 'Do not delete files',
          type: 'hard_constraint',
          isViolated: false,
          status: 'enforced',
          explanation: 'File system destruction and cache wiping intents are prohibited.',
        },
        {
          id: 'hc-5',
          text: 'Stop before making a payment',
          type: 'hard_constraint',
          isViolated: false,
          status: 'enforced',
          explanation: 'Financial authorizations immediately trigger emergency pause.',
        },
        {
          id: 'hc-6',
          text: 'Do not repeat a completed action',
          type: 'hard_constraint',
          isViolated: false,
          status: 'enforced',
          explanation: 'Verified step checkpoints prevent duplicate clicks or slider adjustments.',
        },
      ];

  // Default comparative strategies
  const strategies: AdaptiveStrategy[] = activePlan?.adaptiveStrategies && activePlan.adaptiveStrategies.length > 0
    ? activePlan.adaptiveStrategies
    : [
        {
          name: 'Accessibility Node Traversal',
          reliabilityScore: 97,
          safetyScore: 99,
          estimatedTime: '1.8s',
          timeMs: 1800,
          batteryImpact: 'very_low',
          memoryImpactKb: 380,
          description: 'Directly reads Android View hierarchy for exact viewId and text. Immune to resolution variations.',
          tradeoffSummary: 'Fastest, zero battery drain, and best for 4GB RAM phones.',
          isPermitted: true,
          isBest: true,
        },
        {
          name: 'Bézier Coordinate Simulator',
          reliabilityScore: 92,
          safetyScore: 96,
          estimatedTime: '2.6s',
          timeMs: 2600,
          batteryImpact: 'low',
          memoryImpactKb: 650,
          description: 'Dispatches humanized curved thumb sweeps with randomized reaction jitter to avoid anti-cheat flags.',
          tradeoffSummary: 'Essential for custom game HUDs like Free Fire where nodes are masked.',
          isPermitted: true,
        },
        {
          name: 'Visual Pattern Match (OCR Fallback)',
          reliabilityScore: 86,
          safetyScore: 92,
          estimatedTime: '4.2s',
          timeMs: 4200,
          batteryImpact: 'medium',
          memoryImpactKb: 1400,
          description: 'Scans frame buffers for icon contours if screen elements drift unexpectedly.',
          tradeoffSummary: 'Higher CPU & memory usage; only engaged if primary strategies fail.',
          isPermitted: true,
        },
      ];

  const steps = activePlan?.steps || [];
  const completedSteps = steps.slice(0, currentStepIndex);
  const currentStep = steps[currentStepIndex];
  const remainingSteps = steps.slice(currentStepIndex + 1);

  // Simulate screen drift and dynamic replanning
  const handleSimulateScreenDrift = async () => {
    if (!activePlan) return;
    setIsReplanning(true);
    const failedStepId = currentStep?.id || steps[0]?.id || 'step-1';
    const completedIds = completedSteps.map((s) => s.id);

    try {
      const replanResult = await requestReplanning(
        activePlan,
        failedStepId,
        'Settings modal shifted to dialog frame',
        completedIds
      );

      const updatedPlan: TaskPlan = {
        ...activePlan,
        steps: replanResult.steps,
        selectedStrategy: replanResult.selectedStrategy,
        screenDriftDetected: true,
        recoveryHistory: replanResult.recoveryHistory || activePlan.recoveryHistory,
        failedMethodsBlacklist: replanResult.failedMethodsBlacklist || activePlan.failedMethodsBlacklist,
      };

      onUpdatePlan(updatedPlan);
    } catch (e) {
      console.error(e);
    } finally {
      setIsReplanning(false);
    }
  };

  // Submit User Correction
  const handleApplyUserCorrection = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activePlan || !correctionInput.trim()) return;

    setIsApplyingCorrection(true);
    const stepId = selectedStepToCorrect || currentStep?.id || steps[0]?.id || 'step-1';

    try {
      const result = await requestUserCorrection(activePlan, stepId, correctionInput.trim());
      const updatedPlan: TaskPlan = {
        ...activePlan,
        steps: result.steps,
        userCorrections: result.userCorrections || activePlan.userCorrections,
      };
      onUpdatePlan(updatedPlan);
      setCorrectionInput('');
    } catch (e) {
      console.error(e);
    } finally {
      setIsApplyingCorrection(false);
    }
  };

  const handleTestConstraint = () => {
    if (selectedConstraintTest.includes('close')) {
      setTestConstraintOutput(
        'BLOCKED: Command "Close the app and exit" attempted. Hard constraint "Do not close the current application" is strictly enforced. Execution halted safely without closing foreground application.'
      );
    } else if (selectedConstraintTest.includes('delete')) {
      setTestConstraintOutput(
        'BLOCKED: Command "Delete game data files" attempted. Hard constraint "Do not delete files" intercepted. Potentially destructive action aborted.'
      );
    } else if (selectedConstraintTest.includes('payment')) {
      setTestConstraintOutput(
        'HALTED: Approaching in-app purchase dialog. Hard constraint "Stop before making a payment" triggered. Mandatory user biometric/PIN prompt required.'
      );
    } else {
      setTestConstraintOutput(
        `VERIFIED: Constraint "${selectedConstraintTest}" is active and enforced. All execution branches strictly conform.`
      );
    }
  };

  return (
    <div className="space-y-6">
      {/* 1. Header: AI Task Process Mission Card */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800/60 font-mono font-semibold">
                10-Step AI Process Engine
              </span>
              <span className="text-xs text-slate-400">
                Language: <strong className="text-white uppercase">{activePlan?.languageDetected || 'Hinglish / EN'}</strong>
              </span>
            </div>
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Cpu className="w-5 h-5 text-cyan-400" />
              <span>{activePlan?.taskName || 'Adaptive Task Intelligence'}</span>
            </h3>
            <p className="text-xs text-slate-300">
              <strong className="text-slate-400">Intended Result:</strong> {activePlan?.intendedResult || 'Execute permitted steps safely with verification and zero constraint violations.'}
            </p>
          </div>

          {/* Process Stage & Status Badge */}
          <div className="flex items-center gap-2">
            <div className="text-right">
              <span className="text-[10px] uppercase font-mono text-slate-400 block">Current AI Stage</span>
              <span className="text-xs font-bold text-emerald-400 font-mono">
                {status === 'GREEN_RUNNING' ? 'STAGE 7: EXECUTE STEP' : 'STAGE 6: SAFEST METHOD SELECTED'}
              </span>
            </div>
            <div className="w-10 h-10 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center">
              <Activity className="w-5 h-5 text-cyan-400 animate-pulse" />
            </div>
          </div>
        </div>

        {/* 10-Step Flow Indicators */}
        <div className="pt-3 border-t border-slate-800/80 overflow-x-auto pb-1">
          <div className="flex items-center gap-1 text-[10px] font-mono text-slate-400 whitespace-nowrap min-w-max">
            <span className="text-cyan-400 font-bold">1. Understand</span>
            <span>→</span>
            <span className="text-cyan-400 font-bold">2. Intent</span>
            <span>→</span>
            <span className="text-emerald-400 font-bold">3. Restrictions</span>
            <span>→</span>
            <span className="text-slate-300">4. Plan</span>
            <span>→</span>
            <span className="text-slate-300">5. Methods</span>
            <span>→</span>
            <span className="text-indigo-400 font-bold">6. Select Safest</span>
            <span>→</span>
            <span className={status === 'GREEN_RUNNING' ? 'text-amber-400 font-bold animate-pulse' : 'text-slate-300'}>
              7. Execute
            </span>
            <span>→</span>
            <span className="text-slate-300">8. Verify</span>
            <span>→</span>
            <span className="text-purple-400 font-bold">9. Replan/Recover</span>
            <span>→</span>
            <span className="text-emerald-400 font-bold">10. Report</span>
          </div>
        </div>
      </div>

      {/* 2. Visual Task-Planning Interface: Completed, Current, Remaining */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div>
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-cyan-400" />
              <span>Visual Task-Planning Timeline</span>
            </h4>
            <p className="text-xs text-slate-400 mt-0.5">
              Live progression of completed checkpoints, current action, and pending steps.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">
              Progress: <strong className="text-emerald-400">{completedSteps.length} / {steps.length} steps</strong>
            </span>
          </div>
        </div>

        {/* CURRENT ACTION (Pulsing Card) */}
        {currentStep && (
          <div className="p-4 rounded-xl bg-gradient-to-r from-cyan-950/60 to-slate-950 border-2 border-cyan-500 shadow-lg shadow-cyan-950/50 space-y-2 animate-pulse">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping"></span>
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  CURRENT ACTION: {currentStep.action.toUpperCase()}
                </span>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-900 text-cyan-300 border border-cyan-700">
                Step {currentStepIndex + 1} of {steps.length}
              </span>
            </div>

            <p className="text-sm font-semibold text-white">{currentStep.description}</p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px] text-slate-300 pt-1">
              <div>
                <span className="text-slate-500 block text-[10px]">Target:</span>
                <strong className="text-cyan-300">{currentStep.target}</strong>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">Verification Criterion:</span>
                <span className="text-emerald-400 font-medium">{currentStep.verification}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">Estimated Duration:</span>
                <span className="font-mono text-slate-300">~{currentStep.estimatedTimeMs} ms</span>
              </div>
            </div>
          </div>
        )}

        {/* Timeline Columns: Completed vs Remaining */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          {/* COMPLETED STEPS */}
          <div className="p-4 rounded-xl bg-slate-950 border border-emerald-900/40 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" />
                <span>Completed Steps ({completedSteps.length})</span>
              </span>
              <span className="text-[10px] font-mono text-slate-500">Verified</span>
            </div>

            {completedSteps.length === 0 ? (
              <p className="text-xs text-slate-500 italic py-2">No steps completed yet. Press ACTIVATE to run.</p>
            ) : (
              <div className="space-y-2">
                {completedSteps.map((step, idx) => (
                  <div
                    key={step.id}
                    className="p-2.5 rounded-lg bg-slate-900/60 border border-emerald-800/40 text-xs text-slate-300 flex items-start justify-between gap-2"
                  >
                    <div className="space-y-0.5">
                      <span className="font-medium text-white flex items-center gap-1">
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Step {idx + 1}: {step.target}</span>
                      </span>
                      <p className="text-[11px] text-slate-400 pl-4">{step.description}</p>
                    </div>
                    <span className="text-[10px] font-mono text-emerald-400 whitespace-nowrap bg-emerald-950 px-1.5 py-0.5 rounded">
                      PASS
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* REMAINING STEPS */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-cyan-400" />
                <span>Remaining Steps ({remainingSteps.length})</span>
              </span>
              <span className="text-[10px] font-mono text-slate-500">Scheduled</span>
            </div>

            {remainingSteps.length === 0 ? (
              <p className="text-xs text-slate-500 italic py-2">
                {currentStep ? 'Final step in execution.' : 'All steps completed!'}
              </p>
            ) : (
              <div className="space-y-2">
                {remainingSteps.map((step, idx) => (
                  <div
                    key={step.id}
                    className="p-2.5 rounded-lg bg-slate-900/40 border border-slate-800/80 text-xs text-slate-400 flex items-start justify-between gap-2"
                  >
                    <div>
                      <span className="font-medium text-slate-300">
                        Step {currentStepIndex + 2 + idx}: {step.target}
                      </span>
                      <p className="text-[11px] text-slate-500">{step.description}</p>
                    </div>
                    <span className="text-[10px] font-mono text-slate-500 whitespace-nowrap">
                      ~{step.estimatedTimeMs}ms
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 3. Strict User Instructions / Hard Constraints Sentinel */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div>
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <Lock className="w-4 h-4 text-emerald-400" />
              <span>Strict User Instructions (Hard Constraints Sentinel)</span>
            </h4>
            <p className="text-xs text-slate-400 mt-0.5">
              Explicit restrictions are enforced as unbreakable gates. If no permitted method exists, AutoPilot stops and explains why.
            </p>
          </div>
        </div>

        {/* Constraints Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {hardConstraints.map((hc) => (
            <div
              key={hc.id}
              className={`p-3 rounded-xl border flex flex-col justify-between ${
                hc.isViolated
                  ? 'bg-rose-950/40 border-rose-500'
                  : 'bg-slate-950 border-emerald-900/40'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <span className="text-xs font-bold text-white">{hc.text}</span>
                  {hc.isViolated ? (
                    <span className="text-[9px] uppercase font-mono px-1.5 py-0.5 rounded bg-rose-500 text-white font-bold">
                      VIOLATION
                    </span>
                  ) : (
                    <span className="text-[9px] uppercase font-mono px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                      ENFORCED
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-slate-400">{hc.explanation}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Interactive Constraint Tester */}
        <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 space-y-3">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
            <select
              value={selectedConstraintTest}
              onChange={(e) => setSelectedConstraintTest(e.target.value)}
              className="flex-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-500"
            >
              <option value="Do not close the current application">
                Test Hard Gate: &quot;Do not close the current application&quot;
              </option>
              <option value="Do not delete files">
                Test Hard Gate: &quot;Do not delete files&quot;
              </option>
              <option value="Stop before making a payment">
                Test Hard Gate: &quot;Stop before making a payment&quot;
              </option>
              <option value="Do not switch applications">
                Test Hard Gate: &quot;Do not switch applications&quot;
              </option>
            </select>

            <button
              onClick={handleTestConstraint}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold whitespace-nowrap shadow"
            >
              Trigger Constraint Gate Test
            </button>
          </div>

          {testConstraintOutput && (
            <div className={`p-3 rounded-xl border text-xs flex items-start gap-2 ${
              testConstraintOutput.startsWith('BLOCKED') || testConstraintOutput.startsWith('HALTED')
                ? 'bg-rose-950/40 border-rose-500/50 text-rose-300'
                : 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300'
            }`}>
              <ShieldCheck className="w-4 h-4 shrink-0 mt-0.5 text-current" />
              <span>{testConstraintOutput}</span>
            </div>
          )}
        </div>
      </div>

      {/* 4. Comparative Strategy Matrix (Time, Reliability, Battery, Memory Trade-offs) */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div>
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <Activity className="w-4 h-4 text-cyan-400" />
              <span>Multi-Approach Trade-Off Evaluation (Time, Reliability, Battery &amp; Memory)</span>
            </h4>
            <p className="text-xs text-slate-400 mt-0.5">
              The engine compares permitted methods against hardware metrics and selects the optimal approach.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {strategies.map((strat, idx) => {
            const isSelected = activePlan?.selectedStrategy
              ? activePlan.selectedStrategy.includes(strat.name)
              : idx === 0;

            return (
              <div
                key={idx}
                className={`p-4 rounded-xl border flex flex-col justify-between ${
                  isSelected
                    ? 'bg-gradient-to-b from-cyan-950/50 to-slate-950 border-cyan-500 shadow-lg shadow-cyan-950/40'
                    : 'bg-slate-950/60 border-slate-800'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between gap-1 mb-2">
                    <span className="text-xs font-bold text-white">{strat.name}</span>
                    {isSelected && (
                      <span className="text-[9px] uppercase font-mono px-2 py-0.5 rounded bg-cyan-500 text-slate-950 font-bold whitespace-nowrap">
                        SELECTED
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">{strat.description}</p>
                </div>

                {/* Hardware Metrics Comparison */}
                <div className="mt-4 pt-3 border-t border-slate-800/80 space-y-2 text-xs">
                  {/* Reliability Bar */}
                  <div>
                    <div className="flex items-center justify-between text-[11px] mb-1">
                      <span className="text-slate-400">Reliability:</span>
                      <span className="font-mono font-bold text-emerald-400">{strat.reliabilityScore}%</span>
                    </div>
                    <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-emerald-500 rounded-full"
                        style={{ width: `${strat.reliabilityScore}%` }}
                      />
                    </div>
                  </div>

                  {/* Latency & Battery & Memory */}
                  <div className="grid grid-cols-3 gap-1 pt-1 text-[10px] text-slate-400">
                    <div className="p-1.5 rounded bg-slate-900 border border-slate-800/80 text-center">
                      <span className="text-slate-500 block">Time</span>
                      <strong className="text-white font-mono">{strat.estimatedTime}</strong>
                    </div>
                    <div className="p-1.5 rounded bg-slate-900 border border-slate-800/80 text-center">
                      <span className="text-slate-500 block">Battery</span>
                      <strong className="text-amber-400 font-mono capitalize">{strat.batteryImpact}</strong>
                    </div>
                    <div className="p-1.5 rounded bg-slate-900 border border-slate-800/80 text-center">
                      <span className="text-slate-500 block">RAM</span>
                      <strong className="text-cyan-400 font-mono">{strat.memoryImpactKb} KB</strong>
                    </div>
                  </div>

                  <p className="text-[10px] text-slate-500 italic mt-1">{strat.tradeoffSummary}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 5. Errors, Screen Drift & Dynamic Replanning Console */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div>
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <RefreshCw className="w-4 h-4 text-amber-400" />
              <span>Screen Drift Detection &amp; Autonomous Replanning</span>
            </h4>
            <p className="text-xs text-slate-400 mt-0.5">
              Recognizes when the screen differs from expectations and switches to alternative permitted methods without repeating actions.
            </p>
          </div>

          <button
            onClick={handleSimulateScreenDrift}
            disabled={isReplanning}
            className="px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow transition-all disabled:opacity-50"
          >
            {isReplanning ? (
              <>
                <span className="w-3.5 h-3.5 border-2 border-white/20 border-t-white rounded-full animate-spin"></span>
                <span>Replanning Remaining Steps...</span>
              </>
            ) : (
              <>
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Simulate Screen Drift / Replan</span>
              </>
            )}
          </button>
        </div>

        {/* Recovery Log History */}
        <div className="space-y-2">
          <span className="text-xs font-bold text-slate-300 block">Dynamic Recovery Log:</span>
          {activePlan?.recoveryHistory && activePlan.recoveryHistory.length > 0 ? (
            <div className="space-y-2">
              {activePlan.recoveryHistory.map((rec) => (
                <div
                  key={rec.id}
                  className="p-3 rounded-xl bg-slate-950 border border-amber-900/40 text-xs flex items-start justify-between gap-3 font-mono"
                >
                  <div className="space-y-1">
                    <span className="text-amber-400 font-bold block">{rec.errorDescription}</span>
                    <span className="text-slate-300 block font-sans">{rec.recoveryAction}</span>
                    <span className="text-[10px] text-cyan-400">Switched Strategy: {rec.recoveredStrategy}</span>
                  </div>
                  <span className="text-[10px] text-slate-500 whitespace-nowrap">{rec.timestamp}</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-slate-500 italic p-3 bg-slate-950 rounded-xl border border-slate-800">
              No errors detected. Primary strategy executing on expected screen nodes. Tap &quot;Simulate Screen Drift / Replan&quot; to test.
            </p>
          )}
        </div>

        {/* Remembered Failed Approaches Blacklist */}
        {activePlan?.failedMethodsBlacklist && activePlan.failedMethodsBlacklist.length > 0 && (
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-1">
            <span className="text-slate-400 font-semibold flex items-center gap-1">
              <XCircle className="w-3.5 h-3.5 text-rose-400" />
              <span>Remembered Failed Approaches (Blacklisted to Avoid Repeating Mistakes):</span>
            </span>
            <div className="flex items-center gap-1.5 flex-wrap pt-1">
              {activePlan.failedMethodsBlacklist.map((item, i) => (
                <span
                  key={i}
                  className="px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-900 text-[10px] font-mono"
                >
                  {item}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* 6. Learning from User Corrections */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <h4 className="text-sm font-bold text-white flex items-center gap-2">
          <MessageSquare className="w-4 h-4 text-purple-400" />
          <span>Learning from User Corrections</span>
        </h4>
        <p className="text-xs text-slate-400">
          Provide a real-time correction if a target or button location needs adjustment. AutoPilot memorizes the correction to improve future decisions.
        </p>

        <form onSubmit={handleApplyUserCorrection} className="flex flex-col sm:flex-row gap-2">
          <select
            value={selectedStepToCorrect}
            onChange={(e) => setSelectedStepToCorrect(e.target.value)}
            className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs"
          >
            {steps.map((s, idx) => (
              <option key={s.id} value={s.id}>
                Step {idx + 1}: {s.target}
              </option>
            ))}
          </select>

          <input
            type="text"
            value={correctionInput}
            onChange={(e) => setCorrectionInput(e.target.value)}
            placeholder="Enter correction (e.g., 'Tap top-right cog icon named Settings')..."
            className="flex-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-500"
          />

          <button
            type="submit"
            disabled={isApplyingCorrection || !correctionInput.trim()}
            className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold shadow disabled:opacity-50"
          >
            Learn Correction
          </button>
        </form>

        {activePlan?.userCorrections && activePlan.userCorrections.length > 0 && (
          <div className="space-y-1.5 pt-2">
            <span className="text-xs font-bold text-slate-300 block">Learned Corrections Memory:</span>
            {activePlan.userCorrections.map((corr) => (
              <div
                key={corr.id}
                className="p-2.5 rounded-xl bg-slate-950 border border-purple-800/40 text-xs text-purple-200 flex items-center justify-between"
              >
                <span>✓ {corr.learnedRule}</span>
                <span className="text-[10px] text-slate-500">{corr.timestamp}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 7. Final Result & Completion Report */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-3">
        <h4 className="text-sm font-bold text-white flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>Final Result &amp; Execution Report</span>
        </h4>

        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
          <div className="flex items-center justify-between">
            <span className="text-slate-400">Final Task Status:</span>
            <span className="text-emerald-400 font-bold font-mono uppercase">
              {activePlan?.completionReport?.status || 'Active / In-Flight'}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-slate-400">Report Explanation:</span>
            <span className="text-white">
              {activePlan?.completionReport?.explanation || 'Task actively monitored. Checkpoints executing under strict constraints.'}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-slate-400">Permitted Constraints Adhered:</span>
            <span className="text-emerald-400 font-mono font-semibold">100% (0 Violations)</span>
          </div>
        </div>
      </div>
    </div>
  );
};
