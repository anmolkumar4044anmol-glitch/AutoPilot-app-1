import React, { useState } from 'react';
import { 
  BookOpen, 
  Video, 
  ShieldCheck, 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowRight,
  Flame,
  Plus
} from 'lucide-react';
import { requestVideoLearning } from '../../services/api';
import { WorkflowItem } from '../../types/autopilot';

interface VideoLearningTabProps {
  onSaveNewWorkflow: (workflow: WorkflowItem) => void;
}

export const VideoLearningTab: React.FC<VideoLearningTabProps> = ({
  onSaveNewWorkflow,
}) => {
  const [videoUrl, setVideoUrl] = useState('https://www.youtube.com/watch?v=freefire_fast_gloo_tutorial');
  const [transcriptText, setTranscriptText] = useState(
    'In this tutorial, to do instant gloo wall drop: First press the fire button while dragging aim upwards. Then immediately swipe down towards player feet. Tap the gloo wall icon and crouch at the same time. Finally tap the deploy trigger. This gives 110ms defense reaction.'
  );
  const [isProcessing, setIsProcessing] = useState(false);
  const [learningResult, setLearningResult] = useState<any | null>(null);

  const handleProcessVideo = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    try {
      const data = await requestVideoLearning(videoUrl, transcriptText, 'Free Fire Fast Gloo Wall Tutorial');
      setLearningResult(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleAddAsWorkflow = () => {
    if (!learningResult) return;
    const newWorkflow: WorkflowItem = {
      id: `wf-learned-${Date.now()}`,
      title: learningResult.createdWorkflowName || 'Learned Video Macro',
      category: 'learning',
      description: `Learned from verified video tutorial (${learningResult.confidenceScore}% confidence).`,
      stepsCount: learningResult.extractedSteps.length,
      lastUsed: 'Just now',
      isRestrictedToFreeFire: true,
      steps: learningResult.extractedSteps.map((s: any, idx: number) => ({
        id: `learned-step-${idx}`,
        action: 'tap',
        target: `Gesture ${idx + 1}: ${s.gesture.slice(0, 24)}`,
        description: s.gesture,
        estimatedTimeMs: s.timingMs || 200,
        verification: s.safetyNote || 'Executed within human limits',
        riskLevel: 'safe',
      })),
    };
    onSaveNewWorkflow(newWorkflow);
    alert('Workflow verified and saved to Workflow Memory!');
  };

  return (
    <div className="space-y-6">
      {/* Overview Card */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-950/60 border border-purple-800/60 text-purple-400 flex items-center justify-center">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">Experimental Task &amp; Video Learning Engine</h3>
            <p className="text-xs text-slate-400">
              Extracts high-precision Android macros and tutorials from approved video transcripts &amp; recordings.
            </p>
          </div>
        </div>

        {/* Safety Boundary Notice (Requirement 3) */}
        <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 flex items-start gap-2.5">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          <div>
            <strong className="text-white block mb-0.5">Anti-Malicious Verification Rule:</strong>
            AutoPilot never blindly executes instructions from unknown videos. All extracted actions undergo permission screening, credential blacklisting, and explicit user approval before execution.
          </div>
        </div>
      </div>

      {/* Video URL or Transcript Input */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <h4 className="text-sm font-bold text-white flex items-center gap-2">
          <Video className="w-4 h-4 text-cyan-400" />
          <span>Video Link or Tutorial Transcript Parser</span>
        </h4>

        <form onSubmit={handleProcessVideo} className="space-y-3">
          <div>
            <label className="text-xs text-slate-400 block mb-1">Video Tutorial URL:</label>
            <input
              type="text"
              value={videoUrl}
              onChange={(e) => setVideoUrl(e.target.value)}
              placeholder="https://www.youtube.com/watch?v=..."
              className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div>
            <label className="text-xs text-slate-400 block mb-1">Transcript or Screen Recording Description:</label>
            <textarea
              rows={3}
              value={transcriptText}
              onChange={(e) => setTranscriptText(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-500 font-mono"
            />
          </div>

          <button
            type="submit"
            disabled={isProcessing}
            className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs transition-colors flex items-center gap-2 shadow disabled:opacity-50"
          >
            {isProcessing ? (
              <>
                <span className="w-3.5 h-3.5 border-2 border-white/20 border-t-white rounded-full animate-spin"></span>
                <span>Extracting &amp; Validating Steps...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Extract Reusable Workflow</span>
              </>
            )}
          </button>
        </form>
      </div>

      {/* Extracted Steps & Approval Card */}
      {learningResult && (
        <div className="p-5 rounded-2xl bg-slate-900 border border-purple-800/40 shadow-xl space-y-4 animate-fadeIn">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
            <div>
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <span>{learningResult.workflowTitle}</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800/60 font-mono">
                  Confidence: {learningResult.confidenceScore}%
                </span>
              </h4>
              <p className="text-xs text-slate-400 mt-0.5">{learningResult.notes}</p>
            </div>

            <button
              onClick={handleAddAsWorkflow}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow whitespace-nowrap"
            >
              <Plus className="w-4 h-4" />
              <span>Approve &amp; Save Workflow</span>
            </button>
          </div>

          <div className="space-y-2">
            {learningResult.extractedSteps.map((step: any, i: number) => (
              <div
                key={i}
                className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-3 text-xs"
              >
                <div className="w-6 h-6 rounded-full bg-purple-950 text-purple-300 border border-purple-800 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                  {step.stepNumber}
                </div>
                <div className="flex-1">
                  <span className="text-white font-medium block">{step.gesture}</span>
                  <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-1">
                    <span className="text-cyan-400 font-mono">Timing: {step.timingMs} ms</span>
                    <span>•</span>
                    <span className="text-emerald-400">{step.safetyNote}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
