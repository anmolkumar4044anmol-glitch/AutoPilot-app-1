import React from 'react';
import { 
  History, 
  Flame, 
  Play, 
  ShieldCheck, 
  Clock, 
  Trash2, 
  Layers, 
  Sparkles,
  Lock
} from 'lucide-react';
import { WorkflowItem } from '../../types/autopilot';

interface WorkflowMemoryTabProps {
  workflows: WorkflowItem[];
  onTriggerWorkflow: (workflow: WorkflowItem) => void;
  onDeleteWorkflow: (id: string) => void;
}

export const WorkflowMemoryTab: React.FC<WorkflowMemoryTabProps> = ({
  workflows,
  onTriggerWorkflow,
  onDeleteWorkflow,
}) => {
  return (
    <div className="space-y-6">
      {/* Overview Card */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-950/60 border border-amber-800/60 text-amber-400 flex items-center justify-center">
            <History className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">Workflow Memory &amp; Free Fire Presets</h3>
            <p className="text-xs text-slate-400">
              Locally stored, verified routines that execute 100% offline without requiring internet access.
            </p>
          </div>
        </div>

        {/* Free Fire Sandbox Rule Indicator (Requirement 12) */}
        <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-500/30 text-xs text-amber-300 flex items-start gap-2">
          <Lock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <strong className="block text-white mb-0.5">Strict App Boundary Policy:</strong>
            Macros in this library operate exclusively inside <strong>Free Fire India</strong>. Executing actions outside of Free Fire requires an explicit natural language instruction from you.
          </div>
        </div>
      </div>

      {/* Saved Workflows List */}
      <div className="space-y-3">
        {workflows.map((wf) => {
          const isFreeFire = wf.category === 'free_fire' || wf.category === 'learning';
          return (
            <div
              key={wf.id}
              className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
            >
              <div className="space-y-1.5 flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                    {isFreeFire && <Flame className="w-4 h-4 text-amber-500" />}
                    <span>{wf.title}</span>
                  </h4>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                    {wf.stepsCount} steps
                  </span>
                  {wf.isRestrictedToFreeFire && (
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-950 text-amber-400 border border-amber-800/60">
                      Free Fire Only
                    </span>
                  )}
                </div>

                <p className="text-xs text-slate-400">{wf.description}</p>

                <div className="flex items-center gap-3 text-[11px] text-slate-500 pt-1">
                  <span>Last used: {wf.lastUsed || 'Recent'}</span>
                  <span>•</span>
                  <span className="text-emerald-400 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" /> Offline Verified
                  </span>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-2 self-stretch md:self-auto justify-end">
                <button
                  onClick={() => onTriggerWorkflow(wf)}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Execute Workflow</span>
                </button>

                {wf.id.startsWith('wf-learned') && (
                  <button
                    onClick={() => onDeleteWorkflow(wf.id)}
                    className="p-2.5 rounded-xl bg-slate-800 hover:bg-rose-950 text-slate-400 hover:text-rose-400 border border-slate-700 transition-colors"
                    title="Delete custom workflow"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
