import React, { useState } from 'react';
import { 
  Download, 
  FileCode, 
  CheckCircle2, 
  ExternalLink, 
  Copy, 
  Terminal, 
  Smartphone, 
  ShieldCheck,
  Sparkles,
  Layers,
  ArrowRight
} from 'lucide-react';
import { ANDROID_PROJECT_FILES, AndroidFileRecord } from '../../data/androidFiles';
import { generateAndroidProjectZip, downloadBlobAsFile } from '../../services/zipGenerator';

export const ApkStudioTab: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<AndroidFileRecord>(ANDROID_PROJECT_FILES[0]);
  const [isZipping, setIsZipping] = useState(false);
  const [zipProgress, setZipProgress] = useState(0);
  const [copied, setCopied] = useState(false);

  const handleDownloadZip = async () => {
    setIsZipping(true);
    setZipProgress(10);
    try {
      const blob = await generateAndroidProjectZip((p) => setZipProgress(p));
      downloadBlobAsFile(blob, 'AI-AutoPilot-Android-Source.zip');
    } catch (err) {
      console.error('ZIP generation error:', err);
      alert('Failed to generate ZIP file.');
    } finally {
      setIsZipping(false);
    }
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & 1-Click Download Button */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800 font-mono font-semibold">
                Cloud APK Build System
              </span>
              <span className="text-xs text-slate-400">• Android 8.0 to 14+</span>
            </div>
            <h3 className="text-lg font-bold text-white">Genuine Android APK Builder Studio</h3>
            <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">
              No laptop or programming knowledge needed. Built for Android phone users. Download the complete ready-to-build Android source package or let GitHub Actions build the genuine APK in 3 minutes.
            </p>
          </div>

          {/* Big Download ZIP button */}
          <button
            onClick={handleDownloadZip}
            disabled={isZipping}
            className="w-full md:w-auto px-6 py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-xl shadow-emerald-950/50 transition-all active:scale-95 disabled:opacity-50"
          >
            {isZipping ? (
              <>
                <span className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin"></span>
                <span>Packaging Project ({zipProgress}%)...</span>
              </>
            ) : (
              <>
                <Download className="w-5 h-5" />
                <span>DOWNLOAD ANDROID PROJECT (.ZIP)</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* 4-Step Beginner's Guide to Build APK on Mobile Phone */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <h4 className="text-sm font-bold text-white flex items-center gap-2">
          <Smartphone className="w-4 h-4 text-cyan-400" />
          <span>Simple 4-Step Guide: How to Get Your APK on Android Phone (No Laptop Required!)</span>
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
          {/* Step 1 */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="w-7 h-7 rounded-lg bg-cyan-950 text-cyan-400 font-bold flex items-center justify-center border border-cyan-800">
              1
            </div>
            <h5 className="font-bold text-white">Download ZIP File</h5>
            <p className="text-slate-400 leading-relaxed text-[11px]">
              Tap the green <strong>&quot;DOWNLOAD ANDROID PROJECT (.ZIP)&quot;</strong> button above. It saves directly into your phone&apos;s Downloads folder.
            </p>
          </div>

          {/* Step 2 */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="w-7 h-7 rounded-lg bg-indigo-950 text-indigo-400 font-bold flex items-center justify-center border border-indigo-800">
              2
            </div>
            <h5 className="font-bold text-white">Open GitHub in Mobile Browser</h5>
            <p className="text-slate-400 leading-relaxed text-[11px]">
              Go to <span className="text-indigo-400 font-mono">github.com</span> on Chrome on your phone. Create a new free repository named <strong className="text-white">AI-AutoPilot</strong>.
            </p>
          </div>

          {/* Step 3 */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="w-7 h-7 rounded-lg bg-purple-950 text-purple-400 font-bold flex items-center justify-center border border-purple-800">
              3
            </div>
            <h5 className="font-bold text-white">Upload &amp; Auto-Build</h5>
            <p className="text-slate-400 leading-relaxed text-[11px]">
              Upload the files. GitHub Actions immediately detects <strong className="text-white">build-apk.yml</strong> and starts compiling the APK in the cloud for free!
            </p>
          </div>

          {/* Step 4 */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-950 text-emerald-400 font-bold flex items-center justify-center border border-emerald-800">
              4
            </div>
            <h5 className="font-bold text-white">Download APK &amp; Install</h5>
            <p className="text-slate-400 leading-relaxed text-[11px]">
              Open the <strong>Actions</strong> tab on GitHub, tap <strong>AI-AutoPilot-Debug-APK</strong>, download the <span className="text-emerald-400 font-mono font-bold">.apk</span>, and tap Install!
            </p>
          </div>
        </div>
      </div>

      {/* Interactive Android Codebase Explorer */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <FileCode className="w-4 h-4 text-cyan-400" />
              <span>Native Android Codebase Inspector</span>
            </h4>
            <p className="text-xs text-slate-400 mt-0.5">
              Inspect any Android Kotlin file, layout XML, Gradle script, or GitHub Actions workflow.
            </p>
          </div>

          <button
            onClick={handleCopyCode}
            className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 border border-slate-700 self-start sm:self-auto"
          >
            {copied ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied!' : 'Copy Code'}</span>
          </button>
        </div>

        {/* File Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 border-b border-slate-800">
          {ANDROID_PROJECT_FILES.map((file) => {
            const isSelected = selectedFile.path === file.path;
            return (
              <button
                key={file.path}
                onClick={() => setSelectedFile(file)}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-cyan-950 text-cyan-300 border border-cyan-700 font-bold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                {file.name}
              </button>
            );
          })}
        </div>

        {/* Selected File Description */}
        <div className="text-xs text-slate-300 p-2.5 rounded-lg bg-slate-950/70 border border-slate-800">
          <strong className="text-cyan-400 font-mono">{selectedFile.path}:</strong> {selectedFile.description}
        </div>

        {/* Code Content */}
        <div className="relative rounded-xl overflow-hidden border border-slate-800 bg-slate-950">
          <pre className="p-4 text-xs font-mono text-slate-300 overflow-x-auto max-h-[380px] leading-relaxed select-text">
            <code>{selectedFile.content}</code>
          </pre>
        </div>
      </div>
    </div>
  );
};
