import React, { useState } from 'react';
import { 
  Cpu, 
  BatteryCharging, 
  Flame, 
  Wifi, 
  ShieldCheck, 
  Layers, 
  Sparkles, 
  Zap, 
  CheckCircle2, 
  AlertTriangle, 
  Gauge, 
  Clock, 
  Radio, 
  Smartphone, 
  RefreshCw, 
  HardDrive, 
  Activity, 
  Minimize2, 
  Sliders, 
  Info,
  Check,
  ChevronRight,
  TrendingDown,
  Snowflake
} from 'lucide-react';
import { 
  AdaptivePerformanceSettings, 
  DeviceRecommendation, 
  PerformanceMetrics, 
  DeviceMode 
} from '../../types/autopilot';
import { 
  LITE_MODE_DEFAULTS, 
  ADVANCED_MODE_DEFAULTS 
} from '../../data/defaultPerformanceSettings';

interface PerformanceTabProps {
  settings: AdaptivePerformanceSettings;
  onUpdateSettings: (newSettings: Partial<AdaptivePerformanceSettings>) => void;
  metrics: PerformanceMetrics;
  recommendation: DeviceRecommendation;
  onApplyRecommendation: (rec: DeviceRecommendation) => void;
  onResetDefaults: (mode: DeviceMode) => void;
  isExecuting?: boolean;
}

export const PerformanceTab: React.FC<PerformanceTabProps> = ({
  settings,
  onUpdateSettings,
  metrics,
  recommendation,
  onApplyRecommendation,
  onResetDefaults,
  isExecuting = false,
}) => {
  const [activeSubSection, setActiveSubSection] = useState<'profiles' | 'battery' | 'network' | 'telemetry'>('profiles');
  const [simulationState, setSimulationState] = useState<'normal' | 'gaming_load' | 'idle_sleeping'>('normal');
  const [simulationMessage, setSimulationMessage] = useState<string>('System running nominal background profile.');

  // Handle mode switch between 4GB Lite and 8GB Advanced
  const handleSelectMode = (newMode: DeviceMode) => {
    if (newMode === 'lite') {
      onUpdateSettings(LITE_MODE_DEFAULTS);
    } else {
      onUpdateSettings(ADVANCED_MODE_DEFAULTS);
    }
  };

  const handleSimulateLoad = (type: 'gaming_load' | 'idle_sleeping' | 'normal') => {
    setSimulationState(type);
    if (type === 'gaming_load') {
      setSimulationMessage('⚡ Free Fire match load simulated: Frame loop active, cooldown throttle engaged, polling shifted to event-driven.');
    } else if (type === 'idle_sleeping') {
      setSimulationMessage('💤 Idle reduction triggered: Screenshot capture stopped, background polling sleep active, 0.0 FPS screen consumption.');
    } else {
      setSimulationMessage('System returned to default adaptive operational baseline.');
    }
  };

  const isLite = settings.mode === 'lite';

  return (
    <div className="space-y-6">
      {/* Overview & Mission Header */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-950 text-cyan-400 flex items-center justify-center border border-cyan-800/60 shadow-inner">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span>Adaptive Performance Manager</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
                  {isLite ? '4 GB Lite Mode' : '8 GB Advanced Mode'}
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Hardware-aware resource regulation, battery longevity preservation, and mobile data optimization.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleSelectMode('lite')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                isLite 
                  ? 'bg-amber-950/80 text-amber-300 border-amber-600 ring-1 ring-amber-500' 
                  : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
            >
              4 GB Lite
            </button>
            <button
              onClick={() => handleSelectMode('advanced')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                !isLite 
                  ? 'bg-indigo-950/80 text-indigo-300 border-indigo-600 ring-1 ring-indigo-500' 
                  : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
            >
              8 GB Advanced
            </button>
          </div>
        </div>

        {/* Automatic Device Recommendation Banner */}
        <div className="p-4 rounded-xl bg-gradient-to-r from-slate-950 via-slate-900 to-cyan-950/40 border border-cyan-700/40 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-cyan-400" />
              <span className="text-xs font-bold text-white">Hardware Profiler &amp; Recommendation</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 font-mono">
                Detected: {recommendation.detectedMemoryGb} GB RAM / {recommendation.detectedCores} Cores
              </span>
            </div>

            <div className="flex items-center gap-2">
              <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={settings.autoRecommendationEnabled}
                  onChange={(e) => onUpdateSettings({ autoRecommendationEnabled: e.target.checked })}
                  className="rounded accent-cyan-500 w-3.5 h-3.5"
                />
                <span className="text-[11px]">Auto-Recommend</span>
              </label>
              {settings.mode !== recommendation.recommendedMode && (
                <button
                  onClick={() => onApplyRecommendation(recommendation)}
                  className="px-2.5 py-1 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-[11px] font-semibold transition-colors shadow"
                >
                  Apply {recommendation.recommendedMode === 'lite' ? '4 GB Lite' : '8 GB Advanced'}
                </button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1 text-[11px]">
            {recommendation.reasons.map((r, i) => (
              <div key={i} className="p-2 rounded-lg bg-slate-950/70 border border-slate-800/80 text-slate-300 flex items-start gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 flex-shrink-0 mt-0.5" />
                <span>{r}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Real-Time Live Resource Telemetry Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* RAM Usage */}
        <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 shadow-lg space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span className="flex items-center gap-1 font-medium">
              <HardDrive className="w-3.5 h-3.5 text-cyan-400" />
              <span>RAM Budget</span>
            </span>
            <span className="text-[10px] font-mono">{isLite ? '400MB Cap' : '1GB Cap'}</span>
          </div>
          <div className="text-base font-bold text-white font-mono">
            {metrics.estimatedRamUsageMb} <span className="text-xs text-slate-400 font-normal">MB</span>
          </div>
          <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden border border-slate-800">
            <div 
              className={`h-full transition-all duration-500 ${isLite ? 'bg-amber-400' : 'bg-indigo-400'}`}
              style={{ width: `${Math.round((metrics.estimatedRamUsageMb / metrics.maxRamAllocationMb) * 100)}%` }}
            />
          </div>
        </div>

        {/* CPU Load */}
        <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 shadow-lg space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span className="flex items-center gap-1 font-medium">
              <Activity className="w-3.5 h-3.5 text-emerald-400" />
              <span>CPU Load</span>
            </span>
            <span className="text-[10px] font-mono">{simulationState === 'idle_sleeping' ? 'Idle' : 'Active'}</span>
          </div>
          <div className="text-base font-bold text-emerald-400 font-mono">
            {simulationState === 'idle_sleeping' ? '2' : simulationState === 'gaming_load' ? '28' : metrics.cpuLoadPct}%
          </div>
          <div className="text-[10px] text-slate-400">
            {settings.reducedBackgroundCpu ? 'Throttled for games' : 'Standard priority'}
          </div>
        </div>

        {/* Thermal State (With Explicit Thermodynamics Reality) */}
        <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 shadow-lg space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span className="flex items-center gap-1 font-medium">
              <Flame className="w-3.5 h-3.5 text-amber-400" />
              <span>Thermals</span>
            </span>
            <span className="text-[10px] font-mono">
              {metrics.thermalState === 'normal' ? 'Nominal' : 'Warm'}
            </span>
          </div>
          <div className="text-base font-bold text-amber-300 font-mono flex items-center gap-1">
            <span>{simulationState === 'gaming_load' ? '41.2°C' : '36.8°C'}</span>
          </div>
          <div className="text-[10px] text-slate-400 truncate" title="Zero heating claim rejected by physics">
            {metrics.cooldownPeriodMs > 0 ? `${metrics.cooldownPeriodMs}ms cooldown active` : 'Active cooling off'}
          </div>
        </div>

        {/* Battery Discharge */}
        <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 shadow-lg space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span className="flex items-center gap-1 font-medium">
              <BatteryCharging className="w-3.5 h-3.5 text-emerald-400" />
              <span>Battery Rate</span>
            </span>
            <span className="text-[10px] font-mono">Discharge</span>
          </div>
          <div className="text-base font-bold text-emerald-300 font-mono">
            {simulationState === 'idle_sleeping' ? '180' : metrics.batteryDischargeRateMw} <span className="text-xs text-slate-400 font-normal">mW</span>
          </div>
          <div className="text-[10px] text-slate-400">
            {settings.batterySaverEnabled ? '32% power reduction' : 'Unrestricted'}
          </div>
        </div>

        {/* Screenshot Frequency */}
        <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 shadow-lg space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span className="flex items-center gap-1 font-medium">
              <Radio className="w-3.5 h-3.5 text-cyan-400" />
              <span>Screen Capture</span>
            </span>
            <span className="text-[10px] font-mono">Accessibility</span>
          </div>
          <div className="text-base font-bold text-cyan-300 font-mono">
            {simulationState === 'idle_sleeping' ? '0.0' : metrics.screenshotFrequencyFps} <span className="text-xs text-slate-400 font-normal">FPS</span>
          </div>
          <div className="text-[10px] text-slate-400">
            {settings.avoidContinuousCapture ? 'Event-driven only' : 'Periodic scan'}
          </div>
        </div>

        {/* Mobile Data Saved */}
        <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 shadow-lg space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span className="flex items-center gap-1 font-medium">
              <Wifi className="w-3.5 h-3.5 text-purple-400" />
              <span>Data Saved</span>
            </span>
            <span className="text-[10px] font-mono">Cellular</span>
          </div>
          <div className="text-base font-bold text-purple-300 font-mono">
            {(metrics.mobileDataSavedKb / 1024).toFixed(1)} <span className="text-xs text-slate-400 font-normal">MB</span>
          </div>
          <div className="text-[10px] text-slate-400">
            Compressed + Video skip
          </div>
        </div>
      </div>

      {/* Mandatory Engineering Honesty & Physics Notice */}
      <div className="p-4 rounded-xl bg-amber-950/20 border border-amber-600/40 text-amber-200 text-xs flex items-start gap-3 shadow-md">
        <Info className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <strong className="block text-amber-300 font-semibold">
            Engineering Reality &amp; Thermal Physics Notice:
          </strong>
          <p className="text-amber-200/90 leading-relaxed">
            {metrics.thermalNote}
          </p>
          <p className="text-[11px] text-amber-300/80">
            AutoPilot actively monitors thermal state, throttles expensive loops during intense Free Fire gunfights, and sleeps background watchers when idle.
          </p>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2 text-xs overflow-x-auto">
        <button
          onClick={() => setActiveSubSection('profiles')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${
            activeSubSection === 'profiles'
              ? 'bg-cyan-950 text-cyan-300 border border-cyan-700 font-semibold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Cpu className="w-3.5 h-3.5" />
          <span>Device Profiles (4GB vs 8GB)</span>
        </button>

        <button
          onClick={() => setActiveSubSection('battery')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${
            activeSubSection === 'battery'
              ? 'bg-cyan-950 text-cyan-300 border border-cyan-700 font-semibold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <BatteryCharging className="w-3.5 h-3.5" />
          <span>Battery Saving &amp; Cooldown</span>
        </button>

        <button
          onClick={() => setActiveSubSection('network')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${
            activeSubSection === 'network'
              ? 'bg-cyan-950 text-cyan-300 border border-cyan-700 font-semibold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Wifi className="w-3.5 h-3.5" />
          <span>Mobile Data &amp; Network</span>
        </button>

        <button
          onClick={() => setActiveSubSection('telemetry')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${
            activeSubSection === 'telemetry'
              ? 'bg-cyan-950 text-cyan-300 border border-cyan-700 font-semibold'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Activity className="w-3.5 h-3.5" />
          <span>Live Load &amp; Cooldown Simulator</span>
        </button>
      </div>

      {/* SECTION 1: DEVICE PROFILES COMPARISON (4 GB RAM vs 8 GB RAM) */}
      {activeSubSection === 'profiles' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* LITE MODE — 4 GB RAM CARD */}
            <div
              onClick={() => handleSelectMode('lite')}
              className={`p-5 rounded-2xl border cursor-pointer transition-all ${
                isLite
                  ? 'bg-amber-950/30 border-amber-500 shadow-xl shadow-amber-950/40 ring-1 ring-amber-500/50'
                  : 'bg-slate-900 border-slate-800 opacity-70 hover:opacity-100'
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-amber-400 animate-pulse"></span>
                  <h4 className="text-sm font-bold text-white">LITE MODE — 4 GB RAM</h4>
                </div>
                {isLite && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500 text-slate-950 font-bold uppercase">
                    ACTIVE PROFILE
                  </span>
                )}
              </div>

              <p className="text-xs text-slate-300 mb-4 leading-relaxed">
                Tailored for budget Android phones to prevent low-memory kills (OOM) and guarantee 60 FPS in Free Fire India.
              </p>

              {/* 7 Core Lite Mode Features as explicitly required */}
              <div className="space-y-2 text-xs text-slate-300">
                <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800/80 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-amber-400" />
                    <span>One active task at a time</span>
                  </div>
                  <span className="text-[10px] font-mono text-amber-300">Enforced</span>
                </div>

                <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800/80 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-amber-400" />
                    <span>Minimal background processing</span>
                  </div>
                  <span className="text-[10px] font-mono text-amber-300">Active</span>
                </div>

                <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800/80 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-amber-400" />
                    <span>Reduced screenshot frequency</span>
                  </div>
                  <span className="text-[10px] font-mono text-amber-300">0.5 FPS</span>
                </div>

                <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800/80 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-amber-400" />
                    <span>Smaller AI requests &amp; token cap</span>
                  </div>
                  <span className="text-[10px] font-mono text-amber-300">Compact</span>
                </div>

                <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800/80 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-amber-400" />
                    <span>Limited workflow caching</span>
                  </div>
                  <span className="text-[10px] font-mono text-amber-300">Max 5 macros</span>
                </div>

                <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800/80 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-amber-400" />
                    <span>Minimal animations &amp; lean canvas</span>
                  </div>
                  <span className="text-[10px] font-mono text-amber-300">Optimized</span>
                </div>

                <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800/80 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-amber-400" />
                    <span>Aggressive idle resource reduction</span>
                  </div>
                  <span className="text-[10px] font-mono text-amber-300">3s sleep timeout</span>
                </div>
              </div>
            </div>

            {/* ADVANCED MODE — 8 GB RAM CARD */}
            <div
              onClick={() => handleSelectMode('advanced')}
              className={`p-5 rounded-2xl border cursor-pointer transition-all ${
                !isLite
                  ? 'bg-indigo-950/30 border-indigo-500 shadow-xl shadow-indigo-950/40 ring-1 ring-indigo-500/50'
                  : 'bg-slate-900 border-slate-800 opacity-70 hover:opacity-100'
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-indigo-400 animate-pulse"></span>
                  <h4 className="text-sm font-bold text-white">ADVANCED MODE — 8 GB RAM</h4>
                </div>
                {!isLite && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-500 text-white font-bold uppercase">
                    ACTIVE PROFILE
                  </span>
                )}
              </div>

              <p className="text-xs text-slate-300 mb-4 leading-relaxed">
                Utilizes abundant RAM headroom for deeper multimodal screen OCR, 5-path adaptive reasoning, and instant gesture caching.
              </p>

              {/* 5 Core Advanced Mode Features as explicitly required */}
              <div className="space-y-2 text-xs text-slate-300">
                <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800/80 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-indigo-400" />
                    <span>More detailed task analysis</span>
                  </div>
                  <span className="text-[10px] font-mono text-indigo-300">Deep Multimodal</span>
                </div>

                <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800/80 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-indigo-400" />
                    <span>Larger workflow cache</span>
                  </div>
                  <span className="text-[10px] font-mono text-indigo-300">50 macros preloaded</span>
                </div>

                <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800/80 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-indigo-400" />
                    <span>Optional advanced visual verification</span>
                  </div>
                  <span className="text-[10px] font-mono text-indigo-300">Multi-pass OCR</span>
                </div>

                <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800/80 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-indigo-400" />
                    <span>More complex task planning</span>
                  </div>
                  <span className="text-[10px] font-mono text-indigo-300">5-Path Strategies</span>
                </div>

                <div className="p-2 rounded-lg bg-slate-950/60 border border-slate-800/80 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-indigo-400" />
                    <span>Controlled parallel processing</span>
                  </div>
                  <span className="text-[10px] font-mono text-indigo-300">Safe concurrency</span>
                </div>
              </div>
            </div>
          </div>

          {/* Granular Profile Controls */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <Sliders className="w-4 h-4 text-cyan-400" />
              <span>Granular Device Profile Overrides</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
              <label className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between cursor-pointer">
                <div>
                  <span className="font-bold text-white block">Single Task Only</span>
                  <span className="text-[10px] text-slate-400">Strictly blocks concurrent task execution</span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.singleTaskOnly}
                  onChange={(e) => onUpdateSettings({ singleTaskOnly: e.target.checked })}
                  className="rounded accent-cyan-500 w-4 h-4"
                />
              </label>

              <label className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between cursor-pointer">
                <div>
                  <span className="font-bold text-white block">Minimal Animations</span>
                  <span className="text-[10px] text-slate-400">Eliminates heavy GPU canvas repaints</span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.minimalAnimations}
                  onChange={(e) => onUpdateSettings({ minimalAnimations: e.target.checked })}
                  className="rounded accent-cyan-500 w-4 h-4"
                />
              </label>

              <label className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between cursor-pointer">
                <div>
                  <span className="font-bold text-white block">Aggressive Idle Reduction</span>
                  <span className="text-[10px] text-slate-400">Puts background loops to sleep after 3s</span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.aggressiveIdleReduction}
                  onChange={(e) => onUpdateSettings({ aggressiveIdleReduction: e.target.checked })}
                  className="rounded accent-cyan-500 w-4 h-4"
                />
              </label>

              <label className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between cursor-pointer">
                <div>
                  <span className="font-bold text-white block">Smaller AI Requests</span>
                  <span className="text-[10px] text-slate-400">Reduces prompt context to essential JSON</span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.smallerAiRequests}
                  onChange={(e) => onUpdateSettings({ smallerAiRequests: e.target.checked })}
                  className="rounded accent-cyan-500 w-4 h-4"
                />
              </label>

              <label className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between cursor-pointer">
                <div>
                  <span className="font-bold text-white block">Visual Verification</span>
                  <span className="text-[10px] text-slate-400">Multi-pass target confirmation</span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.advancedVisualVerification}
                  onChange={(e) => onUpdateSettings({ advancedVisualVerification: e.target.checked })}
                  className="rounded accent-cyan-500 w-4 h-4"
                />
              </label>

              <label className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between cursor-pointer">
                <div>
                  <span className="font-bold text-white block">Controlled Parallelism</span>
                  <span className="text-[10px] text-slate-400">Allows safe multi-step prefetching</span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.controlledParallelProcessing}
                  onChange={(e) => onUpdateSettings({ controlledParallelProcessing: e.target.checked })}
                  className="rounded accent-cyan-500 w-4 h-4"
                />
              </label>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 2: BATTERY SAVING & COOLDOWN CONTROLS */}
      {activeSubSection === 'battery' && (
        <div className="space-y-6">
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <BatteryCharging className="w-4 h-4 text-emerald-400" />
                  <span>Battery Preservation Engine</span>
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  Protects Android battery health by suppressing unneeded CPU polling and avoiding hot continuous loops.
                </p>
              </div>

              <label className="flex items-center gap-2 text-xs font-semibold cursor-pointer select-none bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800">
                <input
                  type="checkbox"
                  checked={settings.batterySaverEnabled}
                  onChange={(e) => onUpdateSettings({ batterySaverEnabled: e.target.checked })}
                  className="rounded accent-emerald-500 w-4 h-4"
                />
                <span className={settings.batterySaverEnabled ? 'text-emerald-300 font-bold' : 'text-slate-400'}>
                  {settings.batterySaverEnabled ? 'Battery Saver Active' : 'Unrestricted Power'}
                </span>
              </label>
            </div>

            {/* Battery Features Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              {/* Avoid Continuous Screen Capture */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Radio className="w-4 h-4 text-emerald-400" />
                    <span>Avoid Continuous Screen Capture</span>
                  </span>
                  <input
                    type="checkbox"
                    checked={settings.avoidContinuousCapture}
                    onChange={(e) => onUpdateSettings({ avoidContinuousCapture: e.target.checked })}
                    className="rounded accent-emerald-500 w-4 h-4"
                  />
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Replaces continuous 30 FPS bitmap scanning with Android's native <strong>onAccessibilityEvent</strong>. Dispatches screen analysis ONLY when UI window actually changes.
                </p>
              </div>

              {/* Event-Driven Processing */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Zap className="w-4 h-4 text-emerald-400" />
                    <span>Event-Driven Processing</span>
                  </span>
                  <input
                    type="checkbox"
                    checked={settings.eventDrivenProcessing}
                    onChange={(e) => onUpdateSettings({ eventDrivenProcessing: e.target.checked })}
                    className="rounded accent-emerald-500 w-4 h-4"
                  />
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Prevents tight while-loops. AutoPilot sleeps worker threads until an explicit touch event, gesture completion, or target node match occurs.
                </p>
              </div>

              {/* Stop Expensive Analysis When Idle */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Minimize2 className="w-4 h-4 text-emerald-400" />
                    <span>Stop Expensive Analysis When Idle</span>
                  </span>
                  <input
                    type="checkbox"
                    checked={settings.stopExpensiveAnalysisWhenIdle}
                    onChange={(e) => onUpdateSettings({ stopExpensiveAnalysisWhenIdle: e.target.checked })}
                    className="rounded accent-emerald-500 w-4 h-4"
                  />
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Immediately halts OCR and multimodal reasoning when screen is static or user is in a paused lobby screen.
                </p>
              </div>

              {/* Reduced Background CPU Activity */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Activity className="w-4 h-4 text-emerald-400" />
                    <span>Reduce Background CPU Activity</span>
                  </span>
                  <input
                    type="checkbox"
                    checked={settings.reducedBackgroundCpu}
                    onChange={(e) => onUpdateSettings({ reducedBackgroundCpu: e.target.checked })}
                    className="rounded accent-emerald-500 w-4 h-4"
                  />
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Pins background thread priority to Android's <code>THREAD_PRIORITY_BACKGROUND</code> to ensure Free Fire gets 100% of the game rendering cores.
                </p>
              </div>
            </div>

            {/* Polling Interval Slider */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300 font-medium">UI Polling Interval:</span>
                <span className="text-emerald-400 font-mono font-bold bg-slate-900 px-2 py-0.5 rounded border border-slate-700">
                  {settings.pollingIntervalMs} ms
                </span>
              </div>
              <input
                type="range"
                min="300"
                max="3000"
                step="100"
                value={settings.pollingIntervalMs}
                onChange={(e) => onUpdateSettings({ pollingIntervalMs: Number(e.target.value), reducedPolling: true })}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>300ms (Aggressive)</span>
                <span className="text-emerald-400">1600ms (Recommended for Battery)</span>
                <span>3000ms (Ultra Eco)</span>
              </div>
            </div>

            {/* Cooldown Periods Setting */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-white block">Cooldown Periods Between Workflows</span>
                  <span className="text-[10px] text-slate-400">Inserts thermal breather delay after heavy action bursts</span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.cooldownPeriodsEnabled}
                  onChange={(e) => onUpdateSettings({ cooldownPeriodsEnabled: e.target.checked })}
                  className="rounded accent-emerald-500 w-4 h-4"
                />
              </div>

              {settings.cooldownPeriodsEnabled && (
                <div className="space-y-1.5 pt-2 border-t border-slate-800">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400">Cooldown Breather Duration:</span>
                    <span className="text-emerald-400 font-mono font-bold">{settings.cooldownDurationMs} ms</span>
                  </div>
                  <input
                    type="range"
                    min="200"
                    max="2000"
                    step="100"
                    value={settings.cooldownDurationMs}
                    onChange={(e) => onUpdateSettings({ cooldownDurationMs: Number(e.target.value) })}
                    className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                  />
                </div>
              )}
            </div>

            {/* CUSTOM GAMEPLAY COOLING COOLDOWNS (Anti-Overheating) */}
            <div className="p-4 rounded-xl bg-gradient-to-r from-slate-950 via-cyan-950/20 to-slate-950 border border-cyan-800/50 space-y-4 shadow-lg">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <Snowflake className="w-4 h-4 text-cyan-400" />
                    <span className="text-xs font-bold text-white">Custom Gameplay Cooling Cooldowns</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
                      Anti-Overheating
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Forces a 5–10 second gesture suspension every X minutes of continuous gameplay to prevent device thermal throttling.
                  </p>
                </div>

                <label className="flex items-center gap-2 text-xs font-semibold cursor-pointer select-none bg-slate-900 px-3 py-1.5 rounded-xl border border-slate-700">
                  <input
                    type="checkbox"
                    checked={settings.periodicCoolingEnabled}
                    onChange={(e) => onUpdateSettings({ periodicCoolingEnabled: e.target.checked })}
                    className="rounded accent-cyan-500 w-4 h-4 cursor-pointer"
                  />
                  <span className={settings.periodicCoolingEnabled ? 'text-cyan-300 font-bold' : 'text-slate-400'}>
                    {settings.periodicCoolingEnabled ? 'Cooling Cooldowns ON' : 'Disabled'}
                  </span>
                </label>
              </div>

              {settings.periodicCoolingEnabled && (
                <div className="space-y-4 pt-2 border-t border-slate-800/80">
                  {/* Pause Duration Slider (5 to 10 seconds) */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-300 font-medium">Forced Pause Duration:</span>
                      <span className="text-cyan-400 font-mono font-bold bg-slate-900 px-2 py-0.5 rounded border border-slate-700">
                        {settings.coolingPauseDurationSec} Seconds
                      </span>
                    </div>
                    <input
                      type="range"
                      min="5"
                      max="10"
                      step="1"
                      value={settings.coolingPauseDurationSec}
                      onChange={(e) => onUpdateSettings({ coolingPauseDurationSec: Number(e.target.value) })}
                      className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-500"
                    />
                    <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                      <span>5s (Brief Thermal Drop)</span>
                      <span className="text-cyan-400 font-semibold">8s (Recommended Balance)</span>
                      <span>10s (Maximum Cooling)</span>
                    </div>
                  </div>

                  {/* Frequency Interval Slider (Every X minutes) */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-300 font-medium">Trigger Frequency Interval:</span>
                      <span className="text-cyan-400 font-mono font-bold bg-slate-900 px-2 py-0.5 rounded border border-slate-700">
                        Every {settings.coolingIntervalMinutes} Minutes of Continuous Play
                      </span>
                    </div>
                    <input
                      type="range"
                      min="3"
                      max="30"
                      step="1"
                      value={settings.coolingIntervalMinutes}
                      onChange={(e) => onUpdateSettings({ coolingIntervalMinutes: Number(e.target.value) })}
                      className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-500"
                    />
                    <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                      <span>3 Min</span>
                      <span>5 Min</span>
                      <span className="text-cyan-400 font-semibold">10 Min (Esports Standard)</span>
                      <span>15 Min</span>
                      <span>20 Min</span>
                      <span>30 Min</span>
                    </div>
                  </div>

                  {/* Preset quick buttons */}
                  <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
                    <span className="text-[11px] text-slate-400">Quick Interval Presets:</span>
                    {[5, 10, 15, 20].map((mins) => (
                      <button
                        key={mins}
                        onClick={() => onUpdateSettings({ coolingIntervalMinutes: mins })}
                        className={`px-2.5 py-1 rounded-lg border text-[11px] font-mono transition-all ${
                          settings.coolingIntervalMinutes === mins
                            ? 'bg-cyan-950 text-cyan-300 border-cyan-500 font-bold'
                            : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        {mins}m
                      </button>
                    ))}
                  </div>

                  {/* Real-world benefits notification */}
                  <div className="p-3 rounded-xl bg-slate-900/80 border border-cyan-900/40 text-[11px] text-slate-300 space-y-1">
                    <div className="flex items-center gap-1.5 text-cyan-300 font-semibold">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>How It Works in Free Fire India:</span>
                    </div>
                    <p className="text-slate-400 leading-relaxed">
                      Every {settings.coolingIntervalMinutes} minutes of active macro execution, AutoPilot temporarily suspends gesture injection for {settings.coolingPauseDurationSec}s. A floating countdown timer appears so you know exactly when touch resumes. You can tap <em>Skip</em> at any moment if you are in a gunfight.
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* SECTION 3: MOBILE DATA & NETWORK OPTIMIZATION */}
      {activeSubSection === 'network' && (
        <div className="space-y-6">
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <Wifi className="w-4 h-4 text-cyan-400" />
                  <span>Mobile Cellular Data Optimizer</span>
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  Strictly optimized for users with daily mobile data limits (1GB–2GB/day).
                </p>
              </div>

              <span className="text-xs font-mono font-bold text-purple-400 bg-purple-950/80 px-2.5 py-1 rounded-lg border border-purple-800">
                {(metrics.mobileDataSavedKb / 1024).toFixed(1)} MB Saved
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
              {/* Compress Suitable Requests */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white flex items-center gap-1.5">
                    <TrendingDown className="w-4 h-4 text-cyan-400" />
                    <span>Compress Suitable Requests</span>
                  </span>
                  <input
                    type="checkbox"
                    checked={settings.compressPayloads}
                    onChange={(e) => onUpdateSettings({ compressPayloads: e.target.checked })}
                    className="rounded accent-cyan-500 w-4 h-4"
                  />
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Gzip/Brotli compresses JSON schemas and strips unneeded UI metadata, shrinking round-trip payloads by 75%.
                </p>
              </div>

              {/* Avoid Unnecessary Video Downloads */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-cyan-400" />
                    <span>Avoid Video Downloads</span>
                  </span>
                  <input
                    type="checkbox"
                    checked={settings.avoidVideoDownloads}
                    onChange={(e) => onUpdateSettings({ avoidVideoDownloads: e.target.checked })}
                    className="rounded accent-cyan-500 w-4 h-4"
                  />
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Extracts workflow steps directly from lightweight transcripts and metadata instead of downloading 50MB–200MB MP4 files.
                </p>
              </div>

              {/* Intelligent Retry with Jitter */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white flex items-center gap-1.5">
                    <RefreshCw className="w-4 h-4 text-cyan-400" />
                    <span>Intelligent Request Retry</span>
                  </span>
                  <input
                    type="checkbox"
                    checked={settings.intelligentRetry}
                    onChange={(e) => onUpdateSettings({ intelligentRetry: e.target.checked })}
                    className="rounded accent-cyan-500 w-4 h-4"
                  />
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Exponential backoff with randomized jitter handles shaky 4G cell tower handovers without burning data loops.
                </p>
              </div>

              {/* Allow Offline Execution of Workflows */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white flex items-center gap-1.5">
                    <HardDrive className="w-4 h-4 text-emerald-400" />
                    <span>Offline Execution First</span>
                  </span>
                  <input
                    type="checkbox"
                    checked={settings.offlineExecutionPreferred}
                    onChange={(e) => onUpdateSettings({ offlineExecutionPreferred: e.target.checked })}
                    className="rounded accent-emerald-500 w-4 h-4"
                  />
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Eligible saved workflows and Free Fire presets execute 100% locally from Android SQLite Room without using 1 byte of mobile internet.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 4: LIVE LOAD & COOLDOWN SIMULATOR */}
      {activeSubSection === 'telemetry' && (
        <div className="space-y-6">
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <Activity className="w-4 h-4 text-cyan-400" />
              <span>Adaptive Governor &amp; Stress Test Simulator</span>
            </h4>
            <p className="text-xs text-slate-400">
              Simulate actual mobile scenarios to verify that throttling, cooldown intervals, and sleep triggers engage dynamically.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => handleSimulateLoad('normal')}
                className={`px-4 py-2 rounded-xl text-xs font-semibold border transition-all ${
                  simulationState === 'normal'
                    ? 'bg-cyan-950 text-cyan-300 border-cyan-500 ring-1 ring-cyan-500'
                    : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
                }`}
              >
                Nominal State
              </button>

              <button
                onClick={() => handleSimulateLoad('gaming_load')}
                className={`px-4 py-2 rounded-xl text-xs font-semibold border transition-all ${
                  simulationState === 'gaming_load'
                    ? 'bg-amber-950 text-amber-300 border-amber-500 ring-1 ring-amber-500'
                    : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
                }`}
              >
                Simulate Free Fire Match Load
              </button>

              <button
                onClick={() => handleSimulateLoad('idle_sleeping')}
                className={`px-4 py-2 rounded-xl text-xs font-semibold border transition-all ${
                  simulationState === 'idle_sleeping'
                    ? 'bg-purple-950 text-purple-300 border-purple-500 ring-1 ring-purple-500'
                    : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
                }`}
              >
                Simulate 3s Inactivity Sleep
              </button>
            </div>

            {/* Simulation Status Card */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono space-y-2">
              <div className="flex items-center justify-between text-slate-400">
                <span className="text-cyan-400">GOVERNOR STATUS:</span>
                <span>Active Mode: {isLite ? 'LITE (4GB)' : 'ADVANCED (8GB)'}</span>
              </div>
              <p className="text-slate-200">{simulationMessage}</p>
              <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-400 flex flex-wrap gap-4">
                <span>Polling: {simulationState === 'idle_sleeping' ? 'PAUSED' : `${settings.pollingIntervalMs}ms`}</span>
                <span>Cooldown Breather: {settings.cooldownPeriodsEnabled ? `${settings.cooldownDurationMs}ms` : 'OFF'}</span>
                <span>Capture Rate: {simulationState === 'idle_sleeping' ? '0.0 FPS' : `${metrics.screenshotFrequencyFps} FPS`}</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
