import React from 'react';
import { 
  AssistantStatus 
} from '../types/autopilot';
import { 
  Play, 
  Pause, 
  Square, 
  Maximize2, 
  Power, 
  Flame, 
  Layers, 
  ShieldCheck,
  ChevronDown
} from 'lucide-react';

interface OngoingNotificationBarProps {
  status: AssistantStatus;
  isServiceActive: boolean;
  onTogglePauseResume: () => void;
  onEmergencyStop: () => void;
  onReopenApp: () => void;
  onCloseAutoPilot: () => void;
  currentTaskDescription?: string;
  isCallActive?: boolean;
}

export const OngoingNotificationBar: React.FC<OngoingNotificationBarProps> = ({
  status,
  isServiceActive,
  onTogglePauseResume,
  onEmergencyStop,
  onReopenApp,
  onCloseAutoPilot,
  currentTaskDescription = 'Monitoring Free Fire HUD for pro macro triggers',
  isCallActive = false,
}) => {
  if (!isServiceActive) return null;

  const getStatusText = () => {
    switch (status) {
      case 'GREEN_RUNNING':
        return { label: 'RUNNING', color: 'text-emerald-400 bg-emerald-950/80 border-emerald-800' };
      case 'ORANGE_PAUSED':
        return { label: 'PAUSED', color: 'text-amber-400 bg-amber-950/80 border-amber-800' };
      case 'COOLING_PAUSED':
        return { label: 'COOLING PAUSED', color: 'text-cyan-300 bg-cyan-950/80 border-cyan-800' };
      case 'RED_EMERGENCY_STOP':
        return { label: 'EMERGENCY STOPPED', color: 'text-rose-400 bg-rose-950/80 border-rose-800' };
      default:
        return { label: 'STANDBY', color: 'text-slate-400 bg-slate-900 border-slate-700' };
    }
  };

  const statusBadge = getStatusText();

  return (
    <div className="w-full bg-slate-900/95 border border-slate-700/80 rounded-2xl p-3 shadow-xl backdrop-blur-md text-xs text-slate-100 space-y-2 select-none">
      {/* Android System Header */}
      <div className="flex items-center justify-between text-[11px] text-slate-400 border-b border-slate-800/80 pb-1.5">
        <div className="flex items-center gap-1.5 font-medium">
          <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
          <span>Android Ongoing Notification • Channel: autopilot_assistant_channel</span>
        </div>
        <span className="text-[10px] font-mono text-slate-400">PRIORITY_LOW (Silent Ongoing)</span>
      </div>

      {/* Notification Body */}
      <div className="flex items-start justify-between gap-3 pt-1">
        <div className="flex items-start gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-600 to-indigo-600 flex items-center justify-center flex-shrink-0 shadow border border-cyan-400/40">
            <Flame className="w-5 h-5 text-amber-300" />
          </div>
          <div className="space-y-0.5">
            <div className="flex items-center gap-1.5 flex-wrap">
              <h4 className="font-bold text-white text-xs">AI AutoPilot • Free Fire Gaming Assistant</h4>
              <span className={`text-[9px] font-mono font-bold px-1.5 py-0.2 rounded border ${statusBadge.color}`}>
                {statusBadge.label}
              </span>
              {isCallActive && (
                <span className="text-[9px] font-mono font-bold px-1.5 py-0.2 rounded border bg-amber-950 text-amber-300 border-amber-600 animate-pulse">
                  CALL MODE (MUTED)
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-300 line-clamp-1">{currentTaskDescription}</p>
            <p className="text-[10px] text-slate-400 flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-cyan-400" />
              <span>
                {isCallActive
                  ? 'Call Mode: Speech Muted • Written Command Mode Active'
                  : 'Foreground Service Active • Overlay Movable'}
              </span>
            </p>
          </div>
        </div>

        {/* Reopen Button */}
        <button
          onClick={onReopenApp}
          className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 rounded-lg text-[11px] font-medium flex items-center gap-1 shadow-sm flex-shrink-0"
          title="Reopen AI AutoPilot Full Interface"
        >
          <Maximize2 className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Open App</span>
        </button>
      </div>

      {/* Quick Action Buttons (Android Notification Action Bar) */}
      <div className="grid grid-cols-3 gap-2 pt-1 border-t border-slate-800/60">
        {status === 'GREEN_RUNNING' ? (
          <button
            onClick={onTogglePauseResume}
            className="py-1.5 px-2 bg-amber-950/60 hover:bg-amber-900/60 text-amber-300 border border-amber-800/80 rounded-lg font-semibold text-[11px] flex items-center justify-center gap-1.5 transition-colors"
          >
            <Pause className="w-3.5 h-3.5 fill-current" />
            <span>Pause</span>
          </button>
        ) : (
          <button
            onClick={onTogglePauseResume}
            className="py-1.5 px-2 bg-emerald-950/60 hover:bg-emerald-900/60 text-emerald-300 border border-emerald-800/80 rounded-lg font-semibold text-[11px] flex items-center justify-center gap-1.5 transition-colors"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Resume (Safe)</span>
          </button>
        )}

        <button
          onClick={onEmergencyStop}
          className="py-1.5 px-2 bg-rose-950/60 hover:bg-rose-900/60 text-rose-300 border border-rose-800/80 rounded-lg font-semibold text-[11px] flex items-center justify-center gap-1.5 transition-colors"
        >
          <Square className="w-3.5 h-3.5 fill-current" />
          <span>Stop</span>
        </button>

        <button
          onClick={onCloseAutoPilot}
          className="py-1.5 px-2 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded-lg font-medium text-[11px] flex items-center justify-center gap-1.5 transition-colors"
        >
          <Power className="w-3.5 h-3.5 text-rose-400" />
          <span>Close Service</span>
        </button>
      </div>
    </div>
  );
};
