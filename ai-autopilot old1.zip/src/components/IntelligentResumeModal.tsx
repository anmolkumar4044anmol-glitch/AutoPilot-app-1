import React from 'react';
import { 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle, 
  ShieldCheck, 
  RotateCcw, 
  Play, 
  X, 
  Search, 
  Layers, 
  ShieldAlert,
  Flame
} from 'lucide-react';
import { IntelligentResumeInspection } from '../types/autopilot';

interface IntelligentResumeModalProps {
  inspection: IntelligentResumeInspection | null;
  isOpen: boolean;
  onClose: () => void;
  onResumeConfirm: () => void;
  isInspecting?: boolean;
}

export const IntelligentResumeModal: React.FC<IntelligentResumeModalProps> = ({
  inspection,
  isOpen,
  onClose,
  onResumeConfirm,
  isInspecting = false,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl shadow-cyan-950/60 overflow-hidden text-slate-100 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-cyan-950/80 via-slate-900 to-indigo-950/80 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-400">
              <Sparkles className="w-4 h-4 animate-spin-slow" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                <span>Intelligent Pause & Resume Engine</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-mono">
                  ACTIVE
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Safety-first verification before continuing task execution
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs">
          {isInspecting ? (
            <div className="py-12 flex flex-col items-center justify-center text-center space-y-3">
              <div className="w-10 h-10 border-3 border-cyan-400 border-t-transparent rounded-full animate-spin"></div>
              <p className="text-sm font-medium text-slate-200">Inspecting Live Screen & Verifying Completed Actions...</p>
              <p className="text-[11px] text-slate-400 max-w-xs">Comparing Free Fire viewport hierarchy with saved checkpoint state.</p>
            </div>
          ) : inspection ? (
            <>
              {/* 7-Step Inspection Protocol Breakdown */}
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-slate-300 font-semibold">
                  <span className="flex items-center gap-1.5 text-cyan-400">
                    <Search className="w-3.5 h-3.5" />
                    <span>State Recovery Ledger</span>
                  </span>
                  <span className="font-mono text-[10px] text-slate-400">{inspection.timestamp}</span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div className="p-2 rounded bg-slate-900 border border-slate-800">
                    <span className="text-slate-400 block text-[10px]">Saved Task</span>
                    <strong className="text-white truncate block">{inspection.savedTaskName}</strong>
                  </div>
                  <div className="p-2 rounded bg-slate-900 border border-slate-800">
                    <span className="text-slate-400 block text-[10px]">Current Screen</span>
                    <strong className="text-emerald-400 flex items-center gap-1">
                      <Flame className="w-3 h-3 text-amber-500" />
                      {inspection.screenDetected}
                    </strong>
                  </div>
                </div>
              </div>

              {/* Step 3: Verified Completed Steps (Never Redo) */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-[11px] font-semibold text-emerald-400">
                  <span className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Completed Steps ({inspection.completedSteps.length}) — No Duplicates</span>
                  </span>
                  <span className="text-[10px] font-mono text-emerald-300 bg-emerald-950/70 px-1.5 py-0.5 rounded">
                    BLOCKED FROM RETRY
                  </span>
                </div>
                <div className="space-y-1">
                  {inspection.completedSteps.map((step, idx) => (
                    <div key={idx} className="p-2 rounded-lg bg-emerald-950/30 border border-emerald-800/40 text-emerald-200 flex items-center justify-between">
                      <span className="truncate">✓ {step}</span>
                      <span className="text-[10px] font-mono text-emerald-400">SAVED</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Step 4: Screen Changes / Drift Detected */}
              {inspection.changesDetected.length > 0 && (
                <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-600/40 space-y-1.5 text-amber-200">
                  <div className="flex items-center gap-1.5 font-bold text-amber-300">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    <span>Screen Deviations Detected While Paused:</span>
                  </div>
                  <ul className="list-disc list-inside space-y-0.5 text-[11px] text-amber-200/90">
                    {inspection.changesDetected.map((change, idx) => (
                      <li key={idx}>{change}</li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Step 5 & 6: Recalculated Safe Continuation Action */}
              <div className="p-3.5 rounded-xl bg-cyan-950/40 border border-cyan-500/50 space-y-1.5 text-cyan-200">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-cyan-300 flex items-center gap-1.5">
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Recalculated Safe Step (Step #{inspection.safeNextStepIndex + 1}):</span>
                  </span>
                  <span className="font-mono text-[10px] text-cyan-400 bg-cyan-900/60 px-2 py-0.5 rounded">
                    Confidence: {inspection.confidenceScore}%
                  </span>
                </div>
                <p className="text-white text-xs font-medium pl-1">
                  {inspection.recalculatedAction}
                </p>
              </div>

              {/* Step 7: Potentially Destructive Actions Protected */}
              <div className="p-3 rounded-xl bg-slate-950 border border-rose-900/40 space-y-1.5">
                <div className="flex items-center gap-1.5 text-rose-400 font-semibold text-[11px]">
                  <ShieldAlert className="w-3.5 h-3.5" />
                  <span>Destructive Guardrail: Never Blindly Repeat</span>
                </div>
                <div className="space-y-1">
                  {inspection.destructiveActionsBlocked.map((action, idx) => (
                    <div key={idx} className="p-1.5 rounded bg-rose-950/20 border border-rose-800/30 text-rose-200 text-[10px] flex items-center justify-between">
                      <span>✕ {action}</span>
                      <span className="text-[9px] font-mono text-rose-400">HARD-LOCKED</span>
                    </div>
                  ))}
                </div>
              </div>
            </>
          ) : (
            <p className="text-slate-400 text-center py-6">No previous pause checkpoint found.</p>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-xs transition-colors"
          >
            Keep Paused
          </button>
          <button
            onClick={onResumeConfirm}
            className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 active:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-emerald-950/60 transition-transform active:scale-95"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Confirm & Resume Safely</span>
          </button>
        </div>

      </div>
    </div>
  );
};
