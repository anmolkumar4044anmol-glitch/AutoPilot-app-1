import React from 'react';
import { 
  Shield, 
  Cpu, 
  Volume2, 
  VolumeX, 
  PhoneCall, 
  PhoneOff, 
  Square, 
  Activity, 
  Sparkles,
  Wifi,
  WifiOff,
  Flame,
  Minimize2,
  Maximize2
} from 'lucide-react';
import { AssistantStatus, DeviceMode, VoiceSettings, CallModeState } from '../types/autopilot';

interface HeaderProps {
  status: AssistantStatus;
  deviceMode: DeviceMode;
  onToggleDeviceMode: () => void;
  voiceSettings: VoiceSettings;
  onToggleVoice: () => void;
  onToggleCallMute: () => void;
  onEmergencyStop: () => void;
  isOnline: boolean;
  activeApp: string;
  onToggleMinimize?: () => void;
  isAppMinimized?: boolean;
  callMode?: CallModeState;
  onToggleCallMode?: () => void;
  onToggleManualQuietMode?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  status,
  deviceMode,
  onToggleDeviceMode,
  voiceSettings,
  onToggleVoice,
  onToggleCallMute,
  onEmergencyStop,
  isOnline,
  activeApp,
  onToggleMinimize,
  isAppMinimized = false,
  callMode,
  onToggleCallMode,
  onToggleManualQuietMode,
}) => {
  const isCallActive = callMode?.isCallActive || voiceSettings.isCallMuted;

  const getStatusBadge = () => {
    switch (status) {
      case 'GREEN_RUNNING':
        return (
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 animate-pulse">
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            RUNNING
          </span>
        );
      case 'ORANGE_PAUSED':
        return (
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-400 border border-amber-500/30">
            <span className="w-2 h-2 rounded-full bg-amber-400"></span>
            PAUSED
          </span>
        );
      case 'COOLING_PAUSED':
        return (
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 animate-pulse">
            <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
            COOLING
          </span>
        );
      case 'RED_EMERGENCY_STOP':
        return (
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-500/20 text-rose-400 border border-rose-500/30 animate-bounce">
            <span className="w-2 h-2 rounded-full bg-rose-400"></span>
            STOPPED
          </span>
        );
      default:
        return (
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-slate-800 text-slate-400 border border-slate-700">
            <span className="w-2 h-2 rounded-full bg-slate-500"></span>
            STANDBY
          </span>
        );
    }
  };

  const formatCallTime = (secs: number = 0) => {
    const mins = Math.floor(secs / 60);
    const rem = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${rem.toString().padStart(2, '0')}`;
  };

  return (
    <header className="sticky top-0 z-50 bg-slate-950/95 backdrop-blur-md border-b border-slate-800/80 px-4 py-2.5">
      {/* Top Banner if Call Mode is Active */}
      {isCallActive && (
        <div className="mb-2 -mx-4 -mt-2.5 bg-gradient-to-r from-amber-950 via-rose-950 to-amber-950 border-b border-amber-600/60 px-4 py-2 text-xs flex flex-wrap items-center justify-between gap-2 shadow-md">
          <div className="flex items-center gap-2 text-amber-200">
            <span className="flex h-2.5 w-2.5 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500"></span>
            </span>
            <span className="font-bold tracking-wide uppercase text-amber-300">
              📞 CALL MODE ACTIVE
            </span>
            <span className="text-amber-400/60">•</span>
            <span className="font-mono bg-amber-900/60 text-amber-200 px-1.5 py-0.5 rounded border border-amber-700/50">
              {formatCallTime(callMode?.callDurationSeconds)}
            </span>
            <span className="text-amber-400/60">•</span>
            <span className="text-slate-200 font-medium">
              Speech Output Muted • Written Command Mode Only
            </span>
            <span className="text-amber-400/60">•</span>
            <span className="text-emerald-400 text-[11px]">
              Phone Call Audio Untouched (Privacy Safe)
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] text-amber-300/80 hidden sm:inline">
              Task state preserved
            </span>
            <button
              onClick={onToggleCallMode || onToggleCallMute}
              className="px-2.5 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1 shadow transition-colors"
              title="End simulated call and restore prior voice settings"
            >
              <PhoneOff className="w-3.5 h-3.5" />
              <span>End Call (Restore Audio)</span>
            </button>
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
        {/* Brand & Identity */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 via-blue-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-cyan-950/50 border border-cyan-400/30">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold tracking-tight text-white flex items-center gap-1.5">
                AI AutoPilot
                <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800/50">
                  Android Core
                </span>
              </h1>
              {getStatusBadge()}
              {isCallActive && (
                <span className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse">
                  <PhoneCall className="w-3 h-3 text-amber-400" />
                  CALL MODE
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400 flex items-center gap-2">
              <span>Active Target: <strong className="text-slate-200">{activeApp}</strong></span>
              <span className="text-slate-600">•</span>
              <span className="flex items-center gap-1 text-[11px] text-slate-400">
                {isOnline ? (
                  <span className="flex items-center gap-1 text-emerald-400 font-medium">
                    <Wifi className="w-3 h-3" /> Cloud Gemini 3.8
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-amber-400 font-medium">
                    <WifiOff className="w-3 h-3" /> Offline Rules
                  </span>
                )}
              </span>
            </p>
          </div>
        </div>

        {/* Quick Mode Indicators & Actions */}
        <div className="flex items-center flex-wrap gap-2">
          {/* Performance Mode Switch (4GB Lite vs 8GB Advanced) */}
          <button
            onClick={onToggleDeviceMode}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all border ${
              deviceMode === 'lite'
                ? 'bg-amber-950/40 border-amber-600/40 text-amber-300 hover:bg-amber-900/40'
                : 'bg-indigo-950/40 border-indigo-600/40 text-indigo-300 hover:bg-indigo-900/40'
            }`}
            title="Click to toggle between 4GB Lite Mode and 8GB Advanced Mode"
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>{deviceMode === 'lite' ? '4 GB Lite Mode (RAM Saver)' : '8 GB Advanced Mode'}</span>
          </button>

          {/* Voice Mute Toggle */}
          <button
            onClick={onToggleVoice}
            className={`p-2 rounded-lg border text-xs flex items-center gap-1 transition-all ${
              voiceSettings.voiceEnabled && !voiceSettings.quietMode && !isCallActive
                ? 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700'
                : 'bg-rose-950/40 border-rose-800/40 text-rose-300'
            }`}
            title={
              isCallActive
                ? 'Speech Muted by Active Call'
                : voiceSettings.quietMode
                ? 'Quiet Mode Active (Voice Off)'
                : 'Voice Companion Active'
            }
          >
            {voiceSettings.voiceEnabled && !voiceSettings.quietMode && !isCallActive ? (
              <Volume2 className="w-4 h-4 text-emerald-400" />
            ) : (
              <VolumeX className="w-4 h-4 text-rose-400" />
            )}
          </button>

          {/* Automatic Call Mode Simulator Button */}
          <button
            onClick={onToggleCallMode || onToggleCallMute}
            className={`px-2.5 py-1.5 rounded-lg border text-xs flex items-center gap-1.5 transition-all font-medium ${
              isCallActive
                ? 'bg-gradient-to-r from-amber-600 to-rose-600 border-amber-400 text-white shadow-md shadow-amber-950/50 animate-pulse'
                : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800 hover:border-slate-700'
            }`}
            title="Simulate incoming phone call (automatically mutes speech, switches to written commands, preserves tasks)"
          >
            {isCallActive ? (
              <>
                <PhoneCall className="w-3.5 h-3.5 text-white" />
                <span className="font-bold">Call Active ({formatCallTime(callMode?.callDurationSeconds)})</span>
              </>
            ) : (
              <>
                <PhoneCall className="w-3.5 h-3.5 text-slate-400" />
                <span>Simulate Call</span>
              </>
            )}
          </button>

          {/* Manual Quiet Mode switch fallback */}
          {onToggleManualQuietMode && (
            <button
              onClick={onToggleManualQuietMode}
              className={`px-2.5 py-1.5 rounded-lg border text-xs flex items-center gap-1 transition-all ${
                callMode?.manualQuietModeFallback
                  ? 'bg-amber-950/60 border-amber-500 text-amber-300'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800'
              }`}
              title="Manual Quiet Mode Switch (Fallback if Android call detection permission is unavailable)"
            >
              <VolumeX className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Manual Quiet</span>
            </button>
          )}

          {/* Minimize AutoPilot to Background / Restore */}
          {onToggleMinimize && (
            <button
              onClick={onToggleMinimize}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all border ${
                isAppMinimized
                  ? 'bg-cyan-950/80 border-cyan-500 text-cyan-300 shadow-md shadow-cyan-950/50'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
              }`}
              title={isAppMinimized ? 'Restore AI AutoPilot Full Window' : 'Minimize AutoPilot (Runs in background with floating bubble)'}
            >
              {isAppMinimized ? (
                <>
                  <Maximize2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Restore App</span>
                </>
              ) : (
                <>
                  <Minimize2 className="w-3.5 h-3.5 text-slate-400" />
                  <span>Minimize App</span>
                </>
              )}
            </button>
          )}

          {/* PERSISTENT EMERGENCY STOP (RED) */}
          <button
            onClick={onEmergencyStop}
            className="px-3.5 py-1.5 rounded-lg font-bold text-xs uppercase tracking-wider bg-rose-600 hover:bg-rose-700 active:bg-rose-800 text-white flex items-center gap-1.5 shadow-lg shadow-rose-950/50 border border-rose-400/50 transition-transform active:scale-95"
            title="Emergency Stop: Instantly halts all ongoing automation and gestures"
          >
            <Square className="w-3.5 h-3.5 fill-current" />
            <span>STOP</span>
          </button>
        </div>
      </div>
    </header>
  );
};

