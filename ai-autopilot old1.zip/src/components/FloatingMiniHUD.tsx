import React from 'react';
import { 
  AssistantStatus, 
  TaskStep, 
  IntelligentResumeInspection 
} from '../types/autopilot';
import { 
  Play, 
  Pause, 
  Square, 
  Maximize2, 
  Power, 
  Sparkles, 
  ShieldCheck, 
  X, 
  Flame, 
  RotateCcw,
  Sliders
} from 'lucide-react';

interface FloatingMiniHUDProps {
  status: AssistantStatus;
  currentStep?: TaskStep;
  onTogglePauseResume: () => void;
  onEmergencyStop: () => void;
  onReopenApp: () => void;
  onCloseAutoPilot: () => void;
  onOpenInspector: () => void;
  onCloseHUD: () => void;
  activeApp: string;
  isCallActive?: boolean;
}

export const FloatingMiniHUD: React.FC<FloatingMiniHUDProps> = ({
  status,
  currentStep,
  onTogglePauseResume,
  onEmergencyStop,
  onReopenApp,
  onCloseAutoPilot,
  onOpenInspector,
  onCloseHUD,
  activeApp,
  isCallActive = false,
}) => {
  return (
    <div className="w-64 bg-slate-900/95 border border-slate-700/90 rounded-2xl p-3 shadow-2xl backdrop-blur-lg text-slate-100 space-y-2.5 z-50 animate-in fade-in zoom-in-95 duration-150 select-none">
      {/* Top Bar with Close button */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-2">
        <div className="flex items-center gap-1.5">
          <div className={`w-3 h-3 rounded-full ${
            status === 'GREEN_RUNNING' ? 'bg-emerald-500 animate-pulse' :
            status === 'ORANGE_PAUSED' ? 'bg-amber-500' :
            status === 'COOLING_PAUSED' ? 'bg-cyan-400 animate-pulse' :
            status === 'RED_EMERGENCY_STOP' ? 'bg-rose-600 animate-ping' :
            'bg-slate-500'
          }`} />
          <span className="font-bold text-xs text-white">AutoPilot Mini-HUD</span>
        </div>
        <button
          onClick={onCloseHUD}
          className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* CALL MODE ACTIVE ALERT IN MINI-HUD */}
      {isCallActive && (
        <div className="flex items-center justify-between text-[10px] bg-gradient-to-r from-amber-950 to-rose-950 p-1.5 rounded-lg border border-amber-600/70 text-amber-200 animate-pulse">
          <span className="flex items-center gap-1 font-bold">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-400"></span>
            CALL MODE ACTIVE
          </span>
          <span className="text-[9px] font-mono text-amber-300">
            SPEECH MUTED
          </span>
        </div>
      )}

      {/* Target Game & Guardrail Badge */}
      <div className="flex items-center justify-between text-[10px] bg-slate-950/70 p-1.5 rounded-lg border border-slate-800/80">
        <span className="flex items-center gap-1 text-amber-400 font-medium">
          <Flame className="w-3 h-3 text-amber-500" />
          <span>{activeApp}</span>
        </span>
        <span className="text-emerald-400 font-mono text-[9px] bg-emerald-950/80 px-1 rounded border border-emerald-800">
          GUARD ACTIVE
        </span>
      </div>

      {/* Current Execution State */}
      <div className="p-2 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
        <div className="flex items-center justify-between text-[10px] text-slate-400 font-medium">
          <span>TASK STATUS</span>
          <span className={`font-bold font-mono ${
            status === 'GREEN_RUNNING' ? 'text-emerald-400' :
            status === 'ORANGE_PAUSED' ? 'text-amber-400' :
            status === 'COOLING_PAUSED' ? 'text-cyan-400' :
            'text-rose-400'
          }`}>
            {status === 'GREEN_RUNNING' ? 'GREEN • EXECUTING' :
             status === 'ORANGE_PAUSED' ? 'ORANGE • PAUSED' :
             status === 'COOLING_PAUSED' ? 'CYAN • COOLING PAUSE' :
             'RED • STOPPED'}
          </span>
        </div>
        <p className="text-[11px] text-slate-200 truncate font-medium">
          {currentStep ? currentStep.description : 'Monitoring Free Fire Battleground HUD'}
        </p>
      </div>

      {/* Quick Action Buttons */}
      <div className="grid grid-cols-2 gap-1.5 text-xs">
        {status === 'GREEN_RUNNING' ? (
          <button
            onClick={onTogglePauseResume}
            className="py-2 px-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold flex items-center justify-center gap-1 shadow transition-transform active:scale-95"
            title="Pause current task without closing AutoPilot"
          >
            <Pause className="w-3.5 h-3.5 fill-current" />
            <span>Pause (Orange)</span>
          </button>
        ) : (
          <button
            onClick={onTogglePauseResume}
            className="py-2 px-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-bold flex items-center justify-center gap-1 shadow transition-transform active:scale-95"
            title="Intelligent Pause & Resume: verifies screen and continues safely"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Resume (Green)</span>
          </button>
        )}

        <button
          onClick={onEmergencyStop}
          className="py-2 px-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold flex items-center justify-center gap-1 shadow transition-transform active:scale-95"
          title="Instant Emergency Stop"
        >
          <Square className="w-3.5 h-3.5 fill-current" />
          <span>Stop (Red)</span>
        </button>
      </div>

      {/* Intelligent State Inspector Button */}
      <button
        onClick={onOpenInspector}
        className="w-full py-1.5 px-2 bg-slate-800/80 hover:bg-slate-800 text-cyan-300 border border-cyan-800/40 rounded-xl text-[11px] font-medium flex items-center justify-center gap-1.5 transition-colors"
      >
        <Sparkles className="w-3 h-3 text-cyan-400" />
        <span>Intelligent Resume Inspector</span>
      </button>

      {/* Application Control: Reopen & Close */}
      <div className="grid grid-cols-2 gap-1.5 pt-1 border-t border-slate-800 text-[10px]">
        <button
          onClick={onReopenApp}
          className="py-1.5 px-2 bg-indigo-950/60 hover:bg-indigo-900/60 text-indigo-300 border border-indigo-800/60 rounded-lg flex items-center justify-center gap-1 font-medium"
        >
          <Maximize2 className="w-3 h-3" />
          <span>Reopen App</span>
        </button>

        <button
          onClick={onCloseAutoPilot}
          className="py-1.5 px-2 bg-rose-950/40 hover:bg-rose-900/40 text-rose-300 border border-rose-900/60 rounded-lg flex items-center justify-center gap-1 font-medium"
          title="Explicitly shuts down foreground service, overlay, and tasks"
        >
          <Power className="w-3 h-3 text-rose-400" />
          <span>Close AutoPilot</span>
        </button>
      </div>
    </div>
  );
};
