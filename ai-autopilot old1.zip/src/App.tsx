/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Header } from './components/Header';
import { PhoneSimulator } from './components/PhoneSimulator';
import { DashboardTab } from './components/tabs/DashboardTab';
import { AdaptiveIntelligenceTab } from './components/tabs/AdaptiveIntelligenceTab';
import { HumanTouchTab } from './components/tabs/HumanTouchTab';
import { FloatingAssistantTab } from './components/tabs/FloatingAssistantTab';
import { VoiceCompanionTab } from './components/tabs/VoiceCompanionTab';
import { VideoLearningTab } from './components/tabs/VideoLearningTab';
import { PerformanceTab } from './components/tabs/PerformanceTab';
import { ApkStudioTab } from './components/tabs/ApkStudioTab';
import { SecurityAuditTab } from './components/tabs/SecurityAuditTab';
import { WorkflowMemoryTab } from './components/tabs/WorkflowMemoryTab';
import { IntelligentResumeModal } from './components/IntelligentResumeModal';
import { OngoingNotificationBar } from './components/OngoingNotificationBar';
import { ImportantActionConfirmationModal } from './components/ImportantActionConfirmationModal';

import { 
  AssistantStatus, 
  DeviceMode, 
  TouchSettings, 
  VoiceSettings, 
  FloatingAssistantState, 
  TaskPlan, 
  TaskStep, 
  LogEntry, 
  WorkflowItem,
  IntelligentResumeInspection,
  CallModeState,
  AdaptivePerformanceSettings,
  DeviceRecommendation,
  SensitiveActionRequest
} from './types/autopilot';
import { DEFAULT_WORKFLOWS } from './data/defaultWorkflows';
import { DEFAULT_TOUCH_SETTINGS, LOCAL_STORAGE_TOUCH_KEY, calculateHumanizedDelay } from './data/defaultTouchSettings';
import { 
  DEFAULT_PERFORMANCE_SETTINGS, 
  LOCAL_STORAGE_PERFORMANCE_KEY, 
  detectDeviceRecommendation, 
  calculateLivePerformanceMetrics,
  LITE_MODE_DEFAULTS,
  ADVANCED_MODE_DEFAULTS 
} from './data/defaultPerformanceSettings';
import { requestTaskPlan, checkServerHealth } from './services/api';
import { voiceCompanion } from './services/voice';

import { 
  LayoutDashboard, 
  Cpu, 
  Sliders, 
  Layers, 
  Volume2, 
  BookOpen, 
  Activity, 
  Download, 
  ShieldCheck, 
  History,
  Flame,
  CheckCircle2,
  AlertTriangle,
  Maximize2,
  Minimize2
} from 'lucide-react';

export default function App() {
  // Core System States
  const [status, setStatus] = useState<AssistantStatus>('IDLE');
  const [activeApp, setActiveApp] = useState<string>('Free Fire India');
  const [isOnline, setIsOnline] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isPlanning, setIsPlanning] = useState<boolean>(false);
  const [isListening, setIsListening] = useState<boolean>(false);

  // Task & Planning States
  const [activePlan, setActivePlan] = useState<TaskPlan | null>(null);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [workflows, setWorkflows] = useState<WorkflowItem[]>(DEFAULT_WORKFLOWS);

  // Settings with LocalStorage Persistence
  const [touchSettings, setTouchSettings] = useState<TouchSettings>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_TOUCH_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return { ...DEFAULT_TOUCH_SETTINGS, ...parsed };
      }
    } catch (e) {
      // fallback
    }
    return DEFAULT_TOUCH_SETTINGS;
  });

  // Auto-persist touch settings between sessions
  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_TOUCH_KEY, JSON.stringify(touchSettings));
    } catch (e) {
      // ignore
    }
  }, [touchSettings]);

  const [voiceSettings, setVoiceSettings] = useState<VoiceSettings>({
    voiceEnabled: true,
    language: 'auto',
    fastTalkMode: true,
    quietMode: false,
    speechSpeed: 1.15,
    speechPitch: 0.95,
    isCallMuted: false,
  });

  // Automatic Call Mode State
  const [callMode, setCallMode] = useState<CallModeState>({
    isCallActive: false,
    callState: 'IDLE',
    callerLabel: 'No Active Call',
    callDurationSeconds: 0,
    speechMuted: false,
    audioPlaybackBlocked: false,
    writtenCommandModeActive: false,
    detectionAvailable: true,
    manualQuietModeFallback: false,
    savedVoiceSnapshot: null,
  });

  // Call duration counter
  useEffect(() => {
    let interval: any = null;
    if (callMode.isCallActive) {
      interval = setInterval(() => {
        setCallMode((prev) => ({
          ...prev,
          callDurationSeconds: prev.callDurationSeconds + 1,
        }));
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [callMode.isCallActive]);

  // Sync callMode state with voiceSettings
  useEffect(() => {
    setVoiceSettings((v) => ({
      ...v,
      isCallMuted: callMode.isCallActive || callMode.speechMuted || callMode.manualQuietModeFallback,
      callMode: callMode,
    }));
  }, [callMode]);

  // Automatic Call Mode Handlers (Specification Compliance)
  // When a phone call is active:
  // 1. Automatically mute AI AutoPilot speech output.
  // 2. Switch to written command mode.
  // 3. Continue accepting permitted written commands.
  // 4. Avoid unnecessary audio playback.
  // 5. Preserve task state.
  // 6. Restore the previous voice settings when the call ends.
  const handleStartCallMode = (simulatedState: 'RINGING' | 'OFFHOOK' = 'OFFHOOK', caller: string = 'Active Voice Call') => {
    const snapshot = {
      voiceEnabled: voiceSettings.voiceEnabled,
      speechSpeed: voiceSettings.speechSpeed,
      speechPitch: voiceSettings.speechPitch,
      quietMode: voiceSettings.quietMode,
      fastTalkMode: voiceSettings.fastTalkMode,
    };

    // Immediately stop ongoing speech
    voiceCompanion.stop();

    setCallMode((prev) => ({
      ...prev,
      isCallActive: true,
      callState: simulatedState,
      callerLabel: caller,
      callDurationSeconds: 0,
      speechMuted: true,
      audioPlaybackBlocked: true,
      writtenCommandModeActive: true,
      savedVoiceSnapshot: snapshot,
    }));

    setVoiceSettings((v) => ({
      ...v,
      isCallMuted: true,
    }));

    addLog(
      'AUTOMATIC CALL MODE: Phone call detected. AutoPilot speech muted. Switched to Written Command Mode. Actual telephone call is untouched. Task state preserved.',
      'warning',
      'Privacy Safe'
    );
  };

  const handleEndCallMode = () => {
    const snapshot = callMode.savedVoiceSnapshot;

    if (snapshot) {
      setVoiceSettings((v) => ({
        ...v,
        voiceEnabled: snapshot.voiceEnabled,
        speechSpeed: snapshot.speechSpeed,
        speechPitch: snapshot.speechPitch,
        quietMode: snapshot.quietMode,
        fastTalkMode: snapshot.fastTalkMode,
        isCallMuted: false,
      }));
    } else {
      setVoiceSettings((v) => ({
        ...v,
        isCallMuted: false,
      }));
    }

    setCallMode((prev) => ({
      ...prev,
      isCallActive: false,
      callState: 'IDLE',
      callerLabel: 'No Active Call',
      callDurationSeconds: 0,
      speechMuted: false,
      audioPlaybackBlocked: false,
      writtenCommandModeActive: false,
      savedVoiceSnapshot: null,
    }));

    addLog(
      'CALL ENDED: Restored previous voice companion settings. Task state verified and intact.',
      'info'
    );
  };

  const handleToggleCallMode = (action?: 'start' | 'end') => {
    if (action === 'end' || callMode.isCallActive || voiceSettings.isCallMuted) {
      handleEndCallMode();
    } else {
      handleStartCallMode('OFFHOOK', 'Simulated Voice Call');
    }
  };

  const handleToggleManualQuietMode = () => {
    const next = !callMode.manualQuietModeFallback;
    setCallMode((prev) => ({
      ...prev,
      manualQuietModeFallback: next,
      speechMuted: next || prev.isCallActive,
      writtenCommandModeActive: next || prev.isCallActive,
    }));
    setVoiceSettings((v) => ({
      ...v,
      isCallMuted: next || callMode.isCallActive,
    }));
    if (next) {
      voiceCompanion.stop();
      addLog('Manual Quiet Mode ACTIVATED: Speech output silenced. Switched to Written Command Mode.', 'info');
    } else {
      addLog('Manual Quiet Mode DEACTIVATED: Normal voice output restored.', 'info');
    }
  };

  const [floatingState, setFloatingState] = useState<FloatingAssistantState>({
    status: 'IDLE',
    x: 16,
    y: 36,
    isOverlayActive: true,
    opacity: 0.95,
    sizePx: 42,
    isMinimized: false,
    isServiceActive: true,
    ongoingNotificationVisible: true,
  });

  const [isAppMinimized, setIsAppMinimized] = useState<boolean>(false);
  const [isInspectorOpen, setIsInspectorOpen] = useState<boolean>(false);
  const [inspectionState, setInspectionState] = useState<IntelligentResumeInspection | null>(null);

  // Adaptive Performance Settings with LocalStorage Persistence
  const [performanceSettings, setPerformanceSettings] = useState<AdaptivePerformanceSettings>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_PERFORMANCE_KEY);
      if (saved) {
        return { ...DEFAULT_PERFORMANCE_SETTINGS, ...JSON.parse(saved) };
      }
    } catch (e) {
      // ignore
    }
    return DEFAULT_PERFORMANCE_SETTINGS;
  });

  const [deviceRecommendation, setDeviceRecommendation] = useState<DeviceRecommendation>(() => detectDeviceRecommendation());

  // Auto-persist performance settings
  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_PERFORMANCE_KEY, JSON.stringify(performanceSettings));
    } catch (e) {
      // ignore
    }
  }, [performanceSettings]);

  // Derived deviceMode for header sync
  const deviceMode = performanceSettings.mode;
  const setDeviceMode = (mode: DeviceMode) => {
    setPerformanceSettings(mode === 'lite' ? LITE_MODE_DEFAULTS : ADVANCED_MODE_DEFAULTS);
  };

  // Real-time calculated telemetry metrics
  const performanceMetrics = calculateLivePerformanceMetrics(
    performanceSettings,
    status === 'GREEN_RUNNING',
    status === 'IDLE' || status === 'ORANGE_PAUSED',
    status === 'GREEN_RUNNING' ? 1 : 0
  );

  // Custom Gameplay Cooling Cooldowns state (Anti-overheating)
  const [gameplayContinuousSeconds, setGameplayContinuousSeconds] = useState<number>(0);
  const [coolingRemainingSeconds, setCoolingRemainingSeconds] = useState<number>(0);

  // Important Actions Confirmation state (Safety Manager)
  const [pendingSensitiveAction, setPendingSensitiveAction] = useState<SensitiveActionRequest | null>(null);

  // System Audit Logs
  const [logs, setLogs] = useState<LogEntry[]>([
    {
      id: 'log-1',
      timestamp: '10:00:12',
      type: 'info',
      message: 'AI AutoPilot Native Engine initialized.',
      details: '4GB Lite Mode Active',
    },
    {
      id: 'log-2',
      timestamp: '10:00:15',
      type: 'success',
      message: 'Accessibility Service & Overlay Window verified.',
      details: 'Permissions OK',
    },
  ]);

  const addLog = (message: string, type: LogEntry['type'] = 'info', details?: string) => {
    const newEntry: LogEntry = {
      id: `log_${Date.now()}_${Math.random()}`,
      timestamp: new Date().toLocaleTimeString(),
      type,
      message,
      details,
    };
    setLogs((prev) => [newEntry, ...prev.slice(0, 50)]);
  };

  // Check backend cloud status on startup
  useEffect(() => {
    checkServerHealth().then((res) => {
      setIsOnline(res.geminiConfigured);
      if (res.geminiConfigured) {
        addLog('Cloud AI Brain (Gemini 3.8 Flash) connected.', 'success');
      } else {
        addLog('Operating with verified offline local rules.', 'warning');
      }
    });

    // Load initial workflow as active plan for quick user start
    const initialWf = DEFAULT_WORKFLOWS[0];
    setActivePlan({
      taskName: initialWf.title,
      originalCommand: initialWf.description,
      summary: initialWf.description,
      languageDetected: 'en',
      intendedResult: 'Calibrate 98% General Sensitivity and deploy instant Gloo Wall pro combo',
      selectedStrategy: 'Direct Accessibility Dispatch (Recommended)',
      steps: initialWf.steps,
      adaptiveStrategies: [
        {
          name: 'Direct Accessibility Dispatch (Recommended)',
          reliabilityScore: 97,
          safetyScore: 99,
          estimatedTime: '2.4s',
          timeMs: 2400,
          batteryImpact: 'very_low',
          memoryImpactKb: 420,
          description: 'Targets precise View IDs inside Free Fire HUD.',
          tradeoffSummary: 'Minimal resource usage, recommended for 4GB RAM devices.',
          isPermitted: true,
          isBest: true,
        },
        {
          name: 'Bézier Coordinate Curve Dispatch',
          reliabilityScore: 92,
          safetyScore: 96,
          estimatedTime: '3.1s',
          timeMs: 3100,
          batteryImpact: 'low',
          memoryImpactKb: 650,
          description: 'Simulates human thumb arcs to prevent anti-cheat detection.',
          tradeoffSummary: 'Ideal when view hierarchy is obfuscated in games.',
          isPermitted: true,
        },
        {
          name: 'Visual Pattern Match (OCR Fallback)',
          reliabilityScore: 85,
          safetyScore: 92,
          estimatedTime: '4.5s',
          timeMs: 4500,
          batteryImpact: 'medium',
          memoryImpactKb: 1300,
          description: 'Scans frame buffer for icon shapes if nodes drift.',
          tradeoffSummary: 'Higher CPU usage; only engaged if primary strategies fail.',
          isPermitted: true,
        },
      ],
      restrictionsFollowed: ['Stay in active app', 'Humanized touch jitter applied'],
      hardConstraints: [
        {
          id: 'hc-1',
          text: 'Do not close the current application',
          type: 'hard_constraint',
          isViolated: false,
          status: 'enforced',
          explanation: 'Operations constrained to active foreground game window.',
        },
        {
          id: 'hc-2',
          text: 'Do not repeat completed actions',
          type: 'hard_constraint',
          isViolated: false,
          status: 'enforced',
          explanation: 'Checkpoints prevent duplicated actions.',
        },
      ],
      recoveryHistory: [],
      userCorrections: [],
      failedMethodsBlacklist: [],
      completionReport: {
        status: 'success',
        explanation: 'Initial pro macro plan loaded and ready for activation.',
        language: 'en',
        completedStepsCount: 0,
        totalStepsCount: initialWf.steps.length,
      },
    });
  }, []);

  // Sync floating state status
  useEffect(() => {
    setFloatingState((prev) => ({ ...prev, status }));
  }, [status]);

  // Step-by-Step Execution Simulator
  useEffect(() => {
    if (status !== 'GREEN_RUNNING' || !activePlan) return;

    // Enforce strict gaming-only restriction (never activate on non-gaming applications)
    const isGamingApp = activeApp.toLowerCase().includes('free fire') || 
                        activeApp.toLowerCase().includes('game') || 
                        activeApp.toLowerCase().includes('web');
    if (touchSettings.gamingOnlyRestriction && !isGamingApp) {
      setStatus('ORANGE_PAUSED');
      addLog(`AUTOTOUCH BLOCKED: AutoPilot is strictly restricted to Free Fire, gaming apps, and web games. Inactive on "${activeApp}".`, 'security');
      voiceCompanion.speak('AutoTouch blocked on non-gaming app. Automation is locked to games only.', voiceSettings);
      return;
    }

    if (currentStepIndex >= activePlan.steps.length) {
      // Completed all steps
      setStatus('ORANGE_PAUSED');
      addLog(`All steps for "${activePlan.taskName}" completed and verified!`, 'success');
      voiceCompanion.speak('Task completed. All steps verified successfully.', voiceSettings);
      return;
    }

    const currentStep = activePlan.steps[currentStepIndex];
    const { actualDelayMs, jitterMs } = calculateHumanizedDelay(touchSettings.customDelayMs, touchSettings);
    const cooldownDelay = performanceSettings.cooldownPeriodsEnabled ? performanceSettings.cooldownDurationMs : 0;
    const jitterLog = touchSettings.humanizedDelayEnabled
      ? ` (~${actualDelayMs}ms [${touchSettings.customDelayMs}ms ${jitterMs >= 0 ? '+' : ''}${jitterMs}ms jitter])`
      : ` (~${actualDelayMs}ms)`;
    addLog(`Executing: ${currentStep.description}`, 'info', `${jitterLog}${cooldownDelay > 0 ? ` +${cooldownDelay}ms cooldown` : ''}`);

    // Announce step in Fast Talk mode
    if (currentStepIndex === 0) {
      voiceCompanion.speak(`Task started. ${currentStep.description}`, voiceSettings);
    }

    const timer = setTimeout(() => {
      addLog(`Verified: ${currentStep.verification}`, 'success');
      setCurrentStepIndex((prev) => prev + 1);
    }, Math.max(700, actualDelayMs + (currentStep.estimatedTimeMs || 350) + cooldownDelay));

    return () => clearTimeout(timer);
  }, [status, currentStepIndex, activePlan, touchSettings, performanceSettings, voiceSettings]);

  // Continuous Gameplay Runtime & Anti-Overheating Cooling Cooldowns
  useEffect(() => {
    let interval: any = null;
    if (status === 'GREEN_RUNNING') {
      interval = setInterval(() => {
        setGameplayContinuousSeconds((prev) => {
          const next = prev + 1;
          const targetSeconds = (performanceSettings.coolingIntervalMinutes || 10) * 60;
          if (performanceSettings.periodicCoolingEnabled && next >= targetSeconds) {
            // Trigger Cooling Cooldown!
            setStatus('COOLING_PAUSED');
            setCoolingRemainingSeconds(performanceSettings.coolingPauseDurationSec || 8);
            addLog(
              `❄️ COOLING COOLDOWN ENGAGED: Continuous gameplay reached ${performanceSettings.coolingIntervalMinutes} minutes. Forcing ${performanceSettings.coolingPauseDurationSec}s thermal pause to protect device from overheating.`,
              'warning',
              'Anti-Overheating'
            );
            if (!callMode.isCallActive && !callMode.speechMuted && !voiceSettings.isCallMuted) {
              voiceCompanion.speak(
                `Cooling pause active. Pausing gestures for ${performanceSettings.coolingPauseDurationSec} seconds to let phone cool down.`,
                voiceSettings
              );
            }
            return 0; // reset counter
          }
          return next;
        });
      }, 1000);
    } else if (status === 'COOLING_PAUSED') {
      interval = setInterval(() => {
        setCoolingRemainingSeconds((prev) => {
          if (prev <= 1) {
            setStatus('GREEN_RUNNING');
            addLog('❄️ Cooling Cooldown Complete: Touch automation safely resumed.', 'success', 'Thermal Drop OK');
            if (!callMode.isCallActive && !callMode.speechMuted && !voiceSettings.isCallMuted) {
              voiceCompanion.speak('Cooling complete. Touch automation resumed.', voiceSettings);
            }
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [status, performanceSettings, callMode, voiceSettings]);

  const handleSkipCoolingCooldown = () => {
    setStatus('GREEN_RUNNING');
    setCoolingRemainingSeconds(0);
    setGameplayContinuousSeconds(0);
    addLog('Cooling cooldown skipped by user. Immediate touch execution restored.', 'info');
  };

  const handleSimulateCoolingCooldown = () => {
    setStatus('COOLING_PAUSED');
    setCoolingRemainingSeconds(performanceSettings.coolingPauseDurationSec || 8);
    addLog(
      `❄️ Cooling Cooldown Test Triggered: Forcing ${performanceSettings.coolingPauseDurationSec}s pause to demonstrate thermal protection.`,
      'warning',
      'Test Active'
    );
  };

  // Important Actions Confirmation Handlers (Safety Manager)
  const handleTriggerSensitiveActionTest = (type: SensitiveActionRequest['type']) => {
    const isCred = type === 'blocked_credentials';
    const testRequest: SensitiveActionRequest = {
      id: `req-${Date.now()}`,
      type,
      title: isCred
        ? 'AUTOMATED CREDENTIAL INPUT ATTEMPT'
        : type === 'make_payment'
        ? 'In-Game Store Payment Confirmation'
        : type === 'send_message'
        ? 'In-Game Global Chat Message'
        : type === 'delete_data'
        ? 'Purge Saved Offline Workflows'
        : type === 'sensitive_form'
        ? 'Submit Account Information Form'
        : 'Share Hardware & Location Data',
      description: isCred
        ? 'Detected attempt to automate input into a Password / OTP / PIN field.'
        : `AutoPilot is preparing to execute a sensitive action requiring your explicit consent.`,
      targetApp: activeApp,
      timestamp: new Date().toLocaleTimeString(),
      payloadSummary: isCred
        ? 'Target: input[type="password"] / PIN prompt'
        : type === 'make_payment'
        ? 'Order: 520 Free Fire Diamonds (₹400 INR)'
        : type === 'send_message'
        ? 'Content: "Need backup at Clock Tower!"'
        : type === 'delete_data'
        ? 'Scope: Room database table "workflows"'
        : 'Action parameters verified',
      isBlockedByPolicy: isCred,
      policyReason: isCred
        ? 'Permanent Hard Stop: AutoPilot strictly forbids automated entry of passwords, OTPs, and banking credentials.'
        : 'User Ownership Gate: Important actions require explicit user confirmation before dispatch.',
      status: 'pending',
    };

    setPendingSensitiveAction(testRequest);
    if (isCred) {
      addLog('SECURITY POLICY VIOLATION BLOCKED: Automated password/OTP entry was attempted and permanently blocked.', 'security', 'Zero Tolerance');
      if (!callMode.isCallActive && !voiceSettings.isCallMuted) {
        voiceCompanion.speak('Automated password entry blocked by safety policy.', voiceSettings);
      }
    }
  };

  const handleApproveSensitiveAction = (id: string) => {
    if (!pendingSensitiveAction) return;
    addLog(`User approved important action: ${pendingSensitiveAction.title}. Dispatched safely.`, 'success');
    setPendingSensitiveAction(null);
  };

  const handleRejectSensitiveAction = (id: string) => {
    if (!pendingSensitiveAction) return;
    addLog(`User rejected important action: ${pendingSensitiveAction.title}. Action aborted. Control returned to user.`, 'warning');
    setPendingSensitiveAction(null);
  };

  // Emergency Stop Handler (RED State)
  // When activated:
  // • Immediately cancel queued actions
  // • Stop ongoing gesture dispatch
  // • Cancel active task execution
  // • Preserve task history
  // • Return control to the user
  const handleEmergencyStop = () => {
    setStatus('RED_EMERGENCY_STOP');
    voiceCompanion.stop();
    setCoolingRemainingSeconds(0);
    setGameplayContinuousSeconds(0);
    setPendingSensitiveAction(null);
    addLog(
      'EMERGENCY STOP ACTIVATED: Queued actions cancelled, gesture dispatch severed, active task halted. Task history preserved. Control returned to user.',
      'error',
      'Control Returned'
    );
    if (!callMode.isCallActive && !voiceSettings.isCallMuted) {
      voiceCompanion.speak('Emergency stop activated. Control returned to user.', voiceSettings);
    }
  };

  // Explicit Close AutoPilot Handler (Specification Section 6)
  // When user explicitly closes AutoPilot:
  // - Stop automation
  // - Cancel active task execution
  // - Remove floating controls
  // - Stop foreground service
  // - Remove ongoing notification
  const handleCloseAutoPilot = () => {
    setStatus('IDLE');
    setFloatingState((prev) => ({
      ...prev,
      isServiceActive: false,
      ongoingNotificationVisible: false,
    }));
    voiceCompanion.stop();
    addLog('AutoPilot explicitly closed: Foreground Service stopped, overlay removed, ongoing notification cancelled.', 'warning');
    voiceCompanion.speak('AutoPilot foreground service stopped.', voiceSettings);
  };

  // Intelligent Pause and Resume Handler (Specification Section 5)
  // OFF: pauses the current task, does not close AutoPilot
  // ON: triggers Intelligent Pause and Resume
  const handleTogglePauseResume = () => {
    if (status === 'GREEN_RUNNING') {
      // OFF: Pause current task (Turn Orange)
      setStatus('ORANGE_PAUSED');
      addLog(`AutoPilot paused. Preserving checkpoint at step #${currentStepIndex + 1} of "${activePlan?.taskName || 'Workflow'}".`, 'info');
      voiceCompanion.speak('AutoPilot paused. Screen and step progress saved.', voiceSettings);

      const completed = activePlan ? activePlan.steps.slice(0, currentStepIndex).map((s) => s.description) : [];
      const currentDesc = activePlan?.steps[currentStepIndex]?.description || 'Next game action';
      setInspectionState({
        savedCheckpointStepIndex: currentStepIndex,
        savedTaskName: activePlan?.taskName || 'Free Fire Tactical Macro',
        screenDetected: `${activeApp} (Verified Overlay)`,
        completedSteps: completed.length > 0 ? completed : ['No prior steps completed'],
        changesDetected: ['Screen verified: Free Fire HUD active', 'Zero UI coordinate drift'],
        recalculatedAction: currentDesc,
        destructiveActionsBlocked: [
          'In-game diamond / coin purchase',
          'Account logout / credential prompt',
          'System permission modifications',
        ],
        timestamp: new Date().toLocaleTimeString(),
        safeNextStepIndex: currentStepIndex,
        confidenceScore: 99,
      });
    } else {
      // ON: Trigger Intelligent Pause and Resume
      const isGamingApp = activeApp.toLowerCase().includes('free fire') || 
                          activeApp.toLowerCase().includes('game') || 
                          activeApp.toLowerCase().includes('web');
      if (touchSettings.gamingOnlyRestriction && !isGamingApp) {
        setStatus('ORANGE_PAUSED');
        addLog(`AUTOTOUCH BLOCKED: Cannot resume on "${activeApp}". AutoPilot is strictly locked to Free Fire and gaming apps.`, 'security');
        voiceCompanion.speak('Cannot resume. AutoTouch is strictly locked to games only.', voiceSettings);
        return;
      }

      const completed = activePlan ? activePlan.steps.slice(0, currentStepIndex).map((s) => s.description) : [];
      const safeDesc = activePlan?.steps[currentStepIndex]?.description || 'Resume verified macro';

      setInspectionState({
        savedCheckpointStepIndex: currentStepIndex,
        savedTaskName: activePlan?.taskName || 'Free Fire Tactical Macro',
        screenDetected: `${activeApp} (Active Viewport)`,
        completedSteps: completed,
        changesDetected: ['Screen verified: Live Free Fire battleground verified'],
        recalculatedAction: `Safely resuming Step #${currentStepIndex + 1}: ${safeDesc}`,
        destructiveActionsBlocked: [
          'In-game diamond / store purchases',
          'Repetitive weapon reload loops',
          'Third-party non-gaming triggers',
        ],
        timestamp: new Date().toLocaleTimeString(),
        safeNextStepIndex: currentStepIndex,
        confidenceScore: 98,
      });

      setStatus('GREEN_RUNNING');
      setFloatingState((prev) => ({ ...prev, isServiceActive: true }));
      addLog(`Intelligent Resume: Screen verified, duplicate steps skipped. Continuing safely from Step #${currentStepIndex + 1}.`, 'success');
      voiceCompanion.speak('Resuming safely from verified checkpoint.', voiceSettings);
    }
  };

  const handleToggleMinimize = () => {
    setIsAppMinimized((prev) => {
      const next = !prev;
      addLog(next 
        ? 'Application minimized to background. Movable floating control active on screen.' 
        : 'Application restored from background.', 'info');
      return next;
    });
  };

  // Execute or Plan a new Task
  const handleExecutePlan = async (command: string, language: string = 'en') => {
    setIsPlanning(true);
    addLog(`Analyzing command: "${command}"...`, 'info');
    try {
      const plan = await requestTaskPlan(command, deviceMode, language, ['Do not close active app']);
      setActivePlan(plan);
      setCurrentStepIndex(0);
      setStatus('GREEN_RUNNING');
      addLog(`Plan generated: ${plan.taskName} (${plan.steps.length} steps)`, 'success');
      
      // Only speak if speech is allowed and call is NOT active
      if (!callMode.isCallActive && !callMode.speechMuted && !voiceSettings.isCallMuted) {
        voiceCompanion.speak(`Starting task: ${plan.taskName}`, voiceSettings);
      }
    } catch (err) {
      addLog('Failed to plan task. Falling back to safe offline profile.', 'error');
    } finally {
      setIsPlanning(false);
    }
  };

  // Voice Input Speech-to-Text
  const handleStartVoiceInput = () => {
    // If call is active, speech input is switched to written command mode
    if (callMode.isCallActive || callMode.speechMuted || voiceSettings.isCallMuted) {
      addLog('Microphone input suspended during active phone call. Please use Written Command Mode.', 'warning');
      return;
    }

    if (isListening) {
      voiceCompanion.stopListening();
      setIsListening(false);
      return;
    }

    setIsListening(true);
    voiceCompanion.startListening(
      (transcript) => {
        setIsListening(false);
        addLog(`Voice recognized: "${transcript}"`, 'info');
        handleExecutePlan(transcript);
      },
      (err) => {
        setIsListening(false);
        addLog(`Voice input error: ${err}`, 'warning');
      },
      () => {
        setIsListening(false);
      }
    );
  };

  // Simulate Error Recovery
  const handleSimulateErrorRecovery = () => {
    if (!activePlan) return;
    setStatus('ORANGE_PAUSED');
    addLog('Simulated Error: Screen node shifted or element not found.', 'warning');
    voiceCompanion.speak('Target shifted. Recovering and selecting alternative method.', voiceSettings);

    setTimeout(() => {
      addLog('Adaptive Intelligence engaged: Transitioned to Strategy B (Bézier Coordinates).', 'success');
      setStatus('GREEN_RUNNING');
      voiceCompanion.speak('Resuming from verified checkpoint.', voiceSettings);
    }, 1500);
  };

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'floating', label: 'Floating Assistant', icon: Layers },
    { id: 'touch', label: 'Touch Simulator', icon: Sliders },
    { id: 'adaptive', label: 'Adaptive Brain', icon: Cpu },
    { id: 'workflows', label: 'Workflows & Free Fire', icon: Flame },
    { id: 'voice', label: 'Voice Companion', icon: Volume2 },
    { id: 'video', label: 'Video Learning', icon: BookOpen },
    { id: 'performance', label: 'Performance 4GB/8GB', icon: Activity },
    { id: 'apk', label: 'APK Studio', icon: Download },
    { id: 'security', label: 'Security & Audit', icon: ShieldCheck },
  ];

  return (
    <div className="min-h-screen bg-[#070b13] text-slate-100 flex flex-col font-sans">
      {/* Top Application Bar */}
      <Header
        status={status}
        deviceMode={deviceMode}
        onToggleDeviceMode={() => {
          const next = deviceMode === 'lite' ? 'advanced' : 'lite';
          setDeviceMode(next);
          addLog(`Switched profile to: ${next === 'lite' ? '4 GB Lite Mode' : '8 GB Advanced Mode'}`, 'info');
        }}
        voiceSettings={voiceSettings}
        onToggleVoice={() => setVoiceSettings((v) => ({ ...v, voiceEnabled: !v.voiceEnabled }))}
        onToggleCallMute={handleToggleCallMode}
        onEmergencyStop={handleEmergencyStop}
        isOnline={isOnline}
        activeApp={activeApp}
        onToggleMinimize={handleToggleMinimize}
        isAppMinimized={isAppMinimized}
        callMode={callMode}
        onToggleCallMode={handleToggleCallMode}
        onToggleManualQuietMode={handleToggleManualQuietMode}
      />

      {/* Minimized Background Service Notification Banner */}
      {isAppMinimized && (
        <div className="bg-gradient-to-r from-cyan-950 via-slate-900 to-indigo-950 border-b border-cyan-800/80 px-4 py-2.5 shadow-lg">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-2 text-cyan-300">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="font-semibold">AutoPilot Minimized to Background</span>
              <span className="text-slate-400">•</span>
              <span className="text-slate-300">Foreground Service & Movable Floating Indicator Active over Free Fire</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsAppMinimized(false)}
                className="px-3 py-1 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg font-bold text-xs flex items-center gap-1 shadow"
              >
                <Maximize2 className="w-3.5 h-3.5" />
                <span>Restore Main App</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Cooling Cooldown Active Banner (Anti-Overheating Protection) */}
      {status === 'COOLING_PAUSED' && (
        <div className="bg-gradient-to-r from-cyan-950 via-slate-900 to-blue-950 border-b border-cyan-500/80 px-4 py-2.5 shadow-xl animate-pulse">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-2 text-cyan-300">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping"></span>
              <span className="font-bold tracking-wide uppercase text-cyan-200">
                ❄️ GAMEPLAY COOLING COOLDOWN ACTIVE
              </span>
              <span className="text-slate-400">•</span>
              <span className="font-mono bg-cyan-900/60 text-cyan-300 px-2 py-0.5 rounded border border-cyan-700 font-bold">
                {coolingRemainingSeconds}s Remaining
              </span>
              <span className="text-slate-400">•</span>
              <span className="text-slate-300">
                Touch gestures temporarily suspended to dissipate processor and battery heat.
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleSkipCoolingCooldown}
                className="px-3 py-1 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg font-bold text-xs flex items-center gap-1 shadow transition-colors"
                title="Skip cooling pause and resume macro immediately"
              >
                <span>Skip Cooldown &amp; Resume</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Emergency Stop Active Banner */}
      {status === 'RED_EMERGENCY_STOP' && (
        <div className="bg-gradient-to-r from-rose-950 via-slate-900 to-rose-950 border-b border-rose-500/80 px-4 py-2.5 shadow-xl">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-2 text-rose-300">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping"></span>
              <span className="font-bold tracking-wide uppercase text-rose-200">
                🛑 EMERGENCY STOP ACTIVE
              </span>
              <span className="text-slate-400">•</span>
              <span className="text-slate-200">
                All gestures severed. Active task halted. Task history preserved. Control returned 100% to you.
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleTogglePauseResume}
                className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold text-xs flex items-center gap-1 shadow transition-colors"
              >
                <span>Reset &amp; Resume (Safe)</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Responsive Grid Layout */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Interactive Phone Screen Mockup & Overlay HUD (5 Cols on Large) */}
        <div className="lg:col-span-5 flex flex-col items-center">
          <div className="sticky top-20 w-full flex flex-col items-center">
            <PhoneSimulator
              status={status}
              onStatusChange={setStatus}
              floatingState={floatingState}
              onUpdateFloatingState={(update) => setFloatingState((prev) => ({ ...prev, ...update }))}
              currentStep={activePlan?.steps[currentStepIndex]}
              touchSettings={touchSettings}
              activeApp={activeApp}
              onActiveAppChange={setActiveApp}
              onTogglePauseResume={handleTogglePauseResume}
              onEmergencyStop={handleEmergencyStop}
              onReopenApp={() => setIsAppMinimized(false)}
              onCloseAutoPilot={handleCloseAutoPilot}
              onOpenInspector={() => setIsInspectorOpen(true)}
              isAppMinimized={isAppMinimized}
              onToggleMinimize={handleToggleMinimize}
              callMode={callMode}
              onExecuteWrittenCommand={(cmd) => handleExecutePlan(cmd)}
            />
          </div>
        </div>

        {/* Right Column: Tab Navigation & Feature Panels (7 Cols on Large) */}
        <div className="lg:col-span-7 flex flex-col space-y-4">
          {/* Navigation Tab Bar */}
          <nav className="flex items-center gap-1.5 overflow-x-auto pb-1 border-b border-slate-800 scrollbar-none text-xs">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-xl font-medium whitespace-nowrap transition-all ${
                    isActive
                      ? 'bg-cyan-950 text-cyan-300 border border-cyan-700/80 shadow-md shadow-cyan-950/40 font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Tab Content Display */}
          <div className="pt-2">
            {activeTab === 'dashboard' && (
              <DashboardTab
                status={status}
                onStatusChange={setStatus}
                activePlan={activePlan}
                currentStepIndex={currentStepIndex}
                onExecutePlan={handleExecutePlan}
                isPlanning={isPlanning}
                deviceMode={deviceMode}
                voiceSettings={voiceSettings}
                onStartVoiceInput={handleStartVoiceInput}
                isListening={isListening}
                onSimulateErrorRecovery={handleSimulateErrorRecovery}
                callMode={callMode}
                onToggleCallMode={handleToggleCallMode}
              />
            )}

            {activeTab === 'floating' && (
              <FloatingAssistantTab
                status={status}
                onStatusChange={setStatus}
                floatingState={floatingState}
                onUpdateFloatingState={(update) => setFloatingState((prev) => ({ ...prev, ...update }))}
                activePlan={activePlan}
                currentStepIndex={currentStepIndex}
                onToggleMinimize={handleToggleMinimize}
                isAppMinimized={isAppMinimized}
                onTriggerIntelligentResume={handleTogglePauseResume}
                onCloseAutoPilot={handleCloseAutoPilot}
                onOpenInspector={() => setIsInspectorOpen(true)}
              />
            )}

            {activeTab === 'touch' && (
              <HumanTouchTab
                settings={touchSettings}
                onUpdateSettings={(update) => setTouchSettings((prev) => ({ ...prev, ...update }))}
                onResetSettings={() => {
                  setTouchSettings(DEFAULT_TOUCH_SETTINGS);
                  localStorage.setItem(LOCAL_STORAGE_TOUCH_KEY, JSON.stringify(DEFAULT_TOUCH_SETTINGS));
                  addLog('Touch Simulator settings reset to factory defaults.', 'info');
                }}
              />
            )}

            {activeTab === 'adaptive' && (
              <AdaptiveIntelligenceTab
                activePlan={activePlan}
                onUpdatePlan={(updated) => setActivePlan(updated)}
                currentStepIndex={currentStepIndex}
                status={status}
              />
            )}

            {activeTab === 'workflows' && (
              <WorkflowMemoryTab
                workflows={workflows}
                onTriggerWorkflow={(wf) => {
                  setActivePlan({
                    taskName: wf.title,
                    originalCommand: wf.description,
                    summary: wf.description,
                    languageDetected: 'en',
                    intendedResult: wf.description,
                    selectedStrategy: 'Stored Local Rule (100% Offline)',
                    steps: wf.steps,
                    adaptiveStrategies: [
                      {
                        name: 'Stored Local Rule (100% Offline)',
                        reliabilityScore: 98,
                        safetyScore: 99,
                        estimatedTime: '1.8s',
                        timeMs: 1800,
                        batteryImpact: 'very_low',
                        memoryImpactKb: 350,
                        description: 'Dispatched directly from local Room/SQLite database.',
                        tradeoffSummary: 'Zero latency and zero network consumption.',
                        isPermitted: true,
                        isBest: true,
                      },
                    ],
                    restrictionsFollowed: ['Free Fire sandbox strictly maintained'],
                    hardConstraints: [
                      {
                        id: 'hc-wf-1',
                        text: 'Do not close the current application',
                        type: 'hard_constraint',
                        isViolated: false,
                        status: 'enforced',
                        explanation: 'Execution bound to active Free Fire window.',
                      },
                      {
                        id: 'hc-wf-2',
                        text: 'Do not repeat a completed action',
                        type: 'hard_constraint',
                        isViolated: false,
                        status: 'enforced',
                        explanation: 'Macro gestures track execution states.',
                      },
                    ],
                    recoveryHistory: [],
                    userCorrections: [],
                    failedMethodsBlacklist: [],
                    isOfflineRule: true,
                    completionReport: {
                      status: 'success',
                      explanation: `Triggered workflow: ${wf.title}`,
                      language: 'en',
                      completedStepsCount: 0,
                      totalStepsCount: wf.steps.length,
                    },
                  });
                  setCurrentStepIndex(0);
                  setStatus('GREEN_RUNNING');
                  addLog(`Triggered workflow: ${wf.title}`, 'info');
                }}
                onDeleteWorkflow={(id) => setWorkflows((prev) => prev.filter((w) => w.id !== id))}
              />
            )}

            {activeTab === 'voice' && (
              <VoiceCompanionTab
                settings={voiceSettings}
                onUpdateSettings={(update) => setVoiceSettings((prev) => ({ ...prev, ...update }))}
                onTestPhrase={(phrase, isHindi) => voiceCompanion.speak(phrase, voiceSettings, isHindi ? 'hi' : 'en')}
                onSimulateIncomingCall={handleToggleCallMode}
                callMode={callMode}
                onToggleCallMode={handleToggleCallMode}
                onToggleManualQuietMode={handleToggleManualQuietMode}
                onExecuteWrittenCommand={(cmd) => handleExecutePlan(cmd)}
              />
            )}

            {activeTab === 'video' && (
              <VideoLearningTab
                onSaveNewWorkflow={(wf) => setWorkflows((prev) => [wf, ...prev])}
              />
            )}

            {activeTab === 'performance' && (
              <PerformanceTab
                settings={performanceSettings}
                onUpdateSettings={(newSettings) => setPerformanceSettings((prev) => ({ ...prev, ...newSettings }))}
                metrics={performanceMetrics}
                recommendation={deviceRecommendation}
                onApplyRecommendation={(rec) => setPerformanceSettings(rec.recommendedMode === 'lite' ? LITE_MODE_DEFAULTS : ADVANCED_MODE_DEFAULTS)}
                onResetDefaults={(mode) => setPerformanceSettings(mode === 'lite' ? LITE_MODE_DEFAULTS : ADVANCED_MODE_DEFAULTS)}
                isExecuting={status === 'GREEN_RUNNING'}
              />
            )}

            {activeTab === 'apk' && <ApkStudioTab />}

            {activeTab === 'security' && (
              <SecurityAuditTab
                logs={logs}
                onClearLogs={() => setLogs([])}
                onEmergencyStop={handleEmergencyStop}
                status={status}
                onRequestSensitiveActionTest={handleTriggerSensitiveActionTest}
                activeApp={activeApp}
              />
            )}
          </div>
        </div>
      </main>
      {/* Intelligent State Recovery & Resume Inspector Modal */}
      <IntelligentResumeModal
        isOpen={isInspectorOpen}
        onClose={() => setIsInspectorOpen(false)}
        inspection={inspectionState}
        onResumeConfirm={() => {
          setIsInspectorOpen(false);
          if (status !== 'GREEN_RUNNING') {
            handleTogglePauseResume();
          }
        }}
      />
      {/* Important Action Confirmation Modal (Safety Manager) */}
      <ImportantActionConfirmationModal
        isOpen={!!pendingSensitiveAction}
        request={pendingSensitiveAction}
        onApprove={handleApproveSensitiveAction}
        onReject={handleRejectSensitiveAction}
      />
    </div>
  );
}
