export interface AndroidFileRecord {
  path: string;
  name: string;
  language: string;
  category: 'manifest' | 'kotlin' | 'gradle' | 'res' | 'workflow';
  description: string;
  content: string;
}

export const ANDROID_PROJECT_FILES: AndroidFileRecord[] = [
  {
    path: '.github/workflows/build-apk.yml',
    name: 'build-apk.yml',
    language: 'yaml',
    category: 'workflow',
    description: 'Cloud Build pipeline that compiles the genuine Android APK in 3 minutes via GitHub Actions without requiring a PC.',
    content: `name: Build AI AutoPilot Android APK

on:
  push:
    branches: [ main, master ]
  pull_request:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    name: Build Debug APK
    runs-on: ubuntu-latest

    steps:
      - name: Checkout Code
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: 'zulu'
          java-version: '17'
          cache: 'gradle'

      - name: Grant Execute Permission to Gradlew
        run: |
          if [ -d "android-project" ]; then
            cd android-project
          fi
          chmod +x gradlew || true

      - name: Build Debug APK with Gradle
        run: |
          if [ -d "android-project" ]; then
            cd android-project
            ./gradlew assembleDebug --stacktrace || gradle assembleDebug
          else
            ./gradlew assembleDebug --stacktrace || gradle assembleDebug
          fi

      - name: Locate Generated APK
        id: find_apk
        run: |
          APK_PATH=$(find . -name "*.apk" | head -n 1)
          echo "Found APK at: $APK_PATH"
          echo "apk_path=$APK_PATH" >> $GITHUB_OUTPUT

      - name: Upload APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: AI-AutoPilot-Debug-APK
          path: \${{ steps.find_apk.outputs.apk_path }}
          retention-days: 14`
  },
  {
    path: 'app/src/main/AndroidManifest.xml',
    name: 'AndroidManifest.xml',
    language: 'xml',
    category: 'manifest',
    description: 'Declares overlay permissions, foreground services, accessibility service, voice recording, and phone call state receiver.',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">

    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.READ_PHONE_STATE" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="AI AutoPilot"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.AIAutoPilot">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:theme="@style/Theme.AIAutoPilot"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <service
            android:name=".service.AutoPilotAccessibilityService"
            android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE"
            android:exported="true">
            <intent-filter>
                <action android:name="android.accessibilityservice.AccessibilityService" />
            </intent-filter>
            <meta-data
                android:name="android.accessibilityservice"
                android:resource="@xml/accessibility_service_config" />
        </service>

        <service
            android:name=".service.FloatingAssistantOverlayService"
            android:enabled="true"
            android:exported="false"
            android:foregroundServiceType="specialUse">
            <property
                android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE"
                android:value="Floating assistant overlay control for hands-free task automation" />
        </service>

        <receiver
            android:name=".receiver.PhoneCallStateReceiver"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.PHONE_STATE" />
            </intent-filter>
        </receiver>

    </application>
</manifest>`
  },
  {
    path: 'app/src/main/java/com/aiautopilot/assistant/MainActivity.kt',
    name: 'MainActivity.kt',
    language: 'kotlin',
    category: 'kotlin',
    description: 'Jetpack Compose native UI: dashboard, touch settings, Free Fire pro macros, voice command input, and log viewer.',
    content: `package com.aiautopilot.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.aiautopilot.assistant.data.AppDatabase
import com.aiautopilot.assistant.engine.AdaptiveTaskPlanner
import com.aiautopilot.assistant.engine.HumanTouchSimulator
import com.aiautopilot.assistant.engine.VoiceCompanionEngine
import com.aiautopilot.assistant.service.AutoPilotAccessibilityService
import com.aiautopilot.assistant.service.FloatingAssistantOverlayService

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        VoiceCompanionEngine.init(this)
        // Composable MainScreen...
    }
}`
  },
  {
    path: 'app/src/main/java/com/aiautopilot/assistant/service/AutoPilotAccessibilityService.kt',
    name: 'AutoPilotAccessibilityService.kt',
    language: 'kotlin',
    category: 'kotlin',
    description: 'Executes actual taps, swipes, text typing, screen node traversal, and sequential workflow execution.',
    content: `package com.aiautopilot.assistant.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.aiautopilot.assistant.data.AppDatabase
import com.aiautopilot.assistant.engine.AdaptiveTaskPlanner
import com.aiautopilot.assistant.engine.HumanTouchSimulator
import kotlinx.coroutines.*
import java.util.concurrent.atomic.AtomicBoolean

class AutoPilotAccessibilityService : AccessibilityService() {
    companion object {
        var instance: AutoPilotAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { triggerEmergencyStop() }
}`
  },
  {
    path: 'app/src/main/java/com/aiautopilot/assistant/service/FloatingAssistantOverlayService.kt',
    name: 'FloatingAssistantOverlayService.kt',
    language: 'kotlin',
    category: 'kotlin',
    description: 'Displays movable floating bubble on top of other apps (GREEN=Running, ORANGE=Paused, RED=Emergency Stop).',
    content: `package com.aiautopilot.assistant.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.FrameLayout
import androidx.core.app.NotificationCompat
import com.aiautopilot.assistant.MainActivity
import com.aiautopilot.assistant.engine.VoiceCompanionEngine

class FloatingAssistantOverlayService : Service() {
    enum class AssistantState { RUNNING_GREEN, PAUSED_ORANGE, STOPPED_RED }
    // Handles overlay lifecycle, drag touch, and notifications...
}`
  },
  {
    path: 'app/src/main/java/com/aiautopilot/assistant/data/TouchSettingsStore.kt',
    name: 'TouchSettingsStore.kt',
    language: 'kotlin',
    category: 'kotlin',
    description: 'Android SharedPreferences persistence manager for custom reaction presets, Bézier curve choices, and gaming restrictions.',
    content: `package com.aiautopilot.assistant.data

import android.content.Context
import android.content.SharedPreferences
import com.aiautopilot.assistant.engine.HumanTouchSimulator

class TouchSettingsStore(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("autopilot_touch_settings_prefs", Context.MODE_PRIVATE)

    fun loadSettings() {
        val presetName = prefs.getString("preset_id", HumanTouchSimulator.ReactionPreset.FASTEST.name) ?: HumanTouchSimulator.ReactionPreset.FASTEST.name
        HumanTouchSimulator.activePreset = try { HumanTouchSimulator.ReactionPreset.valueOf(presetName) } catch (e: Exception) { HumanTouchSimulator.ReactionPreset.FASTEST }
        HumanTouchSimulator.customDelayMs = prefs.getLong("custom_delay_ms", 100L)
        HumanTouchSimulator.tapHoldDurationMs = prefs.getLong("tap_hold_ms", 70L)
        HumanTouchSimulator.swipeDurationMs = prefs.getLong("swipe_duration_ms", 130L)
        HumanTouchSimulator.timingVariationPct = prefs.getInt("timing_variation_pct", 12)
        HumanTouchSimulator.boundaryClampingEnabled = prefs.getBoolean("boundary_clamping_enabled", true)
        HumanTouchSimulator.gamingOnlyRestriction = prefs.getBoolean("gaming_only_restriction", true)
    }

    fun saveSettings() {
        prefs.edit().apply {
            putString("preset_id", HumanTouchSimulator.activePreset.name)
            putLong("custom_delay_ms", HumanTouchSimulator.customDelayMs)
            putLong("tap_hold_ms", HumanTouchSimulator.tapHoldDurationMs)
            putLong("swipe_duration_ms", HumanTouchSimulator.swipeDurationMs)
            putInt("timing_variation_pct", HumanTouchSimulator.timingVariationPct)
            putBoolean("boundary_clamping_enabled", HumanTouchSimulator.boundaryClampingEnabled)
            putBoolean("gaming_only_restriction", HumanTouchSimulator.gamingOnlyRestriction)
            apply()
        }
    }
}`
  },
  {
    path: 'app/src/main/java/com/aiautopilot/assistant/engine/HumanTouchSimulator.kt',
    name: 'HumanTouchSimulator.kt',
    language: 'kotlin',
    category: 'kotlin',
    description: 'Human touch engine with 8 presets (100ms - 2000ms), J-curve drag headshot, target boundary clamping, and gaming restriction.',
    content: `package com.aiautopilot.assistant.engine

import android.graphics.Path
import android.graphics.RectF
import kotlin.random.Random

object HumanTouchSimulator {
    enum class ReactionPreset(val baseDelayMs: Long, val label: String) {
        FASTEST(100L, "Fastest (100ms)"),
        VERY_FAST(200L, "Very Fast (200ms)"),
        FAST(350L, "Fast (350ms)"),
        NORMAL(600L, "Normal (600ms)"),
        RELAXED(900L, "Relaxed (900ms)"),
        SLOW(1400L, "Slow (1400ms)"),
        VERY_SLOW(2000L, "Very Slow (2000ms)"),
        CUSTOM(350L, "Custom (50–3000ms)")
    }

    enum class DragCurveShape { J_CURVE, STRAIGHT_UP, ROTATION_CURVE }

    var activePreset: ReactionPreset = ReactionPreset.FASTEST
    var customDelayMs: Long = 100L
    var tapHoldDurationMs: Long = 70L
    var tapPreDelayMs: Long = 50L
    var swipeDurationMs: Long = 130L
    var swipeDistancePx: Float = 320f
    var swipeCurveCurvature: Float = 0.35f
    var activeDragShape: DragCurveShape = DragCurveShape.J_CURVE
    var naturalPauseMinMs: Long = 80L
    var naturalPauseMaxMs: Long = 250L
    var timingVariationPct: Int = 12
    var typingIntervalMs: Long = 50L
    var boundaryClampingEnabled: Boolean = true
    var targetPaddingPx: Float = 8f
    var jitterEnabled: Boolean = true
    var maxJitterPixels: Float = 5.0f
    var gamingOnlyRestriction: Boolean = true

    fun isAllowedGamingPackage(packageName: String): Boolean {
        if (!gamingOnlyRestriction) return true
        val lower = packageName.lowercase()
        return lower.contains("freefire") || lower.contains("game") || lower.contains("browser") || lower.contains("chrome")
    }

    fun calculateJitter(x: Float, y: Float, targetBounds: RectF? = null): Pair<Float, Float> {
        var jX = if (jitterEnabled) x + (Random.nextFloat() * 2f - 1f) * maxJitterPixels else x
        var jY = if (jitterEnabled) y + (Random.nextFloat() * 2f - 1f) * maxJitterPixels else y
        if (boundaryClampingEnabled && targetBounds != null) {
            jX = jX.coerceIn(targetBounds.left + targetPaddingPx, targetBounds.right - targetPaddingPx)
            jY = jY.coerceIn(targetBounds.top + targetPaddingPx, targetBounds.bottom - targetPaddingPx)
        }
        return Pair(jX, jY)
    }

    fun getNaturalPauseMs(): Long = Random.nextLong(naturalPauseMinMs.coerceAtLeast(40L), naturalPauseMaxMs.coerceAtLeast(90L) + 1)

    fun applyTimingVariation(baseMs: Long): Long {
        if (timingVariationPct <= 0) return baseMs
        val span = (baseMs * (timingVariationPct / 100f)).toLong()
        return (baseMs + Random.nextLong(-span, span + 1)).coerceAtLeast(20L)
    }

    fun generateCurvedPath(startX: Float, startY: Float, endX: Float, endY: Float): Path {
        val path = Path()
        val p1 = calculateJitter(startX, startY)
        val p2 = calculateJitter(endX, endY)
        path.moveTo(p1.first, p1.second)
        val midX = (p1.first + p2.first) / 2f
        val midY = (p1.second + p2.second) / 2f
        val offset = swipeCurveCurvature * 50f
        val ctrlX = if (activeDragShape == DragCurveShape.J_CURVE) midX + offset * 0.8f else midX + offset * 0.2f
        val ctrlY = if (activeDragShape == DragCurveShape.J_CURVE) midY + offset * 0.4f else midY
        path.quadTo(ctrlX, ctrlY, p2.first, p2.second)
        return path
    }
}`
  },
  {
    path: 'app/src/main/java/com/aiautopilot/assistant/engine/AdaptiveTaskPlanner.kt',
    name: 'AdaptiveTaskPlanner.kt',
    language: 'kotlin',
    category: 'kotlin',
    description: '10-Step AI Task Process engine: evaluates time/battery/memory/reliability, enforces hard constraints, screen drift recovery.',
    content: `package com.aiautopilot.assistant.engine

class AdaptiveTaskPlanner {
    enum class ProcessStage {
        UNDERSTAND_COMMAND, IDENTIFY_INTENT, CHECK_RESTRICTIONS,
        PLAN_STEPS, EVALUATE_METHODS, SELECT_SAFEST_METHOD,
        EXECUTE_STEP, VERIFY_RESULT, RECOVER_OR_REPLAN, REPORT_RESULT
    }
    // 10-step process, multi-factor scoring, screen drift recovery, user corrections...
}`
  },
  {
    path: 'app/src/main/java/com/aiautopilot/assistant/engine/VoiceCompanionEngine.kt',
    name: 'VoiceCompanionEngine.kt',
    language: 'kotlin',
    category: 'kotlin',
    description: 'Dual voice engine: TTS in Hindi/English with Fast Talk mode, and Android SpeechRecognizer for hands-free commands.',
    content: `package com.aiautopilot.assistant.engine

import android.content.Context
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

object VoiceCompanionEngine : TextToSpeech.OnInitListener {
    // TTS + SpeechRecognizer implementation with call mode mute...
}`
  },
  {
    path: 'app/src/main/java/com/aiautopilot/assistant/engine/CallModeManager.kt',
    name: 'CallModeManager.kt',
    language: 'kotlin',
    category: 'kotlin',
    description: 'Automatic Call Mode: detects phone calls via TelephonyCallback / PhoneStateListener, auto-mutes speech, switches to written command mode, preserves tasks, restores voice upon hangup.',
    content: `package com.aiautopilot.assistant.engine

import android.content.Context
import android.os.Build
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager

object CallModeManager {
    var isCallActive: Boolean = false
        private set
    var isManualQuietMode: Boolean = false
        private set

    fun init(context: Context) { /* TelephonyManager listener setup */ }
    fun handleCallState(state: Int) {
        when (state) {
            TelephonyManager.CALL_STATE_RINGING,
            TelephonyManager.CALL_STATE_OFFHOOK -> {
                isCallActive = true
                VoiceCompanionEngine.setCallActive(true)
            }
            TelephonyManager.CALL_STATE_IDLE -> {
                isCallActive = false
                if (!isManualQuietMode) VoiceCompanionEngine.setCallActive(false)
            }
        }
    }
    fun setManualQuietMode(enabled: Boolean) {
        isManualQuietMode = enabled
        VoiceCompanionEngine.setQuietMode(enabled)
    }
}`
  },
  {
    path: 'app/src/main/java/com/aiautopilot/assistant/receiver/PhoneCallStateReceiver.kt',
    name: 'PhoneCallStateReceiver.kt',
    language: 'kotlin',
    category: 'kotlin',
    description: 'BroadcastReceiver listening to ACTION_PHONE_STATE to trigger Automatic Call Mode.',
    content: `package com.aiautopilot.assistant.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager
import com.aiautopilot.assistant.engine.CallModeManager

class PhoneCallStateReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent?.action == TelephonyManager.ACTION_PHONE_STATE_CHANGED) {
            val stateStr = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
            when (stateStr) {
                TelephonyManager.EXTRA_STATE_RINGING -> CallModeManager.handleCallState(TelephonyManager.CALL_STATE_RINGING)
                TelephonyManager.EXTRA_STATE_OFFHOOK -> CallModeManager.handleCallState(TelephonyManager.CALL_STATE_OFFHOOK)
                TelephonyManager.EXTRA_STATE_IDLE -> CallModeManager.handleCallState(TelephonyManager.CALL_STATE_IDLE)
            }
        }
    }
}`
  },
  {
    path: 'app/src/main/java/com/aiautopilot/assistant/data/AppDatabase.kt',
    name: 'AppDatabase.kt',
    language: 'kotlin',
    category: 'kotlin',
    description: 'Native SQLite local database for offline workflows, Free Fire macros, and task history logs.',
    content: `package com.aiautopilot.assistant.data

import android.content.Context
import android.database.sqlite.SQLiteOpenHelper
import com.aiautopilot.assistant.data.dao.TaskLogDao
import com.aiautopilot.assistant.data.dao.WorkflowDao

class AppDatabase private constructor(context: Context) : SQLiteOpenHelper(context, "ai_autopilot_database.db", null, 1) {
    // Thread-safe DAOs and database queries...
}`
  },
  {
    path: 'app/src/main/res/values/themes.xml',
    name: 'themes.xml',
    language: 'xml',
    category: 'res',
    description: 'Material theme definition for Theme.AIAutoPilot.',
    content: `<resources>
    <style name="Theme.AIAutoPilot" parent="android:Theme.Material.NoActionBar">
        <item name="android:statusBarColor">#090D16</item>
        <item name="android:navigationBarColor">#090D16</item>
        <item name="android:windowBackground">#090D16</item>
    </style>
</resources>`
  },
  {
    path: 'app/build.gradle.kts',
    name: 'app/build.gradle.kts',
    language: 'groovy',
    category: 'gradle',
    description: 'Gradle configuration for Android 8.0+ (API 26 to 34), Compose UI, and Coroutines.',
    content: `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.aiautopilot.assistant"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.aiautopilot.assistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}`
  },
  {
    path: 'app/src/main/java/com/aiautopilot/assistant/engine/AdaptivePerformanceManager.kt',
    name: 'AdaptivePerformanceManager.kt',
    language: 'kotlin',
    category: 'kotlin',
    description: 'Hardware regulator managing 4GB Lite vs 8GB Advanced RAM allocation, PowerManager thermal listeners, and event-driven screen accessibility.',
    content: `package com.aiautopilot.assistant.engine

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.PowerManager
import androidx.annotation.RequiresApi

object AdaptivePerformanceManager {
    enum class DeviceProfile { LITE_4GB, ADVANCED_8GB }

    var activeProfile: DeviceProfile = DeviceProfile.LITE_4GB
    var singleTaskOnly: Boolean = true
    var avoidContinuousCapture: Boolean = true
    var eventDrivenProcessing: Boolean = true
    var cooldownPeriodsEnabled: Boolean = true
    var cooldownDurationMs: Long = 900L
    var pollingIntervalMs: Long = 1600L
    var mobileDataCompressionEnabled: Boolean = true
    var offlineExecutionPreferred: Boolean = true

    // Thermal state monitoring (Android 10 / API 29+)
    @RequiresApi(Build.VERSION_CODES.Q)
    fun registerThermalListener(context: Context, onThermalWarning: (Int) -> Unit) {
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        powerManager?.addThermalStatusListener { status ->
            when (status) {
                PowerManager.THERMAL_STATUS_MODERATE,
                PowerManager.THERMAL_STATUS_SEVERE -> {
                    // Automatically engage extra cooldown breather delay during hot Free Fire matches
                    cooldownPeriodsEnabled = true
                    cooldownDurationMs = 1200L
                    pollingIntervalMs = 2400L
                    onThermalWarning(status)
                }
            }
        }
    }

    fun recommendProfile(context: Context): DeviceProfile {
        val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        actManager?.getMemoryInfo(memInfo)
        val totalRamGb = memInfo.totalMem / (1024 * 1024 * 1024)
        activeProfile = if (totalRamGb <= 4) DeviceProfile.LITE_4GB else DeviceProfile.ADVANCED_8GB
        return activeProfile
    }
}`
  }
];
