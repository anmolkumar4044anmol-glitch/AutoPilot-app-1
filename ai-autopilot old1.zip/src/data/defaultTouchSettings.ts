import { TouchSettings, ReactionPreset, GestureProfileId } from '../types/autopilot';

export const REACTION_PRESETS: ReactionPreset[] = [
  { id: 'fastest', label: '1. Fastest (100 ms)', delayMs: 100, description: 'Reflex level for instant competitive actions like Gloo Wall & quick scope.' },
  { id: 'very_fast', label: '2. Very Fast (200 ms)', delayMs: 200, description: 'High-speed esport player response for fast drag headshot sweeps.' },
  { id: 'fast', label: '3. Fast (350 ms)', delayMs: 350, description: 'Attentive player reaction for swift inventory looting & target acquisition.' },
  { id: 'normal', label: '4. Normal (600 ms)', delayMs: 600, description: 'Default comfortable human interaction for general UI and menus.' },
  { id: 'relaxed', label: '5. Relaxed (900 ms)', delayMs: 900, description: 'Casual navigation pacing for map scanning and relaxed gameplay.' },
  { id: 'slow', label: '6. Slow (1400 ms)', delayMs: 1400, description: 'Methodical reading pace for weapon stats and safe adjustments.' },
  { id: 'very_slow', label: '7. Very Slow (2000 ms)', delayMs: 2000, description: 'High-safety deliberate execution for sensitive sensitivity calibration.' },
  { id: 'custom', label: '8. Custom (50–3000 ms)', delayMs: 350, description: 'User-specified exact delay parameter customized to your device touch screen.' },
];

export interface GestureProfileDefinition {
  id: GestureProfileId;
  name: string;
  badge: string;
  description: string;
  settings: Partial<TouchSettings>;
}

export const GESTURE_PROFILES: GestureProfileDefinition[] = [
  {
    id: 'free_fire_gloo',
    name: 'Free Fire Instant Gloo Wall',
    badge: 'Pro Esports',
    description: '100ms reflex speed, crouch-deploy sequence, ±4px safe landing variance, straight drag curve.',
    settings: {
      preset: 'fastest',
      customDelayMs: 100,
      tapHoldDurationMs: 65,
      tapPreDelayMs: 40,
      swipeDurationMs: 110,
      swipeDistancePx: 260,
      swipeCurveCurvature: 0.2,
      freeFireDragCurveShape: 'straight_up',
      naturalPauseMinMs: 60,
      naturalPauseMaxMs: 150,
      timingVariationPct: 8,
      boundaryClampingEnabled: true,
      targetPaddingPx: 6,
      jitterEnabled: true,
      jitterRadiusPx: 4,
      freeFireProTuning: true,
    },
  },
  {
    id: 'free_fire_headshot',
    name: 'Free Fire Drag Headshot J-Curve',
    badge: 'Aim Precision',
    description: '180ms reaction with calibrated J-curve thumb sweep for upward drag aim stabilization.',
    settings: {
      preset: 'very_fast',
      customDelayMs: 180,
      tapHoldDurationMs: 90,
      tapPreDelayMs: 60,
      swipeDurationMs: 140,
      swipeDistancePx: 380,
      swipeCurveCurvature: 0.45,
      freeFireDragCurveShape: 'j_curve',
      naturalPauseMinMs: 90,
      naturalPauseMaxMs: 220,
      timingVariationPct: 10,
      boundaryClampingEnabled: true,
      targetPaddingPx: 8,
      jitterEnabled: true,
      jitterRadiusPx: 5,
      freeFireProTuning: true,
    },
  },
  {
    id: 'free_fire_quick_scope',
    name: 'Free Fire Sniper Quick Switch',
    badge: 'Sniper Pro',
    description: '140ms fire button to secondary weapon switch combo with minimal aim disruption.',
    settings: {
      preset: 'very_fast',
      customDelayMs: 140,
      tapHoldDurationMs: 55,
      tapPreDelayMs: 50,
      swipeDurationMs: 120,
      swipeDistancePx: 180,
      swipeCurveCurvature: 0.15,
      freeFireDragCurveShape: 'straight_up',
      naturalPauseMinMs: 70,
      naturalPauseMaxMs: 160,
      timingVariationPct: 7,
      boundaryClampingEnabled: true,
      targetPaddingPx: 6,
      jitterEnabled: true,
      jitterRadiusPx: 4,
      freeFireProTuning: true,
    },
  },
  {
    id: 'casual_gaming',
    name: 'Casual Gaming & Web Play',
    badge: 'Balanced',
    description: 'Comfortable 600ms pacing with natural 15% timing variation for browser and casual arcade games.',
    settings: {
      preset: 'normal',
      customDelayMs: 600,
      tapHoldDurationMs: 110,
      tapPreDelayMs: 120,
      swipeDurationMs: 280,
      swipeDistancePx: 320,
      swipeCurveCurvature: 0.3,
      freeFireDragCurveShape: 'straight_up',
      scrollSpeedMs: 350,
      scrollStepPx: 420,
      naturalPauseMinMs: 150,
      naturalPauseMaxMs: 450,
      timingVariationPct: 15,
      typingIntervalMs: 65,
      boundaryClampingEnabled: true,
      targetPaddingPx: 8,
      jitterEnabled: true,
      jitterRadiusPx: 7,
      freeFireProTuning: false,
    },
  },
  {
    id: 'precision',
    name: 'Precision Navigator & Setup',
    badge: 'High Safety',
    description: 'Deliberate 900ms reaction with strict boundary clamping and larger touch contact.',
    settings: {
      preset: 'relaxed',
      customDelayMs: 900,
      tapHoldDurationMs: 160,
      tapPreDelayMs: 200,
      swipeDurationMs: 400,
      swipeDistancePx: 280,
      swipeCurveCurvature: 0.25,
      freeFireDragCurveShape: 'straight_up',
      scrollSpeedMs: 480,
      scrollStepPx: 360,
      naturalPauseMinMs: 220,
      naturalPauseMaxMs: 600,
      timingVariationPct: 12,
      typingIntervalMs: 85,
      boundaryClampingEnabled: true,
      targetPaddingPx: 12,
      jitterEnabled: true,
      jitterRadiusPx: 4,
      freeFireProTuning: false,
    },
  },
];

export const DEFAULT_TOUCH_SETTINGS: TouchSettings = {
  preset: 'fastest',
  customDelayMs: 100,
  tapHoldDurationMs: 70,
  tapPreDelayMs: 50,
  swipeDurationMs: 130,
  swipeDistancePx: 320,
  swipeCurveCurvature: 0.35,
  freeFireDragCurveShape: 'j_curve',
  scrollSpeedMs: 300,
  scrollStepPx: 420,
  scrollSmoothness: 3,
  naturalPauseMinMs: 80,
  naturalPauseMaxMs: 250,
  timingVariationPct: 12,
  typingIntervalMs: 50,
  typingJitterMs: 10,
  boundaryClampingEnabled: true,
  targetPaddingPx: 8,
  jitterEnabled: true,
  jitterRadiusPx: 5,
  appliedScopes: {
    tap: true,
    swipe: true,
    scroll: true,
    type: true,
    workflows: true,
    allActions: true,
  },
  activeProfile: 'free_fire_gloo',
  perTaskSettings: {
    'gloo_wall': { preset: 'fastest', delayMs: 100, jitterPx: 4, description: 'Instant Gloo Wall Defense' },
    'drag_headshot': { preset: 'very_fast', delayMs: 180, jitterPx: 5, description: 'Drag Headshot J-Curve' },
    'quick_scope': { preset: 'very_fast', delayMs: 140, jitterPx: 3, description: 'Sniper Scope-Fire Switch' },
    'loot_crate': { preset: 'fast', delayMs: 350, jitterPx: 6, description: 'Fast Inventory & Death Crate Looting' },
    'in_game_menu': { preset: 'normal', delayMs: 600, jitterPx: 6, description: 'Settings & Weapon Customization' },
  },
  gamingOnlyRestriction: true,
  allowedGamingPackages: [
    'com.dts.freefireth',
    'com.dts.freefiremax',
    'com.dts.freefirein',
    'com.android.chrome',
    'org.mozilla.firefox',
    'com.brave.browser',
    'com.google.android.browser',
  ],
  freeFireProTuning: true,
  humanizedDelayEnabled: true,
  humanizedDelayJitterMs: 50,
  humanizedDelayDistribution: 'organic_gaussian',
};

export function calculateHumanizedDelay(baseDelayMs: number, settings: TouchSettings): { actualDelayMs: number; jitterMs: number } {
  if (!settings.humanizedDelayEnabled || settings.humanizedDelayJitterMs <= 0) {
    return { actualDelayMs: baseDelayMs, jitterMs: 0 };
  }

  const maxJitter = settings.humanizedDelayJitterMs; // e.g. 50ms for ±50ms
  let jitter = 0;

  if (settings.humanizedDelayDistribution === 'organic_gaussian') {
    // Box-Muller transform for organic biological thumb tap distribution (bell curve)
    const u1 = Math.max(0.0001, Math.random());
    const u2 = Math.random();
    const randStdNormal = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
    // Standard deviation scaled so ~99% falls within ±maxJitter
    jitter = Math.round(randStdNormal * (maxJitter / 2.5));
    jitter = Math.max(-maxJitter, Math.min(maxJitter, jitter));
  } else {
    // Uniform linear range
    jitter = Math.round((Math.random() * 2 - 1) * maxJitter);
  }

  const actualDelayMs = Math.max(25, baseDelayMs + jitter);
  return { actualDelayMs, jitterMs: jitter };
}

export const LOCAL_STORAGE_TOUCH_KEY = 'ai_autopilot_touch_settings_v3';
