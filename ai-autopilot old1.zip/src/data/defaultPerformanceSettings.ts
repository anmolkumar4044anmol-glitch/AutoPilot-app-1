import { AdaptivePerformanceSettings, DeviceRecommendation, PerformanceMetrics, DeviceMode } from '../types/autopilot';

export const LOCAL_STORAGE_PERFORMANCE_KEY = 'ai_autopilot_perf_settings_v2';

export const LITE_MODE_DEFAULTS: AdaptivePerformanceSettings = {
  mode: 'lite',
  autoRecommendationEnabled: true,

  // LITE MODE — 4 GB RAM
  singleTaskOnly: true,
  minimalBackgroundProcessing: true,
  reducedScreenshotFrequency: true, // 0.5 FPS
  smallerAiRequests: true,
  limitedWorkflowCache: true, // 5 cached routines
  minimalAnimations: true,
  aggressiveIdleReduction: true,

  // ADVANCED MODE (disabled in Lite)
  detailedTaskAnalysis: false,
  expandedWorkflowCache: false,
  advancedVisualVerification: false,
  complexTaskPlanning: false,
  controlledParallelProcessing: false,

  // BATTERY SAVING
  batterySaverEnabled: true,
  reducedPolling: true,
  pollingIntervalMs: 1600,
  avoidContinuousCapture: true,
  reducedBackgroundCpu: true,
  eventDrivenProcessing: true,
  cooldownPeriodsEnabled: true,
  cooldownDurationMs: 900,
  stopExpensiveAnalysisWhenIdle: true,

  // NETWORK & MOBILE DATA
  mobileDataOptimizer: true,
  compressPayloads: true,
  avoidVideoDownloads: true,
  intelligentRetry: true,
  offlineExecutionPreferred: true,

  // CUSTOM GAMEPLAY COOLING COOLDOWNS (Anti-Overheating)
  periodicCoolingEnabled: true,
  coolingIntervalMinutes: 10,
  coolingPauseDurationSec: 8,
};

export const ADVANCED_MODE_DEFAULTS: AdaptivePerformanceSettings = {
  mode: 'advanced',
  autoRecommendationEnabled: false,

  // LITE MODE (relaxed for 8 GB RAM)
  singleTaskOnly: false,
  minimalBackgroundProcessing: false,
  reducedScreenshotFrequency: false, // 2.5 FPS
  smallerAiRequests: false,
  limitedWorkflowCache: false,
  minimalAnimations: false,
  aggressiveIdleReduction: false,

  // ADVANCED MODE — 8 GB RAM
  detailedTaskAnalysis: true,
  expandedWorkflowCache: true, // 50 cached routines
  advancedVisualVerification: true,
  complexTaskPlanning: true,
  controlledParallelProcessing: true,

  // BATTERY SAVING
  batterySaverEnabled: false,
  reducedPolling: false,
  pollingIntervalMs: 600,
  avoidContinuousCapture: false,
  reducedBackgroundCpu: false,
  eventDrivenProcessing: true,
  cooldownPeriodsEnabled: false,
  cooldownDurationMs: 400,
  stopExpensiveAnalysisWhenIdle: true,

  // NETWORK & MOBILE DATA
  mobileDataOptimizer: true,
  compressPayloads: true,
  avoidVideoDownloads: true,
  intelligentRetry: true,
  offlineExecutionPreferred: false,

  // CUSTOM GAMEPLAY COOLING COOLDOWNS (Anti-Overheating)
  periodicCoolingEnabled: true,
  coolingIntervalMinutes: 15,
  coolingPauseDurationSec: 6,
};

export const DEFAULT_PERFORMANCE_SETTINGS: AdaptivePerformanceSettings = LITE_MODE_DEFAULTS;

/**
 * Inspects host device characteristics (Memory API, Hardware Concurrency, Network API, Battery)
 * and generates an intelligent recommendation between Lite Mode (4GB) and Advanced Mode (8GB).
 */
export function detectDeviceRecommendation(): DeviceRecommendation {
  let detectedMemoryGb = 4;
  let detectedCores = 4;
  let networkType: DeviceRecommendation['networkType'] = 'mobile_4g';
  const reasons: string[] = [];

  // 1. Device Memory API (Supported in Chrome / Android WebViews)
  if (typeof navigator !== 'undefined') {
    if ('deviceMemory' in navigator && typeof (navigator as any).deviceMemory === 'number') {
      detectedMemoryGb = (navigator as any).deviceMemory;
    }

    if (navigator.hardwareConcurrency) {
      detectedCores = navigator.hardwareConcurrency;
    }

    // 2. Network Information API
    if ('connection' in navigator && (navigator as any).connection) {
      const conn = (navigator as any).connection;
      if (conn.saveData) {
        networkType = 'metered';
        reasons.push('User Data Saver is active on device');
      } else if (conn.effectiveType === '4g') {
        networkType = 'mobile_4g';
      } else if (conn.effectiveType === '5g') {
        networkType = 'mobile_5g';
      } else if (conn.type === 'wifi') {
        networkType = 'wifi';
      }
    }
  }

  // Recommendation Decision Logic
  let recommendedMode: DeviceMode = 'lite';

  if (detectedMemoryGb <= 4 || detectedCores <= 4) {
    recommendedMode = 'lite';
    reasons.push(`Device memory detected at ~${detectedMemoryGb} GB RAM (${detectedCores} CPU cores).`);
    reasons.push('Lite Mode recommended to eliminate Free Fire background memory contention and prevent low-memory kills.');
  } else {
    recommendedMode = 'advanced';
    reasons.push(`Device has ~${detectedMemoryGb} GB RAM available with ${detectedCores} high-performance cores.`);
    reasons.push('Advanced Mode selected for multi-path reasoning and high-fidelity Bézier trajectory generation.');
  }

  if (networkType === 'mobile_4g' || networkType === 'metered') {
    reasons.push('Mobile cellular data in use: payload compression and video download suppression recommended.');
  }

  return {
    recommendedMode,
    detectedMemoryGb,
    detectedCores,
    batteryLevelPct: 82, // Standard mobile baseline simulation
    isCharging: false,
    networkType,
    reasons,
    autoApplied: true,
  };
}

/**
 * Calculates real-time system metrics reflecting active performance settings,
 * load states, and physical thermal realities.
 */
export function calculateLivePerformanceMetrics(
  settings: AdaptivePerformanceSettings,
  isExecuting: boolean,
  isIdle: boolean,
  activeTasksCount: number
): PerformanceMetrics {
  const isLite = settings.mode === 'lite';

  // Base RAM allocation and usage
  const maxRamAllocationMb = isLite ? 400 : 1024;
  let baseRam = isLite ? 120 : 280;

  if (isExecuting) {
    baseRam += isLite ? 60 : 140;
  }
  if (!isIdle && !settings.aggressiveIdleReduction) {
    baseRam += 30;
  }
  if (settings.expandedWorkflowCache) {
    baseRam += 45;
  }
  const estimatedRamUsageMb = Math.min(maxRamAllocationMb, baseRam);

  // CPU Load calculation
  let cpuLoadPct = isIdle ? 3 : isExecuting ? (isLite ? 16 : 28) : 8;
  if (settings.reducedBackgroundCpu) cpuLoadPct = Math.max(2, cpuLoadPct - 6);
  if (settings.minimalAnimations) cpuLoadPct = Math.max(2, cpuLoadPct - 3);

  // Thermal state based on actual workload (Zero-Heating claim is explicitly rejected by physics)
  let thermalState: PerformanceMetrics['thermalState'] = 'normal';
  if (isExecuting && !isLite) {
    thermalState = 'warm';
  } else if (isExecuting && !settings.cooldownPeriodsEnabled) {
    thermalState = 'warm';
  }

  // Battery discharge
  let batteryDischargeRateMw = isIdle ? 220 : isExecuting ? 980 : 450;
  if (settings.batterySaverEnabled) batteryDischargeRateMw *= 0.68;
  if (settings.eventDrivenProcessing) batteryDischargeRateMw *= 0.85;

  // Screenshot frequency
  const screenshotFrequencyFps = isIdle
    ? 0.0
    : settings.avoidContinuousCapture
    ? 0.2 // Event-driven triggers only
    : settings.reducedScreenshotFrequency
    ? 0.5
    : 2.5;

  // Data saved
  let mobileDataSavedKb = 3450;
  if (settings.compressPayloads) mobileDataSavedKb += 1820;
  if (settings.avoidVideoDownloads) mobileDataSavedKb += 14200; // avoid downloading 1080p MP4s

  const thermalNote = 
    '⚠️ Thermodynamic Physics: 3D mobile games like Free Fire generate substantial processor heat. ' +
    'AutoPilot throttles background polling and caps OCR to minimize thermal buildup, but no software setting can guarantee zero physical heating.';

  return {
    estimatedRamUsageMb,
    maxRamAllocationMb,
    cpuLoadPct: Math.round(cpuLoadPct),
    thermalState,
    batteryDischargeRateMw: Math.round(batteryDischargeRateMw),
    mobileDataSavedKb,
    screenshotFrequencyFps,
    cachedWorkflowsCount: isLite ? 5 : 42,
    activeParallelTasksCount: isLite ? Math.min(1, activeTasksCount) : activeTasksCount,
    pollingIntervalMs: settings.reducedPolling ? settings.pollingIntervalMs : 400,
    cooldownPeriodMs: settings.cooldownPeriodsEnabled ? settings.cooldownDurationMs : 0,
    idleReductionActive: isIdle && settings.aggressiveIdleReduction,
    thermalNote,
  };
}
