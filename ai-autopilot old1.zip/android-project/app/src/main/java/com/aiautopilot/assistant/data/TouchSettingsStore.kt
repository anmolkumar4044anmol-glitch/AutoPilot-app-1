package com.aiautopilot.assistant.data

import android.content.Context
import android.content.SharedPreferences
import com.aiautopilot.assistant.engine.HumanTouchSimulator

/**
 * TouchSettingsStore: Persists all Human Touch Simulator settings to Android SharedPreferences.
 * Ensures custom reaction times, swipe curves, jitter radii, and gaming-only restrictions persist across reboots and sessions.
 */
class TouchSettingsStore(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("autopilot_touch_settings_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_PRESET = "preset_id"
        private const val KEY_CUSTOM_DELAY = "custom_delay_ms"
        private const val KEY_TAP_HOLD = "tap_hold_ms"
        private const val KEY_TAP_PRE_DELAY = "tap_pre_delay_ms"
        private const val KEY_SWIPE_DURATION = "swipe_duration_ms"
        private const val KEY_SWIPE_DISTANCE = "swipe_distance_px"
        private const val KEY_SWIPE_CURVATURE = "swipe_curvature"
        private const val KEY_DRAG_SHAPE = "drag_curve_shape"
        private const val KEY_SCROLL_SPEED = "scroll_speed_ms"
        private const val KEY_SCROLL_STEP = "scroll_step_px"
        private const val KEY_NATURAL_PAUSE_MIN = "natural_pause_min_ms"
        private const val KEY_NATURAL_PAUSE_MAX = "natural_pause_max_ms"
        private const val KEY_TIMING_VARIATION_PCT = "timing_variation_pct"
        private const val KEY_TYPING_INTERVAL = "typing_interval_ms"
        private const val KEY_TYPING_JITTER = "typing_jitter_ms"
        private const val KEY_BOUNDARY_CLAMPING = "boundary_clamping_enabled"
        private const val KEY_TARGET_PADDING = "target_padding_px"
        private const val KEY_JITTER_ENABLED = "jitter_enabled"
        private const val KEY_JITTER_RADIUS = "jitter_radius_px"
        private const val KEY_GAMING_ONLY = "gaming_only_restriction"
    }

    /**
     * Loads saved settings from SharedPreferences into HumanTouchSimulator engine.
     */
    fun loadSettings() {
        val presetName = prefs.getString(KEY_PRESET, HumanTouchSimulator.ReactionPreset.FASTEST.name) ?: HumanTouchSimulator.ReactionPreset.FASTEST.name
        HumanTouchSimulator.activePreset = try {
            HumanTouchSimulator.ReactionPreset.valueOf(presetName)
        } catch (e: Exception) {
            HumanTouchSimulator.ReactionPreset.FASTEST
        }

        HumanTouchSimulator.customDelayMs = prefs.getLong(KEY_CUSTOM_DELAY, 100L)
        HumanTouchSimulator.tapHoldDurationMs = prefs.getLong(KEY_TAP_HOLD, 70L)
        HumanTouchSimulator.tapPreDelayMs = prefs.getLong(KEY_TAP_PRE_DELAY, 50L)
        HumanTouchSimulator.swipeDurationMs = prefs.getLong(KEY_SWIPE_DURATION, 130L)
        HumanTouchSimulator.swipeDistancePx = prefs.getFloat(KEY_SWIPE_DISTANCE, 320f)
        HumanTouchSimulator.swipeCurveCurvature = prefs.getFloat(KEY_SWIPE_CURVATURE, 0.35f)
        
        val shapeName = prefs.getString(KEY_DRAG_SHAPE, HumanTouchSimulator.DragCurveShape.J_CURVE.name) ?: HumanTouchSimulator.DragCurveShape.J_CURVE.name
        HumanTouchSimulator.activeDragShape = try {
            HumanTouchSimulator.DragCurveShape.valueOf(shapeName)
        } catch (e: Exception) {
            HumanTouchSimulator.DragCurveShape.J_CURVE
        }

        HumanTouchSimulator.scrollSpeedMs = prefs.getLong(KEY_SCROLL_SPEED, 300L)
        HumanTouchSimulator.scrollStepPx = prefs.getFloat(KEY_SCROLL_STEP, 420f)
        HumanTouchSimulator.naturalPauseMinMs = prefs.getLong(KEY_NATURAL_PAUSE_MIN, 80L)
        HumanTouchSimulator.naturalPauseMaxMs = prefs.getLong(KEY_NATURAL_PAUSE_MAX, 250L)
        HumanTouchSimulator.timingVariationPct = prefs.getInt(KEY_TIMING_VARIATION_PCT, 12)
        HumanTouchSimulator.typingIntervalMs = prefs.getLong(KEY_TYPING_INTERVAL, 50L)
        HumanTouchSimulator.typingJitterMs = prefs.getLong(KEY_TYPING_JITTER, 10L)
        HumanTouchSimulator.boundaryClampingEnabled = prefs.getBoolean(KEY_BOUNDARY_CLAMPING, true)
        HumanTouchSimulator.targetPaddingPx = prefs.getFloat(KEY_TARGET_PADDING, 8f)
        HumanTouchSimulator.jitterEnabled = prefs.getBoolean(KEY_JITTER_ENABLED, true)
        HumanTouchSimulator.maxJitterPixels = prefs.getFloat(KEY_JITTER_RADIUS, 5f)
        HumanTouchSimulator.gamingOnlyRestriction = prefs.getBoolean(KEY_GAMING_ONLY, true)
    }

    /**
     * Saves all current engine settings to SharedPreferences.
     */
    fun saveSettings() {
        prefs.edit().apply {
            putString(KEY_PRESET, HumanTouchSimulator.activePreset.name)
            putLong(KEY_CUSTOM_DELAY, HumanTouchSimulator.customDelayMs)
            putLong(KEY_TAP_HOLD, HumanTouchSimulator.tapHoldDurationMs)
            putLong(KEY_TAP_PRE_DELAY, HumanTouchSimulator.tapPreDelayMs)
            putLong(KEY_SWIPE_DURATION, HumanTouchSimulator.swipeDurationMs)
            putFloat(KEY_SWIPE_DISTANCE, HumanTouchSimulator.swipeDistancePx)
            putFloat(KEY_SWIPE_CURVATURE, HumanTouchSimulator.swipeCurveCurvature)
            putString(KEY_DRAG_SHAPE, HumanTouchSimulator.activeDragShape.name)
            putLong(KEY_SCROLL_SPEED, HumanTouchSimulator.scrollSpeedMs)
            putFloat(KEY_SCROLL_STEP, HumanTouchSimulator.scrollStepPx)
            putLong(KEY_NATURAL_PAUSE_MIN, HumanTouchSimulator.naturalPauseMinMs)
            putLong(KEY_NATURAL_PAUSE_MAX, HumanTouchSimulator.naturalPauseMaxMs)
            putInt(KEY_TIMING_VARIATION_PCT, HumanTouchSimulator.timingVariationPct)
            putLong(KEY_TYPING_INTERVAL, HumanTouchSimulator.typingIntervalMs)
            putLong(KEY_TYPING_JITTER, HumanTouchSimulator.typingJitterMs)
            putBoolean(KEY_BOUNDARY_CLAMPING, HumanTouchSimulator.boundaryClampingEnabled)
            putFloat(KEY_TARGET_PADDING, HumanTouchSimulator.targetPaddingPx)
            putBoolean(KEY_JITTER_ENABLED, HumanTouchSimulator.jitterEnabled)
            putFloat(KEY_JITTER_RADIUS, HumanTouchSimulator.maxJitterPixels)
            putBoolean(KEY_GAMING_ONLY, HumanTouchSimulator.gamingOnlyRestriction)
            apply()
        }
    }

    /**
     * Resets preferences to factory defaults.
     */
    fun resetToDefaults() {
        prefs.edit().clear().apply()
        loadSettings()
    }
}
