package com.aiautopilot.assistant.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Local database model for task execution history and audit logs.
 */
@Entity(tableName = "task_logs")
data class TaskLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: String,
    val type: String, // 'info', 'success', 'warning', 'error', 'security'
    val message: String,
    val details: String? = null,
    val epochTime: Long = System.currentTimeMillis()
)
