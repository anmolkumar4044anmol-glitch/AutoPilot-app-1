package com.aiautopilot.assistant.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.FrameLayout
import androidx.core.app.NotificationCompat
import com.aiautopilot.assistant.MainActivity
import com.aiautopilot.assistant.engine.IntelligentResumeManager
import com.aiautopilot.assistant.engine.VoiceCompanionEngine
import kotlinx.coroutines.*

/**
 * AI AutoPilot Floating Assistant & Foreground Service
 * Specification Compliance:
 * - Default position: top-left of screen (16, 36)
 * - Small green floating indicator (movable, compact, does not cover screen)
 * - 3 States: GREEN (running), ORANGE (paused), RED (emergency stop)
 * - Intelligent Pause and Resume: OFF preserves state; ON inspects screen and resumes safely.
 * - Explicit Closing: Stops automation, removes overlay, stops service, cancels notification.
 * - Strict Gaming Guard: Never touches non-gaming applications.
 */
class FloatingAssistantOverlayService : Service() {

    enum class AssistantState {
        RUNNING_GREEN,
        PAUSED_ORANGE,
        STOPPED_RED
    }

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var bubbleView: View? = null
    private var params: WindowManager.LayoutParams? = null

    private var currentState = AssistantState.RUNNING_GREEN
    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    companion object {
        const val CHANNEL_ID = "autopilot_assistant_channel"
        const val NOTIFICATION_ID = 2001

        const val ACTION_PAUSE = "com.aiautopilot.assistant.ACTION_PAUSE"
        const val ACTION_RESUME = "com.aiautopilot.assistant.ACTION_RESUME"
        const val ACTION_EMERGENCY_STOP = "com.aiautopilot.assistant.ACTION_EMERGENCY_STOP"
        const val ACTION_CLOSE = "com.aiautopilot.assistant.ACTION_CLOSE"

        var activeInstance: FloatingAssistantOverlayService? = null
            private set
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        activeInstance = this
        createNotificationChannel()
        val notification = buildOngoingNotification("AI AutoPilot Active • Free Fire Ready", AssistantState.RUNNING_GREEN)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        setupOverlayView()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PAUSE -> setAssistantState(AssistantState.PAUSED_ORANGE)
            ACTION_RESUME -> setAssistantState(AssistantState.RUNNING_GREEN)
            ACTION_EMERGENCY_STOP -> triggerEmergencyStop()
            ACTION_CLOSE -> explicitlyCloseService()
        }
        return START_STICKY
    }

    /**
     * Initializes the small movable floating indicator.
     * Default position: top-left (16, 36).
     */
    private fun setupOverlayView() {
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        // Compact bubble: 42dp diameter (does not obstruct gameplay)
        val density = resources.displayMetrics.density
        val sizePx = (42 * density).toInt()

        params = WindowManager.LayoutParams(
            sizePx,
            sizePx,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            // Default position: top-left of screen
            x = (16 * density).toInt()
            y = (36 * density).toInt()
        }

        val container = FrameLayout(this)
        val bubble = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(sizePx, sizePx)
            // Default Green when starting active
            background = createBubbleDrawable(Color.parseColor("#10B981"))
        }

        bubbleView = bubble
        container.addView(bubble)
        overlayView = container

        // Movable drag listener & click trigger
        var isDragging = false
        var lastClickTime = 0L

        container.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params?.x ?: 0
                    initialY = params?.y ?: 0
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (Math.abs(dx) > 8 || Math.abs(dy) > 8) {
                        isDragging = true
                        params?.x = initialX + dx
                        params?.y = initialY + dy
                        windowManager?.updateViewLayout(overlayView, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        val now = System.currentTimeMillis()
                        if (now - lastClickTime < 300) {
                            // Double tap: Reopen main app interface
                            reopenMainActivity()
                        } else {
                            // Single tap: Cycle Pause / Resume
                            cyclePauseResume()
                        }
                        lastClickTime = now
                    }
                    true
                }
                else -> false
            }
        }

        try {
            windowManager?.addView(overlayView, params)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Cycles between Green (Running) and Orange (Paused).
     */
    fun cyclePauseResume() {
        when (currentState) {
            AssistantState.RUNNING_GREEN -> setAssistantState(AssistantState.PAUSED_ORANGE)
            AssistantState.PAUSED_ORANGE -> setAssistantState(AssistantState.RUNNING_GREEN)
            AssistantState.STOPPED_RED -> setAssistantState(AssistantState.PAUSED_ORANGE)
        }
    }

    /**
     * Sets state with visual color change and Intelligent Pause & Resume.
     * GREEN: AutoPilot is active and allowed to execute tasks.
     * ORANGE: AutoPilot is paused.
     * RED: Emergency stop activated.
     */
    fun setAssistantState(state: AssistantState) {
        currentState = state
        val bubble = bubbleView ?: return

        when (state) {
            AssistantState.RUNNING_GREEN -> {
                // Trigger Intelligent Pause and Resume
                bubble.background = createBubbleDrawable(Color.parseColor("#10B981")) // Emerald Green
                updateNotification("Status: GREEN (Executing approved gaming steps)", state)
                AutoPilotAccessibilityService.instance?.resetEmergencyStop()
                AutoPilotAccessibilityService.instance?.resumeExecution()
                VoiceCompanionEngine.speak("AutoPilot resumed. Executing next step.")
            }
            AssistantState.PAUSED_ORANGE -> {
                // OFF pauses current task without closing AutoPilot
                bubble.background = createBubbleDrawable(Color.parseColor("#F59E0B")) // Amber Orange
                updateNotification("Status: ORANGE (Task paused • Checkpoint preserved)", state)
                AutoPilotAccessibilityService.instance?.pauseExecution()
                VoiceCompanionEngine.speak("AutoPilot paused. Progress saved.")
            }
            AssistantState.STOPPED_RED -> {
                // Emergency stop
                bubble.background = createBubbleDrawable(Color.parseColor("#EF4444")) // Crimson Red
                updateNotification("Status: RED (Emergency Stop • Gestures Halted)", state)
                AutoPilotAccessibilityService.instance?.triggerEmergencyStop()
                VoiceCompanionEngine.speak("Emergency stop activated.")
            }
        }
    }

    fun triggerEmergencyStop() {
        setAssistantState(AssistantState.STOPPED_RED)
    }

    /**
     * Explicit closing:
     * When user explicitly closes AutoPilot:
     * - Stop automation
     * - Cancel active task execution
     * - Remove floating controls
     * - Stop foreground service
     * - Remove ongoing notification
     */
    fun explicitlyCloseService() {
        AutoPilotAccessibilityService.instance?.triggerEmergencyStop()
        AutoPilotAccessibilityService.instance?.pauseExecution()
        IntelligentResumeManager.clearCheckpoint()
        VoiceCompanionEngine.speak("AI AutoPilot closed.")

        if (overlayView != null) {
            try {
                windowManager?.removeView(overlayView)
            } catch (e: Exception) {
                // View already detached
            }
            overlayView = null
            bubbleView = null
        }

        stopForeground(true)
        stopSelf()
    }

    private fun reopenMainActivity() {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        startActivity(launchIntent)
    }

    private fun createBubbleDrawable(colorInt: Int): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(colorInt)
            setStroke(3, Color.WHITE)
        }
    }

    private fun buildOngoingNotification(contentText: String, state: AssistantState): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val toggleActionIntent = Intent(this, FloatingAssistantOverlayService::class.java).apply {
            action = if (state == AssistantState.RUNNING_GREEN) ACTION_PAUSE else ACTION_RESUME
        }
        val togglePendingIntent = PendingIntent.getService(
            this, 1, toggleActionIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopActionIntent = Intent(this, FloatingAssistantOverlayService::class.java).apply {
            action = ACTION_EMERGENCY_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 2, stopActionIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val closeActionIntent = Intent(this, FloatingAssistantOverlayService::class.java).apply {
            action = ACTION_CLOSE
        }
        val closePendingIntent = PendingIntent.getService(
            this, 3, closeActionIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val toggleLabel = if (state == AssistantState.RUNNING_GREEN) "Pause" else "Resume"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("AI AutoPilot • Free Fire Assistant")
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(openPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(android.R.drawable.ic_media_pause, toggleLabel, togglePendingIntent)
            .addAction(android.R.drawable.ic_delete, "Emergency Stop", stopPendingIntent)
            .addAction(android.R.drawable.ic_lock_power_off, "Close AutoPilot", closePendingIntent)
            .build()
    }

    private fun updateNotification(text: String, state: AssistantState) {
        val notification = buildOngoingNotification(text, state)
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, notification)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "AI AutoPilot Assistant Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Ongoing foreground indicator and quick floating controls for Free Fire"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        if (overlayView != null) {
            try {
                windowManager?.removeView(overlayView)
            } catch (e: Exception) {
                // ignore
            }
            overlayView = null
            bubbleView = null
        }
        activeInstance = null
    }
}
