package com.aiautopilot.assistant.data.dao

import androidx.room.*
import com.aiautopilot.assistant.data.model.TaskLogEntity

@Dao
interface TaskLogDao {
    @Query("SELECT * FROM task_logs ORDER BY id DESC LIMIT 100")
    suspend fun getRecentLogs(): List<TaskLogEntity>

    @Insert
    suspend fun insertLog(log: TaskLogEntity)

    @Query("DELETE FROM task_logs")
    suspend fun clearAllLogs()
}
