package com.aiautopilot.assistant.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Local database model for saved workflows and Free Fire pro macros.
 */
@Entity(tableName = "workflows")
data class WorkflowEntity(
    @PrimaryKey
    val id: String,
    val title: String,
    val category: String, // 'free_fire', 'system', 'learning'
    val description: String,
    val stepsJson: String,
    val stepsCount: Int,
    val isRestrictedToFreeFire: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)
