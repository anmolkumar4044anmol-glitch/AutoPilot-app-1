package com.aiautopilot.assistant.engine

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.PowerManager
import androidx.annotation.RequiresApi

/**
 * Adaptive Performance Manager (Native Android Implementation)
 *
 * Regulates memory, polling, and CPU execution between:
 * - LITE MODE (4 GB RAM): Single-task constraint, 400MB memory cap, 0.5 FPS capture, 1600ms polling, 3s idle sleep
 * - ADVANCED MODE (8 GB RAM): 1GB memory cap, 2.5 FPS capture, 600ms polling, 50 macro cache
 *
 * Battery Saving:
 * - Suppresses continuous screen capture by relying on onAccessibilityEvent
 * - Puts background processing to sleep during idle periods
 * - Thermal state listener (PowerManager.OnThermalStatusChangedListener) to engage cooling pauses
 *
 * Network & Data:
 * - Compresses JSON payloads
 * - Bypasses heavy video downloads (transcript first)
 * - Prioritizes 100% offline Room database execution
 */
object AdaptivePerformanceManager {
    enum class DeviceProfile { LITE_4GB, ADVANCED_8GB }

    var activeProfile: DeviceProfile = DeviceProfile.LITE_4GB
    var singleTaskOnly: Boolean = true
    var avoidContinuousCapture: Boolean = true
    var eventDrivenProcessing: Boolean = true
    var cooldownPeriodsEnabled: Boolean = true
    var cooldownDurationMs: Long = 900L
    var pollingIntervalMs: Long = 1600L
    var mobileDataCompressionEnabled: Boolean = true
    var offlineExecutionPreferred: Boolean = true

    // Thermal state monitoring (Android 10 / API 29+)
    @RequiresApi(Build.VERSION_CODES.Q)
    fun registerThermalListener(context: Context, onThermalWarning: (Int) -> Unit) {
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        powerManager?.addThermalStatusListener { status ->
            when (status) {
                PowerManager.THERMAL_STATUS_MODERATE,
                PowerManager.THERMAL_STATUS_SEVERE -> {
                    // Extra cooldown breather delay during hot Free Fire matches
                    cooldownPeriodsEnabled = true
                    cooldownDurationMs = 1200L
                    pollingIntervalMs = 2400L
                    onThermalWarning(status)
                }
            }
        }
    }

    fun recommendProfile(context: Context): DeviceProfile {
        val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        actManager?.getMemoryInfo(memInfo)
        val totalRamGb = memInfo.totalMem / (1024 * 1024 * 1024)
        activeProfile = if (totalRamGb <= 4) DeviceProfile.LITE_4GB else DeviceProfile.ADVANCED_8GB
        return activeProfile
    }
}
