package com.aiautopilot.assistant.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager
import com.aiautopilot.assistant.engine.CallModeManager

/**
 * Automatic Phone Call Detector Receiver
 *
 * SPECIFICATION COMPLIANCE:
 * 1. Automatically mutes AI AutoPilot speech output upon call detection.
 * 2. Switches to written command mode.
 * 3. Never mutes, screens, or controls the actual phone call.
 * 4. Never answers, rejects, or hangs up calls.
 * 5. Uses minimum READ_PHONE_STATE permission only.
 * 6. Preserves task state throughout the call.
 * 7. Restores previous voice settings upon CALL_STATE_IDLE.
 */
class PhoneCallStateReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent?.action == TelephonyManager.ACTION_PHONE_STATE_CHANGED) {
            val stateStr = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
            when (stateStr) {
                TelephonyManager.EXTRA_STATE_RINGING -> {
                    CallModeManager.handleCallState(TelephonyManager.CALL_STATE_RINGING)
                }
                TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                    CallModeManager.handleCallState(TelephonyManager.CALL_STATE_OFFHOOK)
                }
                TelephonyManager.EXTRA_STATE_IDLE -> {
                    CallModeManager.handleCallState(TelephonyManager.CALL_STATE_IDLE)
                }
            }
        }
    }
}
