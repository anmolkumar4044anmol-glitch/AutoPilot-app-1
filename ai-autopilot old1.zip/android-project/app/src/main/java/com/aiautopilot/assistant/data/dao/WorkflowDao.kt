package com.aiautopilot.assistant.data.dao

import androidx.room.*
import com.aiautopilot.assistant.data.model.WorkflowEntity

@Dao
interface WorkflowDao {
    @Query("SELECT * FROM workflows ORDER BY createdAt DESC")
    suspend fun getAllWorkflows(): List<WorkflowEntity>

    @Query("SELECT * FROM workflows WHERE category = :cat")
    suspend fun getWorkflowsByCategory(cat: String): List<WorkflowEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkflow(workflow: WorkflowEntity)

    @Delete
    suspend fun deleteWorkflow(workflow: WorkflowEntity)

    @Query("DELETE FROM workflows WHERE id = :id")
    suspend fun deleteWorkflowById(id: String)
}
