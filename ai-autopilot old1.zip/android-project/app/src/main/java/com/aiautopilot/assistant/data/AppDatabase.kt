package com.aiautopilot.assistant.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.aiautopilot.assistant.data.dao.TaskLogDao
import com.aiautopilot.assistant.data.dao.WorkflowDao
import com.aiautopilot.assistant.data.model.TaskLogEntity
import com.aiautopilot.assistant.data.model.WorkflowEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Native Android SQLite Database implementation for AI AutoPilot
 * Provides zero-dependency, crash-resistant local persistence for 4GB & 8GB RAM devices.
 */
class AppDatabase private constructor(context: Context) : SQLiteOpenHelper(
    context.applicationContext,
    DATABASE_NAME,
    null,
    DATABASE_VERSION
) {

    companion object {
        const val DATABASE_NAME = "ai_autopilot_database.db"
        const val DATABASE_VERSION = 1

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: AppDatabase(context).also { INSTANCE = it }
            }
        }
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS workflows (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                category TEXT NOT NULL,
                description TEXT NOT NULL,
                stepsJson TEXT NOT NULL,
                stepsCount INTEGER NOT NULL,
                isRestrictedToFreeFire INTEGER NOT NULL DEFAULT 1,
                createdAt INTEGER NOT NULL
            )
            """.trimIndent()
        )

        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS task_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                type TEXT NOT NULL,
                message TEXT NOT NULL,
                details TEXT,
                epochTime INTEGER NOT NULL
            )
            """.trimIndent()
        )

        // Seed default Free Fire pro macros
        seedDefaultWorkflows(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS workflows")
        db.execSQL("DROP TABLE IF EXISTS task_logs")
        onCreate(db)
    }

    private fun seedDefaultWorkflows(db: SQLiteDatabase) {
        val cv = ContentValues().apply {
            put("id", "wf_ff_pro_macro")
            put("title", "Free Fire India — Pro Ultra Setup & Sensitivity")
            put("category", "free_fire")
            put("description", "Calibrates 98% General Sensitivity and instant Gloo Wall crouch-deploy combo.")
            put("stepsJson", "[]")
            put("stepsCount", 5)
            put("isRestrictedToFreeFire", 1)
            put("createdAt", System.currentTimeMillis())
        }
        db.insert("workflows", null, cv)
    }

    val workflowDao: WorkflowDao = object : WorkflowDao {
        override suspend fun getAllWorkflows(): List<WorkflowEntity> = withContext(Dispatchers.IO) {
            val list = mutableListOf<WorkflowEntity>()
            val db = readableDatabase
            val cursor = db.rawQuery("SELECT * FROM workflows ORDER BY createdAt DESC", null)
            cursor.use {
                while (it.moveToNext()) {
                    list.add(
                        WorkflowEntity(
                            id = it.getString(it.getColumnIndexOrThrow("id")),
                            title = it.getString(it.getColumnIndexOrThrow("title")),
                            category = it.getString(it.getColumnIndexOrThrow("category")),
                            description = it.getString(it.getColumnIndexOrThrow("description")),
                            stepsJson = it.getString(it.getColumnIndexOrThrow("stepsJson")),
                            stepsCount = it.getInt(it.getColumnIndexOrThrow("stepsCount")),
                            isRestrictedToFreeFire = it.getInt(it.getColumnIndexOrThrow("isRestrictedToFreeFire")) == 1,
                            createdAt = it.getLong(it.getColumnIndexOrThrow("createdAt"))
                        )
                    )
                }
            }
            list
        }

        override suspend fun getWorkflowsByCategory(cat: String): List<WorkflowEntity> = withContext(Dispatchers.IO) {
            val list = mutableListOf<WorkflowEntity>()
            val db = readableDatabase
            val cursor = db.rawQuery("SELECT * FROM workflows WHERE category = ? ORDER BY createdAt DESC", arrayOf(cat))
            cursor.use {
                while (it.moveToNext()) {
                    list.add(
                        WorkflowEntity(
                            id = it.getString(it.getColumnIndexOrThrow("id")),
                            title = it.getString(it.getColumnIndexOrThrow("title")),
                            category = it.getString(it.getColumnIndexOrThrow("category")),
                            description = it.getString(it.getColumnIndexOrThrow("description")),
                            stepsJson = it.getString(it.getColumnIndexOrThrow("stepsJson")),
                            stepsCount = it.getInt(it.getColumnIndexOrThrow("stepsCount")),
                            isRestrictedToFreeFire = it.getInt(it.getColumnIndexOrThrow("isRestrictedToFreeFire")) == 1,
                            createdAt = it.getLong(it.getColumnIndexOrThrow("createdAt"))
                        )
                    )
                }
            }
            list
        }

        override suspend fun insertWorkflow(workflow: WorkflowEntity) = withContext(Dispatchers.IO) {
            val db = writableDatabase
            val cv = ContentValues().apply {
                put("id", workflow.id)
                put("title", workflow.title)
                put("category", workflow.category)
                put("description", workflow.description)
                put("stepsJson", workflow.stepsJson)
                put("stepsCount", workflow.stepsCount)
                put("isRestrictedToFreeFire", if (workflow.isRestrictedToFreeFire) 1 else 0)
                put("createdAt", workflow.createdAt)
            }
            db.insertWithOnConflict("workflows", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
            Unit
        }

        override suspend fun deleteWorkflow(workflow: WorkflowEntity) = withContext(Dispatchers.IO) {
            deleteWorkflowById(workflow.id)
        }

        override suspend fun deleteWorkflowById(id: String) = withContext(Dispatchers.IO) {
            val db = writableDatabase
            db.delete("workflows", "id = ?", arrayOf(id))
            Unit
        }
    }

    val taskLogDao: TaskLogDao = object : TaskLogDao {
        override suspend fun getRecentLogs(): List<TaskLogEntity> = withContext(Dispatchers.IO) {
            val list = mutableListOf<TaskLogEntity>()
            val db = readableDatabase
            val cursor = db.rawQuery("SELECT * FROM task_logs ORDER BY id DESC LIMIT 100", null)
            cursor.use {
                while (it.moveToNext()) {
                    list.add(
                        TaskLogEntity(
                            id = it.getLong(it.getColumnIndexOrThrow("id")),
                            timestamp = it.getString(it.getColumnIndexOrThrow("timestamp")),
                            type = it.getString(it.getColumnIndexOrThrow("type")),
                            message = it.getString(it.getColumnIndexOrThrow("message")),
                            details = it.getString(it.getColumnIndexOrThrow("details")),
                            epochTime = it.getLong(it.getColumnIndexOrThrow("epochTime"))
                        )
                    )
                }
            }
            list
        }

        override suspend fun insertLog(log: TaskLogEntity) = withContext(Dispatchers.IO) {
            val db = writableDatabase
            val cv = ContentValues().apply {
                put("timestamp", log.timestamp)
                put("type", log.type)
                put("message", log.message)
                put("details", log.details)
                put("epochTime", log.epochTime)
            }
            db.insert("task_logs", null, cv)
            Unit
        }

        override suspend fun clearAllLogs() = withContext(Dispatchers.IO) {
            val db = writableDatabase
            db.delete("task_logs", null, null)
            Unit
        }
    }
}
