package com.aiautopilot.assistant.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.aiautopilot.assistant.data.AppDatabase
import com.aiautopilot.assistant.data.model.TaskLogEntity
import com.aiautopilot.assistant.data.model.WorkflowEntity
import com.aiautopilot.assistant.engine.AdaptivePerformanceManager
import com.aiautopilot.assistant.engine.AdaptiveTaskPlanner
import com.aiautopilot.assistant.engine.HumanTouchSimulator
import com.aiautopilot.assistant.engine.IntelligentResumeManager
import com.aiautopilot.assistant.engine.VoiceCompanionEngine
import kotlinx.coroutines.*
import org.json.JSONArray
import java.util.concurrent.atomic.AtomicBoolean

/**
 * AI AutoPilot Core Accessibility Engine
 * Dispatches humanized gestures, inspects screen hierarchy, and executes safe tasks.
 */
class AutoPilotAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private val isEmergencyStopped = AtomicBoolean(false)
    private val isPaused = AtomicBoolean(false)
    private var currentPackageName: String = ""
    private var activeJob: Job? = null

    companion object {
        var instance: AutoPilotAccessibilityService? = null
            private set
        
        val isServiceConnected: Boolean
            get() = instance != null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        isEmergencyStopped.set(false)
        isPaused.set(false)
        try {
            com.aiautopilot.assistant.data.TouchSettingsStore(this).loadSettings()
        } catch (e: Exception) {
            // fallback
        }
        logToDb("Accessibility Service connected successfully. Touch settings loaded.", "success")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            currentPackageName = event.packageName?.toString() ?: ""
        }
    }

    override fun onInterrupt() {
        triggerEmergencyStop()
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        instance = null
    }

    fun getActiveAppPackage(): String = currentPackageName

    fun triggerEmergencyStop() {
        isEmergencyStopped.set(true)
        activeJob?.cancel()
        logToDb("Emergency stop triggered. Aborting all operations.", "error")
    }

    fun resetEmergencyStop() {
        isEmergencyStopped.set(false)
    }

    fun pauseExecution() {
        isPaused.set(true)
        logToDb("Execution paused. State preserved.", "info")
    }

    fun resumeExecution() {
        isPaused.set(false)
        logToDb("Execution resumed.", "info")
    }

    /**
     * Executes a list of planned steps sequentially with human touch delay and verification.
     * Incorporates Intelligent Resume, reaction preset timing, and Adaptive Performance constraints.
     */
    fun executeWorkflow(
        steps: List<AdaptiveTaskPlanner.TaskStep>,
        timingProfile: HumanTouchSimulator.ReactionPreset = HumanTouchSimulator.activePreset,
        onStepUpdate: (Int, Boolean) -> Unit,
        onComplete: (Boolean) -> Unit
    ) {
        if (isEmergencyStopped.get()) {
            onComplete(false)
            return
        }

        // Strict Gaming-Only Lock Enforcement: Never touch non-gaming applications
        if (!HumanTouchSimulator.isAllowedGamingPackage(currentPackageName)) {
            logToDb("BLOCKED: AutoTouch restricted to Free Fire and gaming apps. Inactive on package ($currentPackageName).", "security")
            VoiceCompanionEngine.speak("AutoTouch blocked. Automation is locked to gaming apps only.")
            onComplete(false)
            return
        }

        // Lite Mode 4GB constraint: ensure only single active task execution
        if (AdaptivePerformanceManager.singleTaskOnly && activeJob?.isActive == true) {
            logToDb("Lite Mode: Cancelling previous task to preserve 4GB RAM threshold.", "info")
            activeJob?.cancel()
        }

        activeJob?.cancel()
        activeJob = serviceScope.launch {
            // Step 1: Intelligent Pause and Resume check
            val resumeDecision = IntelligentResumeManager.evaluateSafeResume(steps, currentPackageName)
            if (!resumeDecision.canResume) {
                logToDb("Resume halted: ${resumeDecision.reason}", "warning")
                VoiceCompanionEngine.speak(resumeDecision.reason)
                onComplete(false)
                return@launch
            }

            val startIndex = resumeDecision.resumeFromStepIndex.coerceAtLeast(0)
            logToDb(resumeDecision.reason, "info")

            for (index in startIndex until steps.size) {
                val step = steps[index]
                if (isEmergencyStopped.get()) {
                    onComplete(false)
                    return@launch
                }

                // Verify gaming app is still in foreground before every single step
                if (!HumanTouchSimulator.isAllowedGamingPackage(currentPackageName)) {
                    logToDb("ABORTED: Switched to non-gaming package ($currentPackageName). Touch halted.", "security")
                    onComplete(false)
                    return@launch
                }

                // Check paused state (Intelligent OFF pause)
                while (isPaused.get()) {
                    delay(300)
                    if (isEmergencyStopped.get()) {
                        onComplete(false)
                        return@launch
                    }
                }

                // Natural pre-step delay with human cognitive timing variation and selected Reaction Preset
                val reactionMs = if (timingProfile == HumanTouchSimulator.ReactionPreset.CUSTOM) {
                    HumanTouchSimulator.customDelayMs
                } else {
                    timingProfile.baseDelayMs
                }
                val pauseMs = HumanTouchSimulator.getNaturalPauseMs()
                val variedDelay = HumanTouchSimulator.applyTimingVariation(reactionMs + pauseMs + HumanTouchSimulator.tapPreDelayMs)
                delay(variedDelay)

                // Adaptive Performance Cooldown pause for thermal and battery preservation
                if (AdaptivePerformanceManager.cooldownPeriodsEnabled && 
                    AdaptivePerformanceManager.activeProfile == AdaptivePerformanceManager.DeviceProfile.LITE_4GB) {
                    delay(AdaptivePerformanceManager.cooldownDurationMs)
                }

                var stepSuccess = false
                val completable = CompletableDeferred<Boolean>()

                when (step.actionType) {
                    "tap" -> {
                        val node = findElementOnScreen(step.targetDescription)
                        if (node != null && node.isClickable) {
                            stepSuccess = node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                            completable.complete(stepSuccess)
                        } else {
                            // Fallback to coordinate touch if node is not directly clickable
                            dispatchHumanTap(540f, 1000f, timingProfile) { res ->
                                completable.complete(res)
                            }
                        }
                    }
                    "swipe" -> {
                        dispatchHumanSwipe(540f, 1200f, 540f, 400f, HumanTouchSimulator.swipeDurationMs) { res ->
                            completable.complete(res)
                        }
                    }
                    "scroll" -> {
                        val root = rootInActiveWindow
                        stepSuccess = root?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) ?: false
                        completable.complete(stepSuccess)
                    }
                    else -> {
                        completable.complete(true)
                    }
                }

                val result = completable.await()
                step.isCompleted = result
                onStepUpdate(index, result)

                // Save step checkpoint in IntelligentResumeManager for safe resumption
                if (result) {
                    IntelligentResumeManager.saveCheckpoint("Free Fire Task", index, currentPackageName)
                }

                logToDb("Step ${index + 1}/${steps.size}: ${step.targetDescription} -> ${if (result) "SUCCESS" else "RETRY"}", if (result) "success" else "warning")

                if (!result && step.retryCount < 2) {
                    step.retryCount++
                    delay(500)
                }
            }

            // Task successfully finished - clear completed checkpoint
            IntelligentResumeManager.clearCheckpoint()
            onComplete(true)
            VoiceCompanionEngine.speak("Task execution finished successfully.")
        }
    }

    /**
     * Executes a saved workflow from SQLite database by parsing its JSON steps
     */
    fun executeSavedWorkflow(
        workflow: WorkflowEntity,
        timingProfile: HumanTouchSimulator.ReactionPreset = HumanTouchSimulator.activePreset,
        onStepUpdate: (Int, Boolean) -> Unit,
        onComplete: (Boolean) -> Unit
    ) {
        val steps = mutableListOf<AdaptiveTaskPlanner.TaskStep>()
        try {
            val jsonArray = JSONArray(workflow.stepsJson)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                steps.add(
                    AdaptiveTaskPlanner.TaskStep(
                        stepId = obj.optString("id", "step_$i"),
                        actionType = obj.optString("actionType", obj.optString("action", "tap")),
                        targetDescription = obj.optString("targetDescription", obj.optString("target", "Screen Item")),
                        expectedVerification = obj.optString("expectedVerification", "Verified"),
                        isCompleted = false
                    )
                )
            }
        } catch (e: Exception) {
            logToDb("Error parsing workflow steps: ${e.message}", "error")
            onComplete(false)
            return
        }

        if (steps.isEmpty()) {
            logToDb("Workflow '${workflow.title}' has no executable steps.", "warning")
            onComplete(false)
            return
        }

        executeWorkflow(steps, timingProfile, onStepUpdate, onComplete)
    }

    /**
     * Dispatches a human-like tap gesture with randomized reaction time and target jitter
     */
    fun dispatchHumanTap(
        targetX: Float,
        targetY: Float,
        timingProfile: HumanTouchSimulator.ReactionPreset = HumanTouchSimulator.activePreset,
        onComplete: (Boolean) -> Unit
    ) {
        if (isEmergencyStopped.get()) {
            onComplete(false)
            return
        }

        // Strict Gaming-Only Lock
        if (!HumanTouchSimulator.isAllowedGamingPackage(currentPackageName)) {
            logToDb("BLOCKED: Tap aborted on non-gaming package ($currentPackageName).", "security")
            onComplete(false)
            return
        }

        val jitter = HumanTouchSimulator.calculateJitter(targetX, targetY)
        val baseHold = HumanTouchSimulator.tapHoldDurationMs
        val tapDuration = HumanTouchSimulator.applyTimingVariation(baseHold)

        val path = Path().apply {
            moveTo(jitter.first, jitter.second)
        }

        val stroke = GestureDescription.StrokeDescription(path, 0, tapDuration)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                onComplete(true)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                onComplete(false)
            }
        }, null)
    }

    /**
     * Dispatches a Bézier curved swipe to simulate natural human thumb motion
     */
    fun dispatchHumanSwipe(
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        durationMs: Long = HumanTouchSimulator.swipeDurationMs,
        onComplete: (Boolean) -> Unit
    ) {
        if (isEmergencyStopped.get()) {
            onComplete(false)
            return
        }

        // Strict Gaming-Only Lock
        if (!HumanTouchSimulator.isAllowedGamingPackage(currentPackageName)) {
            logToDb("BLOCKED: Swipe aborted on non-gaming package ($currentPackageName).", "security")
            onComplete(false)
            return
        }

        val curvedPath = HumanTouchSimulator.generateCurvedPath(startX, startY, endX, endY)
        val variedDuration = HumanTouchSimulator.applyTimingVariation(durationMs)
        val stroke = GestureDescription.StrokeDescription(curvedPath, 0, variedDuration)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                onComplete(true)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                onComplete(false)
            }
        }, null)
    }

    /**
     * Types text into target editable node with realistic interval delays
     */
    fun performTextType(node: AccessibilityNodeInfo, text: String): Boolean {
        val arguments = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
    }

    /**
     * Inspects current screen node tree to locate elements by text, ID, or description
     */
    fun findElementOnScreen(query: String): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val lowerQuery = query.lowercase()

        // 1. Search by Text
        val textMatches = root.findAccessibilityNodeInfosByText(query)
        if (textMatches.isNotEmpty()) return textMatches.first()

        // 2. Search recursively in tree for contentDescription or viewId
        return searchNodeRecursively(root, lowerQuery)
    }

    private fun searchNodeRecursively(node: AccessibilityNodeInfo, query: String): AccessibilityNodeInfo? {
        val text = node.text?.toString()?.lowercase() ?: ""
        val desc = node.contentDescription?.toString()?.lowercase() ?: ""
        val viewId = node.viewIdResourceName?.lowercase() ?: ""

        if (text.contains(query) || desc.contains(query) || viewId.contains(query)) {
            return node
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = searchNodeRecursively(child, query)
            if (found != null) return found
        }
        return null
    }

    private fun logToDb(msg: String, type: String) {
        serviceScope.launch {
            try {
                AppDatabase.getInstance(this@AutoPilotAccessibilityService).taskLogDao.insertLog(
                    TaskLogEntity(
                        timestamp = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date()),
                        type = type,
                        message = msg
                    )
                )
            } catch (e: Exception) {
                // Silently handle
            }
        }
    }
}
