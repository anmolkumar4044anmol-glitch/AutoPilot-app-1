package com.aiautopilot.assistant.engine

import android.view.accessibility.AccessibilityNodeInfo
import com.aiautopilot.assistant.service.AutoPilotAccessibilityService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Intelligent Pause and Resume Engine
 * Implements the 7-step resumption protocol:
 * 1. Load the saved task state.
 * 2. Inspect the current screen.
 * 3. Check which steps are completed (prevent duplicate clicks).
 * 4. Detect environmental / screen changes.
 * 5. Recalculate the remaining plan.
 * 6. Continue from the safest appropriate step.
 * 7. Never blindly repeat potentially destructive actions.
 */
object IntelligentResumeManager {

    data class TaskCheckpoint(
        val taskId: String,
        val taskName: String,
        val completedStepIndices: MutableSet<Int> = mutableSetOf(),
        var lastCompletedStepIndex: Int = -1,
        var targetPackageName: String = "com.dts.freefireth",
        var timestamp: Long = System.currentTimeMillis()
    )

    data class ResumeDecision(
        val canResume: Boolean,
        val resumeFromStepIndex: Int,
        val reason: String,
        val blockedDestructiveActions: List<String> = emptyList()
    )

    private var activeCheckpoint: TaskCheckpoint? = null

    // Strictly blocked actions that must NEVER be repeated blindly upon resume
    private val DESTRUCTIVE_KEYWORDS = listOf(
        "buy", "purchase", "diamond", "coin", "payment", "upi", 
        "confirm order", "delete", "remove account", "logout", "fire weapon repeatedly"
    )

    fun saveCheckpoint(taskName: String, stepIndex: Int, packageName: String = "com.dts.freefireth") {
        val cp = activeCheckpoint ?: TaskCheckpoint(
            taskId = "task_${System.currentTimeMillis()}",
            taskName = taskName,
            targetPackageName = packageName
        )
        cp.completedStepIndices.add(stepIndex)
        cp.lastCompletedStepIndex = stepIndex
        cp.timestamp = System.currentTimeMillis()
        activeCheckpoint = cp
    }

    suspend fun evaluateSafeResume(
        totalSteps: List<AdaptiveTaskPlanner.TaskStep>,
        currentPackageName: String
    ): ResumeDecision = withContext(Dispatchers.Default) {
        val checkpoint = activeCheckpoint

        // Check 1: Enforce strict gaming-only restriction (never touch non-gaming apps)
        val isGaming = currentPackageName.contains("freefire", ignoreCase = true) ||
                       currentPackageName.contains("game", ignoreCase = true)
        if (!isGaming) {
            return@withContext ResumeDecision(
                canResume = false,
                resumeFromStepIndex = -1,
                reason = "AutoPilot is strictly locked to Free Fire and gaming apps. AutoTouch blocked on $currentPackageName."
            )
        }

        // If no prior checkpoint exists, start safely from step 0
        if (checkpoint == null) {
            return@withContext ResumeDecision(
                canResume = true,
                resumeFromStepIndex = 0,
                reason = "Fresh session verified on gaming window. Starting safely from step 1."
            )
        }

        // Check 2 & 3: Find completed steps and determine the next safe unexecuted step
        val nextIndex = checkpoint.lastCompletedStepIndex + 1
        if (nextIndex >= totalSteps.size) {
            return@withContext ResumeDecision(
                canResume = false,
                resumeFromStepIndex = nextIndex,
                reason = "All planned steps in workflow '${checkpoint.taskName}' were already executed and verified."
            )
        }

        val candidateStep = totalSteps[nextIndex]

        // Check 7: Prevent repeating destructive actions
        val isDestructive = DESTRUCTIVE_KEYWORDS.any { keyword ->
            candidateStep.description.contains(keyword, ignoreCase = true) ||
            candidateStep.target.contains(keyword, ignoreCase = true)
        }

        if (isDestructive && checkpoint.completedStepIndices.contains(nextIndex)) {
            return@withContext ResumeDecision(
                canResume = false,
                resumeFromStepIndex = nextIndex,
                reason = "Prevented repeat execution of destructive step: '${candidateStep.description}'.",
                blockedDestructiveActions = listOf(candidateStep.description)
            )
        }

        // Step 6: Safe resumption point confirmed
        return@withContext ResumeDecision(
            canResume = true,
            resumeFromStepIndex = nextIndex,
            reason = "State recovery complete: Skipped ${checkpoint.completedStepIndices.size} verified steps. Continuing safely from step #${nextIndex + 1} ('${candidateStep.description}')."
        )
    }

    fun clearCheckpoint() {
        activeCheckpoint = null
    }

    fun getActiveCheckpoint(): TaskCheckpoint? = activeCheckpoint
}
