package com.aiautopilot.assistant.engine

import kotlinx.coroutines.delay

/**
 * Adaptive Task Intelligence Engine
 * 10-Step AI Task Process:
 * 1. Understand user command (Hindi, English, Hinglish).
 * 2. Identify intended result.
 * 3. Identify explicit hard restrictions.
 * 4. Create step-by-step plan.
 * 5. Identify permitted methods.
 * 6. Select safest method considering time, reliability, battery, and memory.
 * 7. Execute one step at a time.
 * 8. Verify each important result.
 * 9. Recover from errors using alternative permitted methods (dynamic replanning).
 * 10. Report completion or explain failure.
 */
class AdaptiveTaskPlanner {

    enum class ProcessStage {
        UNDERSTAND_COMMAND,
        IDENTIFY_INTENT,
        CHECK_RESTRICTIONS,
        PLAN_STEPS,
        EVALUATE_METHODS,
        SELECT_SAFEST_METHOD,
        EXECUTE_STEP,
        VERIFY_RESULT,
        RECOVER_OR_REPLAN,
        REPORT_RESULT
    }

    data class MultiFactorScore(
        val timeMs: Long,
        val reliabilityPercent: Int, // 0-100
        val batteryDrainPercent: Float, // estimated per run
        val memoryConsumptionKb: Long,
        val safetyScorePercent: Int
    )

    data class ExecutionMethod(
        val name: String,
        val score: MultiFactorScore,
        val description: String,
        val isPermitted: Boolean
    )

    data class TaskStep(
        val stepId: String,
        var actionType: String,
        var targetDescription: String,
        val expectedVerification: String,
        var isCompleted: Boolean = false,
        var retryCount: Int = 0,
        var executionMethodUsed: String = "AccessibilityNodeTraversal"
    )

    data class UserCorrection(
        val timestamp: Long,
        val stepId: String,
        val originalTarget: String,
        val correctedTarget: String
    )

    data class TaskState(
        val taskId: String,
        val originalInstruction: String,
        val intendedResult: String,
        val userRestrictions: List<String>,
        val steps: MutableList<TaskStep>,
        val availableMethods: List<ExecutionMethod>,
        var selectedMethod: ExecutionMethod,
        var currentStepIndex: Int = 0,
        var currentStage: ProcessStage = ProcessStage.UNDERSTAND_COMMAND,
        var isPaused: Boolean = false,
        val recoveryLog: MutableList<String> = mutableListOf(),
        val userCorrections: MutableList<UserCorrection> = mutableListOf(),
        val failedMethodsBlacklist: MutableSet<String> = mutableSetOf()
    )

    private var activeTask: TaskState? = null

    /**
     * Step 1 to 6: Parses command, validates constraints, and selects safest method.
     */
    fun planTask(
        instruction: String,
        restrictions: List<String>,
        rawSteps: List<TaskStep>
    ): Pair<TaskState?, String?> {
        val lower = instruction.lowercase()

        // Step 2: Identify intended result
        val intendedResult = when {
            lower.contains("free fire") || lower.contains("gloo") -> "Optimize Free Fire sensitivity and attach pro gloo wall macro"
            lower.contains("battery") || lower.contains("setting") -> "Adjust device settings and enable battery saver safely"
            else -> "Execute requested task hands-free with verified completion"
        }

        // Step 3: Check for hard constraint violations upfront
        for (restriction in restrictions) {
            val rLower = restriction.lowercase()
            if (rLower.contains("do not close") && (lower.contains("close") || lower.contains("exit") || lower.contains("band kar"))) {
                return Pair(null, "Task halted: Requested action violates hard constraint 'Do not close the current application'. No permitted method exists.")
            }
            if (rLower.contains("do not delete") && (lower.contains("delete") || lower.contains("remove") || lower.contains("hatao"))) {
                return Pair(null, "Task halted: Requested action violates hard constraint 'Do not delete files'. Action blocked.")
            }
            if (rLower.contains("stop before payment") && (lower.contains("pay") || lower.contains("buy") || lower.contains("khareedo"))) {
                return Pair(null, "Task paused: Approaching payment boundary. Explicit user confirmation required.")
            }
        }

        // Step 5: Identify possible permitted methods and calculate scores
        val methodA = ExecutionMethod(
            name = "AccessibilityNodeTraversal",
            score = MultiFactorScore(timeMs = 1800, reliabilityPercent = 97, batteryDrainPercent = 0.05f, memoryConsumptionKb = 400, safetyScorePercent = 99),
            description = "Directly inspects View hierarchy for text/IDs. Fastest and lowest memory.",
            isPermitted = true
        )
        val methodB = ExecutionMethod(
            name = "BezierCoordinateSimulator",
            score = MultiFactorScore(timeMs = 2600, reliabilityPercent = 92, batteryDrainPercent = 0.08f, memoryConsumptionKb = 650, safetyScorePercent = 95),
            description = "Simulates human thumb sweep with randomized jitter. Ideal for game HUDs.",
            isPermitted = true
        )
        val methodC = ExecutionMethod(
            name = "VisualPatternMatch",
            score = MultiFactorScore(timeMs = 4200, reliabilityPercent = 86, batteryDrainPercent = 0.22f, memoryConsumptionKb = 1400, safetyScorePercent = 92),
            description = "OCR visual pattern scanning fallback if nodes are obscured.",
            isPermitted = true
        )

        // Step 6: Select safest suitable method
        val selectedMethod = methodA

        val state = TaskState(
            taskId = "task_${System.currentTimeMillis()}",
            originalInstruction = instruction,
            intendedResult = intendedResult,
            userRestrictions = restrictions,
            steps = rawSteps.toMutableList(),
            availableMethods = listOf(methodA, methodB, methodC),
            selectedMethod = selectedMethod,
            currentStage = ProcessStage.EXECUTE_STEP
        )

        activeTask = state
        return Pair(state, null)
    }

    fun getActiveTask(): TaskState? = activeTask

    fun pauseTask(): TaskState? {
        activeTask?.isPaused = true
        return activeTask
    }

    fun resumeTask(): TaskStep? {
        val task = activeTask ?: return null
        task.isPaused = false
        val nextStep = task.steps.firstOrNull { !it.isCompleted }
        if (nextStep != null) {
            task.currentStepIndex = task.steps.indexOf(nextStep)
        }
        return nextStep
    }

    fun markCurrentStepSuccess() {
        val task = activeTask ?: return
        if (task.currentStepIndex in task.steps.indices) {
            task.steps[task.currentStepIndex].isCompleted = true
            task.currentStepIndex++
            if (task.currentStepIndex >= task.steps.size) {
                task.currentStage = ProcessStage.REPORT_RESULT
            }
        }
    }

    /**
     * Step 9: Replan & Error Recovery
     * When current screen differs from expectations or an element fails,
     * AutoPilot records the failed approach to avoid repeating it, and dynamically
     * switches to the next permitted method without repeating completed steps.
     */
    fun recoverFromError(failedStep: TaskStep, reason: String): TaskStep? {
        val task = activeTask ?: return null
        task.currentStage = ProcessStage.RECOVER_OR_REPLAN

        // Remember failed approach to avoid repeating mistakes
        val failureKey = "${failedStep.executionMethodUsed}_on_${failedStep.targetDescription}"
        task.failedMethodsBlacklist.add(failureKey)
        task.recoveryLog.add("Failed: $reason. Blacklisted: $failureKey. Re-evaluating next permitted method...")

        // Switch to alternative method
        val alternativeMethod = if (failedStep.executionMethodUsed == "AccessibilityNodeTraversal") {
            task.availableMethods.find { it.name == "BezierCoordinateSimulator" } ?: task.selectedMethod
        } else {
            task.availableMethods.find { it.name == "VisualPatternMatch" } ?: task.selectedMethod
        }

        task.selectedMethod = alternativeMethod
        failedStep.executionMethodUsed = alternativeMethod.name
        failedStep.retryCount++

        task.recoveryLog.add("Recovered: Switched to ${alternativeMethod.name}. Continuing execution.")
        task.currentStage = ProcessStage.EXECUTE_STEP
        return failedStep
    }

    /**
     * Learning from User Corrections
     */
    fun applyUserCorrection(stepId: String, correctedTarget: String) {
        val task = activeTask ?: return
        val step = task.steps.find { it.stepId == stepId } ?: return

        task.userCorrections.add(
            UserCorrection(
                timestamp = System.currentTimeMillis(),
                stepId = stepId,
                originalTarget = step.targetDescription,
                correctedTarget = correctedTarget
            )
        )

        step.targetDescription = correctedTarget
        task.recoveryLog.add("Learned from user correction: Step $stepId target updated to '$correctedTarget'.")
    }

    /**
     * Step 3: Hard constraint checker for active operations
     */
    fun verifyConstraint(action: String, targetPackage: String): Boolean {
        val restrictions = activeTask?.userRestrictions ?: emptyList()
        for (restriction in restrictions) {
            val r = restriction.lowercase()
            if (r.contains("without closing") && action == "close_app") return false
            if (r.contains("do not switch") && (action == "switch_app" || action == "press_home")) return false
            if (r.contains("do not delete") && action == "delete_file") return false
            if (r.contains("stop before payment") && action == "confirm_payment") return false
        }
        return true
    }
}
