package com.aiautopilot.assistant.engine

import android.content.Context
import android.os.Build
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import android.util.Log
import androidx.annotation.RequiresApi

/**
 * Automatic Call Mode Manager
 *
 * SPECIFICATION REQUIREMENTS:
 * When a phone call is active:
 * 1. Automatically mute AI AutoPilot speech output.
 * 2. Switch to written command mode.
 * 3. Continue accepting permitted written commands.
 * 4. Avoid unnecessary audio playback.
 * 5. Preserve task state (automation coroutines and checkpoints untouched).
 * 6. Restore the previous voice settings when the call ends.
 *
 * SAFETY & PRIVACY CONSTRAINTS:
 * • Do NOT mute or control the actual phone call.
 * • Do NOT automatically answer, reject or end calls.
 * • Request only the minimum Android permissions (READ_PHONE_STATE).
 * • Respect Android call-state and privacy restrictions (no audio recording, no call logs, no phone numbers).
 * • If call-state detection is unavailable or permission denied, provide manual Quiet Mode.
 */
object CallModeManager {

    private const val TAG = "CallModeManager"

    private var telephonyManager: TelephonyManager? = null
    private var isRegistered = false

    // State Tracking
    var isCallActive: Boolean = false
        private set

    var isManualQuietMode: Boolean = false
        private set

    var isDetectionAvailable: Boolean = true
        private set

    // Preserved Prior Voice Settings Snapshot
    private var savedVoiceEnabled: Boolean = true
    private var savedSpeechSpeed: Float = 1.15f
    private var savedSpeechPitch: Float = 0.95f
    private var savedFastTalk: Boolean = true

    // Listener callbacks for UI overlay and notification updates
    private val listeners = mutableListOf<CallModeListener>()

    interface CallModeListener {
        fun onCallModeChanged(isCallActive: Boolean, isMuted: Boolean, writtenModeOnly: Boolean)
    }

    fun addListener(listener: CallModeListener) {
        if (!listeners.contains(listener)) {
            listeners.add(listener)
        }
    }

    fun removeListener(listener: CallModeListener) {
        listeners.remove(listener)
    }

    /**
     * Initializes call-state detection using TelephonyManager.
     * Uses TelephonyCallback on Android 12+ (API 31+) and PhoneStateListener on older versions.
     */
    fun init(context: Context) {
        if (isRegistered) return

        try {
            telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager

            if (telephonyManager == null) {
                Log.w(TAG, "TelephonyManager unavailable on device. Enabling manual Quiet Mode fallback.")
                isDetectionAvailable = false
                return
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                registerTelephonyCallbackApi31(context)
            } else {
                registerLegacyPhoneStateListener()
            }

            isRegistered = true
            isDetectionAvailable = true
            Log.i(TAG, "Automatic Call Mode initialized with minimum READ_PHONE_STATE listener.")
        } catch (e: SecurityException) {
            Log.w(TAG, "READ_PHONE_STATE permission not granted: ${e.message}. Manual Quiet Mode fallback active.")
            isDetectionAvailable = false
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize CallModeManager: ${e.message}")
            isDetectionAvailable = false
        }
    }

    @RequiresApi(Build.VERSION_CODES.S)
    private fun registerTelephonyCallbackApi31(context: Context) {
        val callback = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
            override fun onCallStateChanged(state: Int) {
                handleCallState(state)
            }
        }
        telephonyManager?.registerTelephonyCallback(context.mainExecutor, callback)
    }

    @Suppress("DEPRECATION")
    private fun registerLegacyPhoneStateListener() {
        val listener = object : PhoneStateListener() {
            @Deprecated("Deprecated in Java")
            override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                handleCallState(state)
            }
        }
        telephonyManager?.listen(listener, PhoneStateListener.LISTEN_CALL_STATE)
    }

    /**
     * Core Call State Handler
     * Strictly limits action to AutoPilot audio muting and written command mode switching.
     * NEVER interacts with TelecomManager call control.
     */
    fun handleCallState(state: Int) {
        when (state) {
            TelephonyManager.CALL_STATE_RINGING,
            TelephonyManager.CALL_STATE_OFFHOOK -> {
                if (!isCallActive) {
                    onPhoneCallStarted()
                }
            }
            TelephonyManager.CALL_STATE_IDLE -> {
                if (isCallActive) {
                    onPhoneCallEnded()
                }
            }
        }
    }

    private fun onPhoneCallStarted() {
        Log.i(TAG, "Phone call active: Auto-muting AutoPilot speech output. Switching to Written Command Mode.")
        isCallActive = true

        // 1. Snapshot previous voice settings
        savedSpeechSpeed = VoiceCompanionEngine.speechSpeed
        savedSpeechPitch = VoiceCompanionEngine.speechPitch

        // 2. Mute AutoPilot voice companion immediately
        VoiceCompanionEngine.setCallActive(true)

        // 3. Notify overlay HUD and ongoing notification (Written Command Mode Active)
        notifyListeners(isCallActive = true, isMuted = true, writtenModeOnly = true)
    }

    private fun onPhoneCallEnded() {
        Log.i(TAG, "Phone call ended: Restoring previous voice settings. Task state preserved.")
        isCallActive = false

        // 1. Restore previous voice settings
        VoiceCompanionEngine.speechSpeed = savedSpeechSpeed
        VoiceCompanionEngine.speechPitch = savedSpeechPitch

        // 2. Unmute AutoPilot voice companion (if not in manual Quiet Mode)
        if (!isManualQuietMode) {
            VoiceCompanionEngine.setCallActive(false)
        }

        // 3. Notify overlay HUD and ongoing notification
        notifyListeners(isCallActive = false, isMuted = isManualQuietMode, writtenModeOnly = isManualQuietMode)
    }

    /**
     * Manual Quiet Mode Switch
     * Provided for when call-state detection is unavailable, denied, or user prefers silence.
     */
    fun setManualQuietMode(enabled: Boolean) {
        isManualQuietMode = enabled
        VoiceCompanionEngine.setQuietMode(enabled)
        notifyListeners(
            isCallActive = isCallActive,
            isMuted = enabled || isCallActive,
            writtenModeOnly = enabled || isCallActive
        )
        Log.i(TAG, "Manual Quiet Mode toggled: $enabled")
    }

    private fun notifyListeners(isCallActive: Boolean, isMuted: Boolean, writtenModeOnly: Boolean) {
        listeners.forEach {
            try {
                it.onCallModeChanged(isCallActive, isMuted, writtenModeOnly)
            } catch (e: Exception) {
                Log.e(TAG, "Error notifying CallModeListener: ${e.message}")
            }
        }
    }
}
