package com.aiautopilot.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.aiautopilot.assistant.data.AppDatabase
import com.aiautopilot.assistant.data.model.TaskLogEntity
import com.aiautopilot.assistant.engine.AdaptiveTaskPlanner
import com.aiautopilot.assistant.engine.HumanTouchSimulator
import com.aiautopilot.assistant.engine.VoiceCompanionEngine
import com.aiautopilot.assistant.service.AutoPilotAccessibilityService
import com.aiautopilot.assistant.service.FloatingAssistantOverlayService
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val recordAudioGranted = permissions[Manifest.permission.RECORD_AUDIO] ?: false
        if (recordAudioGranted) {
            Toast.makeText(this, "Voice permissions granted", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        VoiceCompanionEngine.init(this)
        requestAppPermissions()

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF090D16)
                ) {
                    MainScreen()
                }
            }
        }
    }

    private fun requestAppPermissions() {
        val perms = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (perms.isNotEmpty()) {
            permissionLauncher.launch(perms.toTypedArray())
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun MainScreen() {
        val coroutineScope = rememberCoroutineScope()
        var selectedTab by remember { mutableStateOf(0) } // 0: Dashboard, 1: Touch Settings, 2: Free Fire, 3: Logs
        var commandText by remember { mutableStateOf("") }
        var isListening by remember { mutableStateOf(false) }
        var isLiteMode by remember { mutableStateOf(true) }
        var activePreset by remember { mutableStateOf(HumanTouchSimulator.activePreset) }
        var logsList by remember { mutableStateOf<List<TaskLogEntity>>(emptyList()) }

        val db = remember { AppDatabase.getInstance(this@MainActivity) }

        // Refresh logs periodically
        LaunchedEffect(selectedTab) {
            if (selectedTab == 3) {
                logsList = db.taskLogDao.getRecentLogs()
            }
        }

        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "AI AutoPilot",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = if (isLiteMode) "Lite Mode (4 GB RAM)" else "Advanced Mode (8 GB RAM)",
                                fontSize = 11.sp,
                                color = Color(0xFF38BDF8)
                            )
                        }
                    },
                    actions = {
                        // Emergency Stop Persistent Button
                        Button(
                            onClick = {
                                FloatingAssistantOverlayService.activeInstance?.triggerEmergencyStop()
                                AutoPilotAccessibilityService.instance?.triggerEmergencyStop()
                                Toast.makeText(this@MainActivity, "EMERGENCY STOP!", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text("STOP", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF090D16))
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF131D2F)) {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = { Icon(Icons.Default.PlayArrow, contentDescription = "Dashboard") },
                        label = { Text("Pilot", fontSize = 10.sp) }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = { Icon(Icons.Default.TouchApp, contentDescription = "Touch") },
                        label = { Text("Touch", fontSize = 10.sp) }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        icon = { Icon(Icons.Default.SportsEsports, contentDescription = "Free Fire") },
                        label = { Text("Free Fire", fontSize = 10.sp) }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        icon = { Icon(Icons.Default.History, contentDescription = "Logs") },
                        label = { Text("Logs", fontSize = 10.sp) }
                    )
                }
            },
            containerColor = Color(0xFF090D16)
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                when (selectedTab) {
                    0 -> DashboardView(
                        commandText = commandText,
                        onCommandChange = { commandText = it },
                        isListening = isListening,
                        onVoiceClick = {
                            if (!isListening) {
                                isListening = true
                                VoiceCompanionEngine.startListening(
                                    context = this@MainActivity,
                                    onResult = { result ->
                                        commandText = result
                                        isListening = false
                                        executeCommand(result)
                                    },
                                    onError = { err ->
                                        isListening = false
                                        Toast.makeText(this@MainActivity, err, Toast.LENGTH_SHORT).show()
                                    }
                                )
                            } else {
                                VoiceCompanionEngine.stopListening()
                                isListening = false
                            }
                        },
                        onActivateClick = {
                            if (checkAndRequestPermissions()) {
                                val intent = Intent(this@MainActivity, FloatingAssistantOverlayService::class.java)
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    startForegroundService(intent)
                                } else {
                                    startService(intent)
                                }
                                Toast.makeText(this@MainActivity, "Floating Assistant Activated!", Toast.LENGTH_SHORT).show()
                                VoiceCompanionEngine.speak("AI AutoPilot activated. Control bubble attached at top-left.")
                            }
                        },
                        onExecuteCommand = {
                            if (commandText.isNotBlank()) {
                                executeCommand(commandText)
                            }
                        }
                    )
                    1 -> TouchSettingsView(
                        activePreset = activePreset,
                        onPresetSelected = { preset ->
                            activePreset = preset
                            HumanTouchSimulator.activePreset = preset
                            Toast.makeText(this@MainActivity, "Preset set: ${preset.label}", Toast.LENGTH_SHORT).show()
                        }
                    )
                    2 -> FreeFireView(
                        onTriggerMacro = { macroName ->
                            if (!AutoPilotAccessibilityService.isServiceConnected) {
                                promptAccessibilityService()
                                return@FreeFireView
                            }
                            val steps = when (macroName) {
                                "gloo" -> listOf(
                                    AdaptiveTaskPlanner.TaskStep("ff-1", "tap", "Crouch", "Crouched", false),
                                    AdaptiveTaskPlanner.TaskStep("ff-2", "tap", "Gloo Wall", "Shield placed", false),
                                    AdaptiveTaskPlanner.TaskStep("ff-3", "swipe", "Camera", "180 degree spin", false)
                                )
                                else -> listOf(
                                    AdaptiveTaskPlanner.TaskStep("ff-s1", "tap", "Settings Gear", "Settings open", false),
                                    AdaptiveTaskPlanner.TaskStep("ff-s2", "tap", "Sensitivity", "Panel open", false),
                                    AdaptiveTaskPlanner.TaskStep("ff-s3", "swipe", "General Slider", "Slider at 98", false)
                                )
                            }
                            AutoPilotAccessibilityService.instance?.executeWorkflow(
                                steps = steps,
                                onStepUpdate = { idx, ok -> },
                                onComplete = { ok ->
                                    Toast.makeText(this@MainActivity, "Free Fire macro finished!", Toast.LENGTH_SHORT).show()
                                }
                            )
                        }
                    )
                    3 -> LogsView(logsList)
                }
            }
        }
    }

    @Composable
    fun DashboardView(
        commandText: String,
        onCommandChange: (String) -> Unit,
        isListening: Boolean,
        onVoiceClick: () -> Unit,
        onActivateClick: () -> Unit,
        onExecuteCommand: () -> Unit
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            // Status Banner
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131D2F)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Accessibility Service", fontSize = 12.sp, color = Color.White)
                        Text(
                            text = if (AutoPilotAccessibilityService.isServiceConnected) "CONNECTED" else "NOT CONNECTED",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (AutoPilotAccessibilityService.isServiceConnected) Color(0xFF10B981) else Color(0xFFF59E0B)
                        )
                    }
                    if (!AutoPilotAccessibilityService.isServiceConnected) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Button(
                            onClick = { promptAccessibilityService() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0891B2)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("ENABLE ACCESSIBILITY PERMISSION", fontSize = 11.sp)
                        }
                    }
                }
            }

            // Command input row
            OutlinedTextField(
                value = commandText,
                onValueChange = onCommandChange,
                placeholder = { Text("Command (e.g., 'Free fire sensitivity 98 set karo')...", fontSize = 12.sp, color = Color(0xFF64748B)) },
                trailingIcon = {
                    IconButton(onClick = onVoiceClick) {
                        Icon(
                            Icons.Default.Mic,
                            contentDescription = "Voice",
                            tint = if (isListening) Color(0xFFEF4444) else Color(0xFF38BDF8)
                        )
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF06B6D4),
                    unfocusedBorderColor = Color(0xFF334155),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = onExecuteCommand,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF06B6D4)),
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("RUN COMMAND", fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = onActivateClick,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("ACTIVATE FLOATING ASSISTANT OVERLAY", fontWeight = FontWeight.Bold)
            }
        }
    }

    @Composable
    fun TouchSettingsView(
        activePreset: HumanTouchSimulator.ReactionPreset,
        onPresetSelected: (HumanTouchSimulator.ReactionPreset) -> Unit
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Human Touch Simulator Presets", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("Controls actual Android touch delay and finger micro-jitter to prevent bot detection.", fontSize = 11.sp, color = Color(0xFF94A3B8))

            val presets = listOf(
                HumanTouchSimulator.ReactionPreset.FASTEST,
                HumanTouchSimulator.ReactionPreset.VERY_FAST,
                HumanTouchSimulator.ReactionPreset.FAST,
                HumanTouchSimulator.ReactionPreset.NORMAL,
                HumanTouchSimulator.ReactionPreset.RELAXED,
                HumanTouchSimulator.ReactionPreset.SLOW
            )

            presets.forEach { preset ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onPresetSelected(preset) },
                    colors = CardDefaults.cardColors(
                        containerColor = if (activePreset == preset) Color(0xFF0E384C) else Color(0xFF131D2F)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(preset.label, color = Color.White, fontSize = 13.sp)
                        Text("${preset.baseDelayMs} ms", color = Color(0xFF38BDF8), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    @Composable
    fun FreeFireView(onTriggerMacro: (String) -> Unit) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Free Fire India Pro Macros", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("Strictly sandboxed to Free Fire India window to protect device.", fontSize = 11.sp, color = Color(0xFF94A3B8))

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131D2F)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Instant Gloo Wall & 180° Spin", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Deploys protective ice shield in 110ms and pivots camera angle.", fontSize = 11.sp, color = Color(0xFF94A3B8))
                    Button(
                        onClick = { onTriggerMacro("gloo") },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("TRIGGER GLOO WALL MACRO", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131D2F)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Pro General Sensitivity 98 Setup", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Configures 98% General Sensitivity slider inside Free Fire settings.", fontSize = 11.sp, color = Color(0xFF94A3B8))
                    Button(
                        onClick = { onTriggerMacro("sensitivity") },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF06B6D4)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("APPLY SENSITIVITY TUNE", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    @Composable
    fun LogsView(logs: List<TaskLogEntity>) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Task Execution History", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
            if (logs.isEmpty()) {
                Text("No logs recorded yet. Run a command or activate floating overlay.", fontSize = 12.sp, color = Color(0xFF64748B))
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(logs) { log ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF131D2F)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(log.message, fontSize = 11.sp, color = Color.White, modifier = Modifier.weight(1f))
                                Text(log.timestamp, fontSize = 10.sp, color = Color(0xFF94A3B8))
                            }
                        }
                    }
                }
            }
        }
    }

    private fun executeCommand(command: String) {
        val steps = listOf(
            AdaptiveTaskPlanner.TaskStep("cmd-1", "tap", command, "Verified action", false)
        )
        if (AutoPilotAccessibilityService.isServiceConnected) {
            AutoPilotAccessibilityService.instance?.executeWorkflow(
                steps = steps,
                onStepUpdate = { idx, ok -> },
                onComplete = { ok ->
                    Toast.makeText(this, "Execution completed", Toast.LENGTH_SHORT).show()
                }
            )
        } else {
            promptAccessibilityService()
        }
    }

    private fun checkAndRequestPermissions(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Please grant Overlay Permission for Floating Assistant", Toast.LENGTH_LONG).show()
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
            return false
        }
        return true
    }

    private fun promptAccessibilityService() {
        Toast.makeText(this, "Please enable AI AutoPilot in Accessibility Settings", Toast.LENGTH_LONG).show()
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        startActivity(intent)
    }
}
