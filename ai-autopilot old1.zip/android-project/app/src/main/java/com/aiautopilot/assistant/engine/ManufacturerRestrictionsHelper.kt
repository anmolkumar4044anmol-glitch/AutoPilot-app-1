package com.aiautopilot.assistant.engine

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings

/**
 * Helper to navigate Android background execution limits and OEM manufacturer battery killers
 * (Xiaomi MIUI/HyperOS, Samsung One UI, Oppo ColorOS, Vivo Funtouch OS).
 */
object ManufacturerRestrictionsHelper {

    enum class OemType {
        XIAOMI,
        SAMSUNG,
        HUAWEI,
        OPPO_VIVO,
        GENERIC
    }

    fun detectOem(): OemType {
        val manufacturer = Build.MANUFACTURER.lowercase()
        return when {
            manufacturer.contains("xiaomi") || manufacturer.contains("redmi") || manufacturer.contains("poco") -> OemType.XIAOMI
            manufacturer.contains("samsung") -> OemType.SAMSUNG
            manufacturer.contains("huawei") || manufacturer.contains("honor") -> OemType.HUAWEI
            manufacturer.contains("oppo") || manufacturer.contains("vivo") || manufacturer.contains("realme") -> OemType.OPPO_VIVO
            else -> OemType.GENERIC
        }
    }

    /**
     * Intent to open Overlay permission settings (SYSTEM_ALERT_WINDOW)
     */
    fun getOverlayPermissionIntent(context: Context): Intent {
        return Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        ).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
    }

    /**
     * Intent to request exemption from Battery Optimization (REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
     */
    fun getBatteryOptimizationIntent(context: Context): Intent {
        return Intent().apply {
            action = Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS
            data = Uri.parse("package:${context.packageName}")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
    }

    /**
     * Attempts to open OEM-specific Autostart settings to prevent the system from killing
     * the AI AutoPilot foreground service in the background.
     */
    fun openOemAutostartSettings(context: Context): Boolean {
        val intents = listOf(
            // Xiaomi / HyperOS / MIUI
            Intent().setComponent(ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")),
            // Oppo / Realme
            Intent().setComponent(ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity")),
            // Vivo
            Intent().setComponent(ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity")),
            // Huawei
            Intent().setComponent(ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity")),
            // Samsung Device Care
            Intent().setComponent(ComponentName("com.samsung.android.lool", "com.samsung.android.sm.battery.ui.BatteryActivity"))
        )

        for (intent in intents) {
            try {
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(intent)
                return true
            } catch (e: Exception) {
                // Continue to next intent
            }
        }

        // Fallback: standard Application Details Settings
        return try {
            val fallback = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:${context.packageName}")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(fallback)
            true
        } catch (e: Exception) {
            false
        }
    }
}
