package com.aiautopilot.assistant.engine

import android.graphics.Path
import android.graphics.RectF
import kotlin.random.Random

/**
 * Human Touch Simulator Engine
 * Replaces robotic inputs with authentic human finger motor-dynamics:
 * - 8 Reaction time presets (100ms - 2000ms & custom)
 * - Adjustable tap down-up physical hold duration and pre-tap delay
 * - Adjustable swipe speed, distance, and Bézier thumb drag shapes
 * - Natural cognitive inter-action pauses and timing variation
 * - Strict Target Boundary Sentinel: prevents touching outside verified target bounding box
 * - Strict Gaming-Only Lock: refuses autotouch activation outside Free Fire and approved gaming apps
 */
object HumanTouchSimulator {

    enum class ReactionPreset(val baseDelayMs: Long, val label: String) {
        FASTEST(100L, "1. Fastest (100 ms)"),
        VERY_FAST(200L, "2. Very Fast (200 ms)"),
        FAST(350L, "3. Fast (350 ms)"),
        NORMAL(600L, "4. Normal (600 ms)"),
        RELAXED(900L, "5. Relaxed (900 ms)"),
        SLOW(1400L, "6. Slow (1400 ms)"),
        VERY_SLOW(2000L, "7. Very Slow (2000 ms)"),
        CUSTOM(350L, "8. Custom (50–3000 ms)")
    }

    enum class DragCurveShape {
        J_CURVE,         // Free Fire J-curve drag headshot
        STRAIGHT_UP,     // Vertical thumb arc
        ROTATION_CURVE   // Lateral sweeping drag
    }

    // Active Reaction Preset & Timing
    var activePreset: ReactionPreset = ReactionPreset.FASTEST
    var customDelayMs: Long = 100L

    // 1. Tap Timing
    var tapHoldDurationMs: Long = 70L       // Physical contact on glass
    var tapPreDelayMs: Long = 50L           // Pre-tap visual alignment

    // 2. Swipe Controls
    var swipeDurationMs: Long = 130L        // Swipe gesture duration
    var swipeDistancePx: Float = 320f       // Distance in pixels
    var swipeCurveCurvature: Float = 0.35f  // Bézier arc intensity (0 to 1)
    var activeDragShape: DragCurveShape = DragCurveShape.J_CURVE

    // 3. Scrolling Controls
    var scrollSpeedMs: Long = 300L          // Fling duration
    var scrollStepPx: Float = 420f          // Scroll step distance

    // 4. Natural Pauses & Timing Variation
    var naturalPauseMinMs: Long = 80L       // Inter-step min pause
    var naturalPauseMaxMs: Long = 250L      // Inter-step max pause
    var timingVariationPct: Int = 12        // ±% random human variation

    // 5. Typing Intervals
    var typingIntervalMs: Long = 50L        // Key interval
    var typingJitterMs: Long = 10L          // Key variance

    // 6. Safety & Target Boundary Sentinel
    var boundaryClampingEnabled: Boolean = true
    var targetPaddingPx: Float = 8f         // Safe inner boundary margin
    var jitterEnabled: Boolean = true
    var maxJitterPixels: Float = 5.0f

    // 7. Strict Gaming-Only Lockdown (Never touch non-gaming applications)
    var gamingOnlyRestriction: Boolean = true

    // Whitelist of approved gaming packages
    private val ALLOWED_GAMING_PACKAGES = hashSetOf(
        "com.dts.freefireth",            // Free Fire Global
        "com.dts.freefiremax",           // Free Fire MAX
        "com.dts.freefirein",            // Free Fire India
        "com.android.chrome",            // Web Gaming
        "org.mozilla.firefox",           // Web Gaming
        "com.brave.browser",             // Web Gaming
        "com.google.android.browser",    // Web Gaming
        "com.tencent.ig",                // BGMI / PUBG Mobile
        "com.pubg.imobile",              // Battlegrounds Mobile India
        "com.activision.callofduty.shooter" // COD Mobile
    )

    /**
     * Verifies if package belongs to an authorized game or web gaming browser.
     * Prevents autotouch from ever interacting with banking, messaging, or system settings.
     */
    fun isAllowedGamingPackage(packageName: String): Boolean {
        if (!gamingOnlyRestriction) return true
        val lower = packageName.lowercase()
        return ALLOWED_GAMING_PACKAGES.contains(lower) ||
               lower.contains("freefire") ||
               lower.contains("game") ||
               lower.contains("browser")
    }

    /**
     * Calculates realistic human finger landing coordinate variance.
     * Clamps strictly inside target bounding box if target bounds are provided.
     */
    fun calculateJitter(x: Float, y: Float, targetBounds: RectF? = null): Pair<Float, Float> {
        var jX = x
        var jY = y

        if (jitterEnabled) {
            val deltaX = (Random.nextFloat() * 2f - 1f) * maxJitterPixels
            val deltaY = (Random.nextFloat() * 2f - 1f) * maxJitterPixels
            jX += deltaX
            jY += deltaY
        }

        if (boundaryClampingEnabled && targetBounds != null) {
            val minX = targetBounds.left + targetPaddingPx
            val maxX = targetBounds.right - targetPaddingPx
            val minY = targetBounds.top + targetPaddingPx
            val maxY = targetBounds.bottom - targetPaddingPx

            jX = jX.coerceIn(minX, maxX)
            jY = jY.coerceIn(minY, maxY)
        }

        return Pair(jX, jY)
    }

    /**
     * Returns natural inter-action cognitive pause between consecutive workflow steps.
     */
    fun getNaturalPauseMs(): Long {
        val min = naturalPauseMinMs.coerceAtLeast(40L)
        val max = naturalPauseMaxMs.coerceAtLeast(min + 10L)
        return Random.nextLong(min, max + 1)
    }

    /**
     * Applies human timing variation (±%) to prevent robotic exact-millisecond cadences.
     */
    fun applyTimingVariation(baseMs: Long): Long {
        if (timingVariationPct <= 0) return baseMs
        val variationSpan = (baseMs * (timingVariationPct / 100f)).toLong()
        if (variationSpan <= 0) return baseMs
        val delta = Random.nextLong(-variationSpan, variationSpan + 1)
        return (baseMs + delta).coerceAtLeast(20L)
    }

    /**
     * Generates a realistic curved path using Bézier mathematics.
     * Supports Free Fire J-curve drag, straight-up thumb drag, and rotation drag.
     */
    fun generateCurvedPath(
        startX: Float, 
        startY: Float, 
        endX: Float, 
        endY: Float,
        targetBounds: RectF? = null
    ): Path {
        val path = Path()
        val jitterStart = calculateJitter(startX, startY, targetBounds)
        val jitterEnd = calculateJitter(endX, endY, targetBounds)

        path.moveTo(jitterStart.first, jitterStart.second)

        val midX = (jitterStart.first + jitterEnd.first) / 2f
        val midY = (jitterStart.second + jitterEnd.second) / 2f

        val curveIntensity = swipeCurveCurvature * 60f

        val (ctrlX, ctrlY) = when (activeDragShape) {
            DragCurveShape.J_CURVE -> {
                // Free Fire J-Curve: brief initial dip before fast upward acceleration
                Pair(midX + curveIntensity * 0.8f, midY + curveIntensity * 0.4f)
            }
            DragCurveShape.ROTATION_CURVE -> {
                // Lateral sweeping thumb curve
                Pair(midX - curveIntensity * 0.9f, midY - curveIntensity * 0.3f)
            }
            DragCurveShape.STRAIGHT_UP -> {
                // Natural slight thumb drift
                val subtleOffset = (Random.nextFloat() * 2f - 1f) * 12f
                Pair(midX + subtleOffset, midY)
            }
        }

        path.quadTo(ctrlX, ctrlY, jitterEnd.first, jitterEnd.second)
        return path
    }

    /**
     * Free Fire Pro-Player Tunings
     */
    object FreeFireTuning {
        const val GLOO_WALL_DEPLOY_MS = 100L
        const val QUICK_CROUCH_DELAY_MS = 65L
        const val QUICK_SCOPE_TAP_MS = 75L
        const val DRAG_HEADSHOT_SWIPE_SPEED_MS = 130L
    }
}
