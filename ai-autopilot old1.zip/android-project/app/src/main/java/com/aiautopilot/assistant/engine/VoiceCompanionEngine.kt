package com.aiautopilot.assistant.engine

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * Live Voice Companion Engine
 * Provides dual-engine voice communication:
 * 1. Text-To-Speech (TTS) with friendly male tone, Fast Talk, and call muting.
 * 2. Speech-To-Text (STT) SpeechRecognizer for hands-free voice commands in Hindi and English.
 */
object VoiceCompanionEngine : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var isTtsInitialized = false
    private var isQuietMode = false
    private var isFastTalkMode = true
    private var isCallMuted = false
    private var isListening = false

    var speechSpeed: Float = 1.15f // Fast talk default
    var speechPitch: Float = 0.95f // Friendly male tone

    fun init(context: Context) {
        if (tts == null) {
            tts = TextToSpeech(context.applicationContext, this)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsInitialized = true
            tts?.setSpeechRate(speechSpeed)
            tts?.setPitch(speechPitch)
            tts?.language = Locale("hi", "IN")
        }
    }

    fun setQuietMode(enabled: Boolean) {
        isQuietMode = enabled
        if (enabled) {
            tts?.stop()
        }
    }

    fun setFastTalkMode(enabled: Boolean) {
        isFastTalkMode = enabled
        speechSpeed = if (enabled) 1.25f else 1.0f
        tts?.setSpeechRate(speechSpeed)
    }

    fun setCallActive(isActive: Boolean) {
        isCallMuted = isActive
        if (isActive) {
            tts?.stop()
            stopListening()
        }
    }

    /**
     * Speaks announcements if not muted by Quiet Mode or Phone Call Mode
     */
    fun speak(text: String, isHindi: Boolean = false) {
        if (isQuietMode || isCallMuted || !isTtsInitialized) return

        val utterance = if (isFastTalkMode && text.length > 80) {
            text.take(80)
        } else {
            text
        }

        if (isHindi || text.any { it.code in 0x0900..0x097F }) {
            tts?.language = Locale("hi", "IN")
        } else {
            tts?.language = Locale.ENGLISH
        }

        tts?.speak(utterance, TextToSpeech.QUEUE_FLUSH, null, "autopilot_${System.currentTimeMillis()}")
    }

    /**
     * Starts listening for voice commands using Android's SpeechRecognizer
     */
    fun startListening(
        context: Context,
        language: String = "hi-IN",
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        if (isCallMuted) {
            onError("Cannot listen during active phone call")
            return
        }

        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError("Speech recognition not available on device")
            return
        }

        stopListening()

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { isListening = true }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { isListening = false }

                override fun onError(error: Int) {
                    isListening = false
                    val errorMsg = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized"
                        SpeechRecognizer.ERROR_NETWORK -> "Network error during recognition"
                        SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
                        else -> "Speech recognition error code: $error"
                    }
                    onError(errorMsg)
                }

                override fun onResults(results: Bundle?) {
                    isListening = false
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!matches.isNullOrEmpty()) {
                        onResult(matches[0])
                    } else {
                        onError("No match found")
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language)
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, language)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }

        try {
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            onError("Failed to start speech listener: ${e.message}")
        }
    }

    fun stopListening() {
        if (isListening) {
            speechRecognizer?.stopListening()
            speechRecognizer?.destroy()
            speechRecognizer = null
            isListening = false
        }
    }

    fun stop() {
        tts?.stop()
        stopListening()
    }
}
